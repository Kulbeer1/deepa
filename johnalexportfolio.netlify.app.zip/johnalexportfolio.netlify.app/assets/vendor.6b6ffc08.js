var _f = Object.defineProperty,
    Lf = Object.defineProperties;
var Of = Object.getOwnPropertyDescriptors;
var dr = Object.getOwnPropertySymbols;
var Vs = Object.prototype.hasOwnProperty,
    Hs = Object.prototype.propertyIsEnumerable;
var Us = (e, t, n) => t in e ? _f(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n,
    Ti = (e, t) => {
        for (var n in t || (t = {})) Vs.call(t, n) && Us(e, n, t[n]);
        if (dr)
            for (var n of dr(t)) Hs.call(t, n) && Us(e, n, t[n]);
        return e
    },
    ki = (e, t) => Lf(e, Of(t));
var Pi = (e, t) => {
    var n = {};
    for (var r in e) Vs.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
    if (e != null && dr)
        for (var r of dr(e)) t.indexOf(r) < 0 && Hs.call(e, r) && (n[r] = e[r]);
    return n
};
var R = {
        exports: {}
    },
    A = {};
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
var Ws = Object.getOwnPropertySymbols,
    Mf = Object.prototype.hasOwnProperty,
    Nf = Object.prototype.propertyIsEnumerable;

function zf(e) {
    if (e == null) throw new TypeError("Object.assign cannot be called with null or undefined");
    return Object(e)
}

function If() {
    try {
        if (!Object.assign) return !1;
        var e = new String("abc");
        if (e[5] = "de", Object.getOwnPropertyNames(e)[0] === "5") return !1;
        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
        var r = Object.getOwnPropertyNames(t).map(function(l) {
            return t[l]
        });
        if (r.join("") !== "0123456789") return !1;
        var i = {};
        return "abcdefghijklmnopqrst".split("").forEach(function(l) {
            i[l] = l
        }), Object.keys(Object.assign({}, i)).join("") === "abcdefghijklmnopqrst"
    } catch {
        return !1
    }
}
var Gs = If() ? Object.assign : function(e, t) {
    for (var n, r = zf(e), i, l = 1; l < arguments.length; l++) {
        n = Object(arguments[l]);
        for (var s in n) Mf.call(n, s) && (r[s] = n[s]);
        if (Ws) {
            i = Ws(n);
            for (var a = 0; a < i.length; a++) Nf.call(n, i[a]) && (r[i[a]] = n[i[a]])
        }
    }
    return r
};
/** @license React v17.0.2
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var _i = Gs,
    $t = 60103,
    Ys = 60106;
A.Fragment = 60107;
A.StrictMode = 60108;
A.Profiler = 60114;
var bs = 60109,
    Xs = 60110,
    Qs = 60112;
A.Suspense = 60113;
var qs = 60115,
    Ks = 60116;
if (typeof Symbol == "function" && Symbol.for) {
    var ke = Symbol.for;
    $t = ke("react.element"), Ys = ke("react.portal"), A.Fragment = ke("react.fragment"), A.StrictMode = ke("react.strict_mode"), A.Profiler = ke("react.profiler"), bs = ke("react.provider"), Xs = ke("react.context"), Qs = ke("react.forward_ref"), A.Suspense = ke("react.suspense"), qs = ke("react.memo"), Ks = ke("react.lazy")
}
var Zs = typeof Symbol == "function" && Symbol.iterator;

function $f(e) {
    return e === null || typeof e != "object" ? null : (e = Zs && e[Zs] || e["@@iterator"], typeof e == "function" ? e : null)
}

function pn(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var Js = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    eo = {};

function Dt(e, t, n) {
    this.props = e, this.context = t, this.refs = eo, this.updater = n || Js
}
Dt.prototype.isReactComponent = {};
Dt.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error(pn(85));
    this.updater.enqueueSetState(this, e, t, "setState")
};
Dt.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function to() {}
to.prototype = Dt.prototype;

function Li(e, t, n) {
    this.props = e, this.context = t, this.refs = eo, this.updater = n || Js
}
var Oi = Li.prototype = new to;
Oi.constructor = Li;
_i(Oi, Dt.prototype);
Oi.isPureReactComponent = !0;
var Mi = {
        current: null
    },
    no = Object.prototype.hasOwnProperty,
    ro = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function io(e, t, n) {
    var r, i = {},
        l = null,
        s = null;
    if (t != null)
        for (r in t.ref !== void 0 && (s = t.ref), t.key !== void 0 && (l = "" + t.key), t) no.call(t, r) && !ro.hasOwnProperty(r) && (i[r] = t[r]);
    var a = arguments.length - 2;
    if (a === 1) i.children = n;
    else if (1 < a) {
        for (var o = Array(a), f = 0; f < a; f++) o[f] = arguments[f + 2];
        i.children = o
    }
    if (e && e.defaultProps)
        for (r in a = e.defaultProps, a) i[r] === void 0 && (i[r] = a[r]);
    return {
        $$typeof: $t,
        type: e,
        key: l,
        ref: s,
        props: i,
        _owner: Mi.current
    }
}

function Df(e, t) {
    return {
        $$typeof: $t,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function Ni(e) {
    return typeof e == "object" && e !== null && e.$$typeof === $t
}

function Rf(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var lo = /\/+/g;

function zi(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? Rf("" + e.key) : t.toString(36)
}

function pr(e, t, n, r, i) {
    var l = typeof e;
    (l === "undefined" || l === "boolean") && (e = null);
    var s = !1;
    if (e === null) s = !0;
    else switch (l) {
        case "string":
        case "number":
            s = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case $t:
                case Ys:
                    s = !0
            }
    }
    if (s) return s = e, i = i(s), e = r === "" ? "." + zi(s, 0) : r, Array.isArray(i) ? (n = "", e != null && (n = e.replace(lo, "$&/") + "/"), pr(i, t, n, "", function(f) {
        return f
    })) : i != null && (Ni(i) && (i = Df(i, n + (!i.key || s && s.key === i.key ? "" : ("" + i.key).replace(lo, "$&/") + "/") + e)), t.push(i)), 1;
    if (s = 0, r = r === "" ? "." : r + ":", Array.isArray(e))
        for (var a = 0; a < e.length; a++) {
            l = e[a];
            var o = r + zi(l, a);
            s += pr(l, t, n, o, i)
        } else if (o = $f(e), typeof o == "function")
            for (e = o.call(e), a = 0; !(l = e.next()).done;) l = l.value, o = r + zi(l, a++), s += pr(l, t, n, o, i);
        else if (l === "object") throw t = "" + e, Error(pn(31, t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t));
    return s
}

function hr(e, t, n) {
    if (e == null) return e;
    var r = [],
        i = 0;
    return pr(e, r, "", "", function(l) {
        return t.call(n, l, i++)
    }), r
}

function Af(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), e._status = 0, e._result = t, t.then(function(n) {
            e._status === 0 && (n = n.default, e._status = 1, e._result = n)
        }, function(n) {
            e._status === 0 && (e._status = 2, e._result = n)
        })
    }
    if (e._status === 1) return e._result;
    throw e._result
}
var so = {
    current: null
};

function Re() {
    var e = so.current;
    if (e === null) throw Error(pn(321));
    return e
}
var Ff = {
    ReactCurrentDispatcher: so,
    ReactCurrentBatchConfig: {
        transition: 0
    },
    ReactCurrentOwner: Mi,
    IsSomeRendererActing: {
        current: !1
    },
    assign: _i
};
A.Children = {
    map: hr,
    forEach: function(e, t, n) {
        hr(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return hr(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return hr(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!Ni(e)) throw Error(pn(143));
        return e
    }
};
A.Component = Dt;
A.PureComponent = Li;
A.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ff;
A.cloneElement = function(e, t, n) {
    if (e == null) throw Error(pn(267, e));
    var r = _i({}, e.props),
        i = e.key,
        l = e.ref,
        s = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (l = t.ref, s = Mi.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var a = e.type.defaultProps;
        for (o in t) no.call(t, o) && !ro.hasOwnProperty(o) && (r[o] = t[o] === void 0 && a !== void 0 ? a[o] : t[o])
    }
    var o = arguments.length - 2;
    if (o === 1) r.children = n;
    else if (1 < o) {
        a = Array(o);
        for (var f = 0; f < o; f++) a[f] = arguments[f + 2];
        r.children = a
    }
    return {
        $$typeof: $t,
        type: e.type,
        key: i,
        ref: l,
        props: r,
        _owner: s
    }
};
A.createContext = function(e, t) {
    return t === void 0 && (t = null), e = {
        $$typeof: Xs,
        _calculateChangedBits: t,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null
    }, e.Provider = {
        $$typeof: bs,
        _context: e
    }, e.Consumer = e
};
A.createElement = io;
A.createFactory = function(e) {
    var t = io.bind(null, e);
    return t.type = e, t
};
A.createRef = function() {
    return {
        current: null
    }
};
A.forwardRef = function(e) {
    return {
        $$typeof: Qs,
        render: e
    }
};
A.isValidElement = Ni;
A.lazy = function(e) {
    return {
        $$typeof: Ks,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: Af
    }
};
A.memo = function(e, t) {
    return {
        $$typeof: qs,
        type: e,
        compare: t === void 0 ? null : t
    }
};
A.useCallback = function(e, t) {
    return Re().useCallback(e, t)
};
A.useContext = function(e, t) {
    return Re().useContext(e, t)
};
A.useDebugValue = function() {};
A.useEffect = function(e, t) {
    return Re().useEffect(e, t)
};
A.useImperativeHandle = function(e, t, n) {
    return Re().useImperativeHandle(e, t, n)
};
A.useLayoutEffect = function(e, t) {
    return Re().useLayoutEffect(e, t)
};
A.useMemo = function(e, t) {
    return Re().useMemo(e, t)
};
A.useReducer = function(e, t, n) {
    return Re().useReducer(e, t, n)
};
A.useRef = function(e) {
    return Re().useRef(e)
};
A.useState = function(e) {
    return Re().useState(e)
};
A.version = "17.0.2";
R.exports = A;
var gt = R.exports,
    oo = {
        exports: {}
    },
    we = {},
    ao = {
        exports: {}
    },
    uo = {};
/** @license React v0.20.2
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    var t, n, r, i;
    if (typeof performance == "object" && typeof performance.now == "function") {
        var l = performance;
        e.unstable_now = function() {
            return l.now()
        }
    } else {
        var s = Date,
            a = s.now();
        e.unstable_now = function() {
            return s.now() - a
        }
    }
    if (typeof window == "undefined" || typeof MessageChannel != "function") {
        var o = null,
            f = null,
            d = function() {
                if (o !== null) try {
                    var k = e.unstable_now();
                    o(!0, k), o = null
                } catch (I) {
                    throw setTimeout(d, 0), I
                }
            };
        t = function(k) {
            o !== null ? setTimeout(t, 0, k) : (o = k, setTimeout(d, 0))
        }, n = function(k, I) {
            f = setTimeout(k, I)
        }, r = function() {
            clearTimeout(f)
        }, e.unstable_shouldYield = function() {
            return !1
        }, i = e.unstable_forceFrameRate = function() {}
    } else {
        var m = window.setTimeout,
            h = window.clearTimeout;
        if (typeof console != "undefined") {
            var y = window.cancelAnimationFrame;
            typeof window.requestAnimationFrame != "function" && console.error("This browser doesn't support requestAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills"), typeof y != "function" && console.error("This browser doesn't support cancelAnimationFrame. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills")
        }
        var S = !1,
            E = null,
            c = -1,
            u = 5,
            p = 0;
        e.unstable_shouldYield = function() {
            return e.unstable_now() >= p
        }, i = function() {}, e.unstable_forceFrameRate = function(k) {
            0 > k || 125 < k ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : u = 0 < k ? Math.floor(1e3 / k) : 5
        };
        var g = new MessageChannel,
            v = g.port2;
        g.port1.onmessage = function() {
            if (E !== null) {
                var k = e.unstable_now();
                p = k + u;
                try {
                    E(!0, k) ? v.postMessage(null) : (S = !1, E = null)
                } catch (I) {
                    throw v.postMessage(null), I
                }
            } else S = !1
        }, t = function(k) {
            E = k, S || (S = !0, v.postMessage(null))
        }, n = function(k, I) {
            c = m(function() {
                k(e.unstable_now())
            }, I)
        }, r = function() {
            h(c), c = -1
        }
    }

    function T(k, I) {
        var D = k.length;
        k.push(I);
        e: for (;;) {
            var G = D - 1 >>> 1,
                J = k[G];
            if (J !== void 0 && 0 < x(J, I)) k[G] = I, k[D] = J, D = G;
            else break e
        }
    }

    function w(k) {
        return k = k[0], k === void 0 ? null : k
    }

    function P(k) {
        var I = k[0];
        if (I !== void 0) {
            var D = k.pop();
            if (D !== I) {
                k[0] = D;
                e: for (var G = 0, J = k.length; G < J;) {
                    var ht = 2 * (G + 1) - 1,
                        mt = k[ht],
                        dn = ht + 1,
                        It = k[dn];
                    if (mt !== void 0 && 0 > x(mt, D)) It !== void 0 && 0 > x(It, mt) ? (k[G] = It, k[dn] = D, G = dn) : (k[G] = mt, k[ht] = D, G = ht);
                    else if (It !== void 0 && 0 > x(It, D)) k[G] = It, k[dn] = D, G = dn;
                    else break e
                }
            }
            return I
        }
        return null
    }

    function x(k, I) {
        var D = k.sortIndex - I.sortIndex;
        return D !== 0 ? D : k.id - I.id
    }
    var O = [],
        _ = [],
        z = 1,
        N = null,
        F = 3,
        b = !1,
        me = !1,
        $e = !1;

    function pt(k) {
        for (var I = w(_); I !== null;) {
            if (I.callback === null) P(_);
            else if (I.startTime <= k) P(_), I.sortIndex = I.expirationTime, T(O, I);
            else break;
            I = w(_)
        }
    }

    function Ue(k) {
        if ($e = !1, pt(k), !me)
            if (w(O) !== null) me = !0, t(De);
            else {
                var I = w(_);
                I !== null && n(Ue, I.startTime - k)
            }
    }

    function De(k, I) {
        me = !1, $e && ($e = !1, r()), b = !0;
        var D = F;
        try {
            for (pt(I), N = w(O); N !== null && (!(N.expirationTime > I) || k && !e.unstable_shouldYield());) {
                var G = N.callback;
                if (typeof G == "function") {
                    N.callback = null, F = N.priorityLevel;
                    var J = G(N.expirationTime <= I);
                    I = e.unstable_now(), typeof J == "function" ? N.callback = J : N === w(O) && P(O), pt(I)
                } else P(O);
                N = w(O)
            }
            if (N !== null) var ht = !0;
            else {
                var mt = w(_);
                mt !== null && n(Ue, mt.startTime - I), ht = !1
            }
            return ht
        } finally {
            N = null, F = D, b = !1
        }
    }
    var X = i;
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(k) {
        k.callback = null
    }, e.unstable_continueExecution = function() {
        me || b || (me = !0, t(De))
    }, e.unstable_getCurrentPriorityLevel = function() {
        return F
    }, e.unstable_getFirstCallbackNode = function() {
        return w(O)
    }, e.unstable_next = function(k) {
        switch (F) {
            case 1:
            case 2:
            case 3:
                var I = 3;
                break;
            default:
                I = F
        }
        var D = F;
        F = I;
        try {
            return k()
        } finally {
            F = D
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = X, e.unstable_runWithPriority = function(k, I) {
        switch (k) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                k = 3
        }
        var D = F;
        F = k;
        try {
            return I()
        } finally {
            F = D
        }
    }, e.unstable_scheduleCallback = function(k, I, D) {
        var G = e.unstable_now();
        switch (typeof D == "object" && D !== null ? (D = D.delay, D = typeof D == "number" && 0 < D ? G + D : G) : D = G, k) {
            case 1:
                var J = -1;
                break;
            case 2:
                J = 250;
                break;
            case 5:
                J = 1073741823;
                break;
            case 4:
                J = 1e4;
                break;
            default:
                J = 5e3
        }
        return J = D + J, k = {
            id: z++,
            callback: I,
            priorityLevel: k,
            startTime: D,
            expirationTime: J,
            sortIndex: -1
        }, D > G ? (k.sortIndex = D, T(_, k), w(O) === null && k === w(_) && ($e ? r() : $e = !0, n(Ue, D - G))) : (k.sortIndex = J, T(O, k), me || b || (me = !0, t(De))), k
    }, e.unstable_wrapCallback = function(k) {
        var I = F;
        return function() {
            var D = F;
            F = I;
            try {
                return k.apply(this, arguments)
            } finally {
                F = D
            }
        }
    }
})(uo);
ao.exports = uo;
/** @license React v17.0.2
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var mr = R.exports,
    H = Gs,
    q = ao.exports;

function C(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
if (!mr) throw Error(C(227));
var fo = new Set,
    hn = {};

function vt(e, t) {
    Rt(e, t), Rt(e + "Capture", t)
}

function Rt(e, t) {
    for (hn[e] = t, e = 0; e < t.length; e++) fo.add(t[e])
}
var Ae = !(typeof window == "undefined" || typeof window.document == "undefined" || typeof window.document.createElement == "undefined"),
    jf = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    co = Object.prototype.hasOwnProperty,
    po = {},
    ho = {};

function Bf(e) {
    return co.call(ho, e) ? !0 : co.call(po, e) ? !1 : jf.test(e) ? ho[e] = !0 : (po[e] = !0, !1)
}

function Vf(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function Hf(e, t, n, r) {
    if (t === null || typeof t == "undefined" || Vf(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function ae(e, t, n, r, i, l, s) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = i, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = l, this.removeEmptyString = s
}
var ee = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    ee[e] = new ae(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    ee[t] = new ae(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    ee[e] = new ae(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    ee[e] = new ae(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    ee[e] = new ae(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    ee[e] = new ae(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    ee[e] = new ae(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    ee[e] = new ae(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    ee[e] = new ae(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var Ii = /[\-:]([a-z])/g;

function $i(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Ii, $i);
    ee[t] = new ae(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Ii, $i);
    ee[t] = new ae(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(Ii, $i);
    ee[t] = new ae(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    ee[e] = new ae(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
ee.xlinkHref = new ae("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    ee[e] = new ae(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function Di(e, t, n, r) {
    var i = ee.hasOwnProperty(t) ? ee[t] : null,
        l = i !== null ? i.type === 0 : r ? !1 : !(!(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N");
    l || (Hf(t, n, i, r) && (n = null), r || i === null ? Bf(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : i.mustUseProperty ? e[i.propertyName] = n === null ? i.type === 3 ? !1 : "" : n : (t = i.attributeName, r = i.attributeNamespace, n === null ? e.removeAttribute(t) : (i = i.type, n = i === 3 || i === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var yt = mr.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    mn = 60103,
    wt = 60106,
    We = 60107,
    Ri = 60108,
    gn = 60114,
    Ai = 60109,
    Fi = 60110,
    gr = 60112,
    vn = 60113,
    vr = 60120,
    yr = 60115,
    ji = 60116,
    Bi = 60121,
    Vi = 60128,
    mo = 60129,
    Hi = 60130,
    Ui = 60131;
if (typeof Symbol == "function" && Symbol.for) {
    var K = Symbol.for;
    mn = K("react.element"), wt = K("react.portal"), We = K("react.fragment"), Ri = K("react.strict_mode"), gn = K("react.profiler"), Ai = K("react.provider"), Fi = K("react.context"), gr = K("react.forward_ref"), vn = K("react.suspense"), vr = K("react.suspense_list"), yr = K("react.memo"), ji = K("react.lazy"), Bi = K("react.block"), K("react.scope"), Vi = K("react.opaque.id"), mo = K("react.debug_trace_mode"), Hi = K("react.offscreen"), Ui = K("react.legacy_hidden")
}
var go = typeof Symbol == "function" && Symbol.iterator;

function yn(e) {
    return e === null || typeof e != "object" ? null : (e = go && e[go] || e["@@iterator"], typeof e == "function" ? e : null)
}
var Wi;

function wn(e) {
    if (Wi === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        Wi = t && t[1] || ""
    }
    return `
` + Wi + e
}
var Gi = !1;

function wr(e, t) {
    if (!e || Gi) return "";
    Gi = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (o) {
                    var r = o
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (o) {
                    r = o
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (o) {
                r = o
            }
            e()
        }
    } catch (o) {
        if (o && r && typeof o.stack == "string") {
            for (var i = o.stack.split(`
`), l = r.stack.split(`
`), s = i.length - 1, a = l.length - 1; 1 <= s && 0 <= a && i[s] !== l[a];) a--;
            for (; 1 <= s && 0 <= a; s--, a--)
                if (i[s] !== l[a]) {
                    if (s !== 1 || a !== 1)
                        do
                            if (s--, a--, 0 > a || i[s] !== l[a]) return `
` + i[s].replace(" at new ", " at "); while (1 <= s && 0 <= a);
                    break
                }
        }
    } finally {
        Gi = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? wn(e) : ""
}

function Uf(e) {
    switch (e.tag) {
        case 5:
            return wn(e.type);
        case 16:
            return wn("Lazy");
        case 13:
            return wn("Suspense");
        case 19:
            return wn("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = wr(e.type, !1), e;
        case 11:
            return e = wr(e.type.render, !1), e;
        case 22:
            return e = wr(e.type._render, !1), e;
        case 1:
            return e = wr(e.type, !0), e;
        default:
            return ""
    }
}

function At(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case We:
            return "Fragment";
        case wt:
            return "Portal";
        case gn:
            return "Profiler";
        case Ri:
            return "StrictMode";
        case vn:
            return "Suspense";
        case vr:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case Fi:
            return (e.displayName || "Context") + ".Consumer";
        case Ai:
            return (e._context.displayName || "Context") + ".Provider";
        case gr:
            var t = e.render;
            return t = t.displayName || t.name || "", e.displayName || (t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef");
        case yr:
            return At(e.type);
        case Bi:
            return At(e._render);
        case ji:
            t = e._payload, e = e._init;
            try {
                return At(e(t))
            } catch {}
    }
    return null
}

function Ge(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "object":
        case "string":
        case "undefined":
            return e;
        default:
            return ""
    }
}

function vo(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function Wf(e) {
    var t = vo(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n != "undefined" && typeof n.get == "function" && typeof n.set == "function") {
        var i = n.get,
            l = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return i.call(this)
            },
            set: function(s) {
                r = "" + s, l.call(this, s)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(s) {
                r = "" + s
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function Sr(e) {
    e._valueTracker || (e._valueTracker = Wf(e))
}

function yo(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = vo(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Er(e) {
    if (e = e || (typeof document != "undefined" ? document : void 0), typeof e == "undefined") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function Yi(e, t) {
    var n = t.checked;
    return H({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n != null ? n : e._wrapperState.initialChecked
    })
}

function wo(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = Ge(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function So(e, t) {
    t = t.checked, t != null && Di(e, "checked", t, !1)
}

function bi(e, t) {
    So(e, t);
    var n = Ge(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? Xi(e, t.type, n) : t.hasOwnProperty("defaultValue") && Xi(e, t.type, Ge(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function Eo(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function Xi(e, t, n) {
    (t !== "number" || Er(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}

function Gf(e) {
    var t = "";
    return mr.Children.forEach(e, function(n) {
        n != null && (t += n)
    }), t
}

function Qi(e, t) {
    return e = H({
        children: void 0
    }, t), (t = Gf(t.children)) && (e.children = t), e
}

function Ft(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
        for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + Ge(n), t = null, i = 0; i < e.length; i++) {
            if (e[i].value === n) {
                e[i].selected = !0, r && (e[i].defaultSelected = !0);
                return
            }
            t !== null || e[i].disabled || (t = e[i])
        }
        t !== null && (t.selected = !0)
    }
}

function qi(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(C(91));
    return H({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function Co(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(C(92));
            if (Array.isArray(n)) {
                if (!(1 >= n.length)) throw Error(C(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: Ge(n)
    }
}

function xo(e, t) {
    var n = Ge(t.value),
        r = Ge(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function To(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}
var Ki = {
    html: "http://www.w3.org/1999/xhtml",
    mathml: "http://www.w3.org/1998/Math/MathML",
    svg: "http://www.w3.org/2000/svg"
};

function ko(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function Zi(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? ko(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var Cr, Po = function(e) {
    return typeof MSApp != "undefined" && MSApp.execUnsafeLocalFunction ? function(t, n, r, i) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, i)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== Ki.svg || "innerHTML" in e) e.innerHTML = t;
    else {
        for (Cr = Cr || document.createElement("div"), Cr.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = Cr.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function Sn(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var En = {
        animationIterationCount: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    Yf = ["Webkit", "ms", "Moz", "O"];
Object.keys(En).forEach(function(e) {
    Yf.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), En[t] = En[e]
    })
});

function _o(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || En.hasOwnProperty(e) && En[e] ? ("" + t).trim() : t + "px"
}

function Lo(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                i = _o(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, i) : e[n] = i
        }
}
var bf = H({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function Ji(e, t) {
    if (t) {
        if (bf[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(C(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(C(60));
            if (!(typeof t.dangerouslySetInnerHTML == "object" && "__html" in t.dangerouslySetInnerHTML)) throw Error(C(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(C(62))
    }
}

function el(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}

function tl(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var nl = null,
    jt = null,
    Bt = null;

function Oo(e) {
    if (e = Bn(e)) {
        if (typeof nl != "function") throw Error(C(280));
        var t = e.stateNode;
        t && (t = Br(t), nl(e.stateNode, e.type, t))
    }
}

function Mo(e) {
    jt ? Bt ? Bt.push(e) : Bt = [e] : jt = e
}

function No() {
    if (jt) {
        var e = jt,
            t = Bt;
        if (Bt = jt = null, Oo(e), t)
            for (e = 0; e < t.length; e++) Oo(t[e])
    }
}

function rl(e, t) {
    return e(t)
}

function zo(e, t, n, r, i) {
    return e(t, n, r, i)
}

function il() {}
var Io = rl,
    St = !1,
    ll = !1;

function sl() {
    (jt !== null || Bt !== null) && (il(), No())
}

function Xf(e, t, n) {
    if (ll) return e(t, n);
    ll = !0;
    try {
        return Io(e, t, n)
    } finally {
        ll = !1, sl()
    }
}

function Cn(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Br(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(C(231, t, typeof n));
    return n
}
var ol = !1;
if (Ae) try {
    var xn = {};
    Object.defineProperty(xn, "passive", {
        get: function() {
            ol = !0
        }
    }), window.addEventListener("test", xn, xn), window.removeEventListener("test", xn, xn)
} catch {
    ol = !1
}

function Qf(e, t, n, r, i, l, s, a, o) {
    var f = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, f)
    } catch (d) {
        this.onError(d)
    }
}
var Tn = !1,
    xr = null,
    Tr = !1,
    al = null,
    qf = {
        onError: function(e) {
            Tn = !0, xr = e
        }
    };

function Kf(e, t, n, r, i, l, s, a, o) {
    Tn = !1, xr = null, Qf.apply(qf, arguments)
}

function Zf(e, t, n, r, i, l, s, a, o) {
    if (Kf.apply(this, arguments), Tn) {
        if (Tn) {
            var f = xr;
            Tn = !1, xr = null
        } else throw Error(C(198));
        Tr || (Tr = !0, al = f)
    }
}

function Et(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, (t.flags & 1026) != 0 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function $o(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function Do(e) {
    if (Et(e) !== e) throw Error(C(188))
}

function Jf(e) {
    var t = e.alternate;
    if (!t) {
        if (t = Et(e), t === null) throw Error(C(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var i = n.return;
        if (i === null) break;
        var l = i.alternate;
        if (l === null) {
            if (r = i.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (i.child === l.child) {
            for (l = i.child; l;) {
                if (l === n) return Do(i), e;
                if (l === r) return Do(i), t;
                l = l.sibling
            }
            throw Error(C(188))
        }
        if (n.return !== r.return) n = i, r = l;
        else {
            for (var s = !1, a = i.child; a;) {
                if (a === n) {
                    s = !0, n = i, r = l;
                    break
                }
                if (a === r) {
                    s = !0, r = i, n = l;
                    break
                }
                a = a.sibling
            }
            if (!s) {
                for (a = l.child; a;) {
                    if (a === n) {
                        s = !0, n = l, r = i;
                        break
                    }
                    if (a === r) {
                        s = !0, r = l, n = i;
                        break
                    }
                    a = a.sibling
                }
                if (!s) throw Error(C(189))
            }
        }
        if (n.alternate !== r) throw Error(C(190))
    }
    if (n.tag !== 3) throw Error(C(188));
    return n.stateNode.current === n ? e : t
}

function Ro(e) {
    if (e = Jf(e), !e) return null;
    for (var t = e;;) {
        if (t.tag === 5 || t.tag === 6) return t;
        if (t.child) t.child.return = t, t = t.child;
        else {
            if (t === e) break;
            for (; !t.sibling;) {
                if (!t.return || t.return === e) return null;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return null
}

function Ao(e, t) {
    for (var n = e.alternate; t !== null;) {
        if (t === e || t === n) return !0;
        t = t.return
    }
    return !1
}
var Fo, ul, jo, Bo, fl = !1,
    Le = [],
    Ye = null,
    be = null,
    Xe = null,
    kn = new Map,
    Pn = new Map,
    _n = [],
    Vo = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function cl(e, t, n, r, i) {
    return {
        blockedOn: e,
        domEventName: t,
        eventSystemFlags: n | 16,
        nativeEvent: i,
        targetContainers: [r]
    }
}

function Ho(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            Ye = null;
            break;
        case "dragenter":
        case "dragleave":
            be = null;
            break;
        case "mouseover":
        case "mouseout":
            Xe = null;
            break;
        case "pointerover":
        case "pointerout":
            kn.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            Pn.delete(t.pointerId)
    }
}

function Ln(e, t, n, r, i, l) {
    return e === null || e.nativeEvent !== l ? (e = cl(t, n, r, i, l), t !== null && (t = Bn(t), t !== null && ul(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
}

function ec(e, t, n, r, i) {
    switch (t) {
        case "focusin":
            return Ye = Ln(Ye, e, t, n, r, i), !0;
        case "dragenter":
            return be = Ln(be, e, t, n, r, i), !0;
        case "mouseover":
            return Xe = Ln(Xe, e, t, n, r, i), !0;
        case "pointerover":
            var l = i.pointerId;
            return kn.set(l, Ln(kn.get(l) || null, e, t, n, r, i)), !0;
        case "gotpointercapture":
            return l = i.pointerId, Pn.set(l, Ln(Pn.get(l) || null, e, t, n, r, i)), !0
    }
    return !1
}

function tc(e) {
    var t = Ct(e.target);
    if (t !== null) {
        var n = Et(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = $o(n), t !== null) {
                    e.blockedOn = t, Bo(e.lanePriority, function() {
                        q.unstable_runWithPriority(e.priority, function() {
                            jo(n)
                        })
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.hydrate) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function kr(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = vl(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n !== null) return t = Bn(n), t !== null && ul(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function Uo(e, t, n) {
    kr(e) && n.delete(t)
}

function nc() {
    for (fl = !1; 0 < Le.length;) {
        var e = Le[0];
        if (e.blockedOn !== null) {
            e = Bn(e.blockedOn), e !== null && Fo(e);
            break
        }
        for (var t = e.targetContainers; 0 < t.length;) {
            var n = vl(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
            if (n !== null) {
                e.blockedOn = n;
                break
            }
            t.shift()
        }
        e.blockedOn === null && Le.shift()
    }
    Ye !== null && kr(Ye) && (Ye = null), be !== null && kr(be) && (be = null), Xe !== null && kr(Xe) && (Xe = null), kn.forEach(Uo), Pn.forEach(Uo)
}

function On(e, t) {
    e.blockedOn === t && (e.blockedOn = null, fl || (fl = !0, q.unstable_scheduleCallback(q.unstable_NormalPriority, nc)))
}

function Wo(e) {
    function t(i) {
        return On(i, e)
    }
    if (0 < Le.length) {
        On(Le[0], e);
        for (var n = 1; n < Le.length; n++) {
            var r = Le[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (Ye !== null && On(Ye, e), be !== null && On(be, e), Xe !== null && On(Xe, e), kn.forEach(t), Pn.forEach(t), n = 0; n < _n.length; n++) r = _n[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < _n.length && (n = _n[0], n.blockedOn === null);) tc(n), n.blockedOn === null && _n.shift()
}

function Pr(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var Vt = {
        animationend: Pr("Animation", "AnimationEnd"),
        animationiteration: Pr("Animation", "AnimationIteration"),
        animationstart: Pr("Animation", "AnimationStart"),
        transitionend: Pr("Transition", "TransitionEnd")
    },
    dl = {},
    Go = {};
Ae && (Go = document.createElement("div").style, "AnimationEvent" in window || (delete Vt.animationend.animation, delete Vt.animationiteration.animation, delete Vt.animationstart.animation), "TransitionEvent" in window || delete Vt.transitionend.transition);

function _r(e) {
    if (dl[e]) return dl[e];
    if (!Vt[e]) return e;
    var t = Vt[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in Go) return dl[e] = t[n];
    return e
}
var Yo = _r("animationend"),
    bo = _r("animationiteration"),
    Xo = _r("animationstart"),
    Qo = _r("transitionend"),
    qo = new Map,
    pl = new Map,
    rc = ["abort", "abort", Yo, "animationEnd", bo, "animationIteration", Xo, "animationStart", "canplay", "canPlay", "canplaythrough", "canPlayThrough", "durationchange", "durationChange", "emptied", "emptied", "encrypted", "encrypted", "ended", "ended", "error", "error", "gotpointercapture", "gotPointerCapture", "load", "load", "loadeddata", "loadedData", "loadedmetadata", "loadedMetadata", "loadstart", "loadStart", "lostpointercapture", "lostPointerCapture", "playing", "playing", "progress", "progress", "seeking", "seeking", "stalled", "stalled", "suspend", "suspend", "timeupdate", "timeUpdate", Qo, "transitionEnd", "waiting", "waiting"];

function hl(e, t) {
    for (var n = 0; n < e.length; n += 2) {
        var r = e[n],
            i = e[n + 1];
        i = "on" + (i[0].toUpperCase() + i.slice(1)), pl.set(r, t), qo.set(r, i), vt(i, [r])
    }
}
var ic = q.unstable_now;
ic();
var j = 8;

function Ht(e) {
    if ((1 & e) != 0) return j = 15, 1;
    if ((2 & e) != 0) return j = 14, 2;
    if ((4 & e) != 0) return j = 13, 4;
    var t = 24 & e;
    return t !== 0 ? (j = 12, t) : (e & 32) != 0 ? (j = 11, 32) : (t = 192 & e, t !== 0 ? (j = 10, t) : (e & 256) != 0 ? (j = 9, 256) : (t = 3584 & e, t !== 0 ? (j = 8, t) : (e & 4096) != 0 ? (j = 7, 4096) : (t = 4186112 & e, t !== 0 ? (j = 6, t) : (t = 62914560 & e, t !== 0 ? (j = 5, t) : e & 67108864 ? (j = 4, 67108864) : (e & 134217728) != 0 ? (j = 3, 134217728) : (t = 805306368 & e, t !== 0 ? (j = 2, t) : (1073741824 & e) != 0 ? (j = 1, 1073741824) : (j = 8, e))))))
}

function lc(e) {
    switch (e) {
        case 99:
            return 15;
        case 98:
            return 10;
        case 97:
        case 96:
            return 8;
        case 95:
            return 2;
        default:
            return 0
    }
}

function sc(e) {
    switch (e) {
        case 15:
        case 14:
            return 99;
        case 13:
        case 12:
        case 11:
        case 10:
            return 98;
        case 9:
        case 8:
        case 7:
        case 6:
        case 4:
        case 5:
            return 97;
        case 3:
        case 2:
        case 1:
            return 95;
        case 0:
            return 90;
        default:
            throw Error(C(358, e))
    }
}

function Mn(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return j = 0;
    var r = 0,
        i = 0,
        l = e.expiredLanes,
        s = e.suspendedLanes,
        a = e.pingedLanes;
    if (l !== 0) r = l, i = j = 15;
    else if (l = n & 134217727, l !== 0) {
        var o = l & ~s;
        o !== 0 ? (r = Ht(o), i = j) : (a &= l, a !== 0 && (r = Ht(a), i = j))
    } else l = n & ~s, l !== 0 ? (r = Ht(l), i = j) : a !== 0 && (r = Ht(a), i = j);
    if (r === 0) return 0;
    if (r = 31 - Qe(r), r = n & ((0 > r ? 0 : 1 << r) << 1) - 1, t !== 0 && t !== r && (t & s) == 0) {
        if (Ht(t), i <= j) return t;
        j = i
    }
    if (t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - Qe(t), i = 1 << n, r |= e[n], t &= ~i;
    return r
}

function Ko(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function Lr(e, t) {
    switch (e) {
        case 15:
            return 1;
        case 14:
            return 2;
        case 12:
            return e = Ut(24 & ~t), e === 0 ? Lr(10, t) : e;
        case 10:
            return e = Ut(192 & ~t), e === 0 ? Lr(8, t) : e;
        case 8:
            return e = Ut(3584 & ~t), e === 0 && (e = Ut(4186112 & ~t), e === 0 && (e = 512)), e;
        case 2:
            return t = Ut(805306368 & ~t), t === 0 && (t = 268435456), t
    }
    throw Error(C(358, e))
}

function Ut(e) {
    return e & -e
}

function ml(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function Or(e, t, n) {
    e.pendingLanes |= t;
    var r = t - 1;
    e.suspendedLanes &= r, e.pingedLanes &= r, e = e.eventTimes, t = 31 - Qe(t), e[t] = n
}
var Qe = Math.clz32 ? Math.clz32 : uc,
    oc = Math.log,
    ac = Math.LN2;

function uc(e) {
    return e === 0 ? 32 : 31 - (oc(e) / ac | 0) | 0
}
var fc = q.unstable_UserBlockingPriority,
    cc = q.unstable_runWithPriority,
    Mr = !0;

function dc(e, t, n, r) {
    St || il();
    var i = gl,
        l = St;
    St = !0;
    try {
        zo(i, e, t, n, r)
    } finally {
        (St = l) || sl()
    }
}

function pc(e, t, n, r) {
    cc(fc, gl.bind(null, e, t, n, r))
}

function gl(e, t, n, r) {
    if (Mr) {
        var i;
        if ((i = (t & 4) == 0) && 0 < Le.length && -1 < Vo.indexOf(e)) e = cl(null, e, t, n, r), Le.push(e);
        else {
            var l = vl(e, t, n, r);
            if (l === null) i && Ho(e, r);
            else {
                if (i) {
                    if (-1 < Vo.indexOf(e)) {
                        e = cl(l, e, t, n, r), Le.push(e);
                        return
                    }
                    if (ec(l, e, t, n, r)) return;
                    Ho(e, r)
                }
                _a(e, t, r, null, n)
            }
        }
    }
}

function vl(e, t, n, r) {
    var i = tl(r);
    if (i = Ct(i), i !== null) {
        var l = Et(i);
        if (l === null) i = null;
        else {
            var s = l.tag;
            if (s === 13) {
                if (i = $o(l), i !== null) return i;
                i = null
            } else if (s === 3) {
                if (l.stateNode.hydrate) return l.tag === 3 ? l.stateNode.containerInfo : null;
                i = null
            } else l !== i && (i = null)
        }
    }
    return _a(e, t, r, i, n), null
}
var qe = null,
    yl = null,
    Nr = null;

function Zo() {
    if (Nr) return Nr;
    var e, t = yl,
        n = t.length,
        r, i = "value" in qe ? qe.value : qe.textContent,
        l = i.length;
    for (e = 0; e < n && t[e] === i[e]; e++);
    var s = n - e;
    for (r = 1; r <= s && t[n - r] === i[l - r]; r++);
    return Nr = i.slice(e, 1 < r ? 1 - r : void 0)
}

function zr(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function Ir() {
    return !0
}

function Jo() {
    return !1
}

function ge(e) {
    function t(n, r, i, l, s) {
        this._reactName = n, this._targetInst = i, this.type = r, this.nativeEvent = l, this.target = s, this.currentTarget = null;
        for (var a in e) e.hasOwnProperty(a) && (n = e[a], this[a] = n ? n(l) : l[a]);
        return this.isDefaultPrevented = (l.defaultPrevented != null ? l.defaultPrevented : l.returnValue === !1) ? Ir : Jo, this.isPropagationStopped = Jo, this
    }
    return H(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Ir)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Ir)
        },
        persist: function() {},
        isPersistent: Ir
    }), t
}
var Wt = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    wl = ge(Wt),
    Nn = H({}, Wt, {
        view: 0,
        detail: 0
    }),
    hc = ge(Nn),
    Sl, El, zn, $r = H({}, Nn, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: xl,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== zn && (zn && e.type === "mousemove" ? (Sl = e.screenX - zn.screenX, El = e.screenY - zn.screenY) : El = Sl = 0, zn = e), Sl)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : El
        }
    }),
    ea = ge($r),
    mc = H({}, $r, {
        dataTransfer: 0
    }),
    gc = ge(mc),
    vc = H({}, Nn, {
        relatedTarget: 0
    }),
    Cl = ge(vc),
    yc = H({}, Wt, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    wc = ge(yc),
    Sc = H({}, Wt, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    Ec = ge(Sc),
    Cc = H({}, Wt, {
        data: 0
    }),
    ta = ge(Cc),
    xc = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    Tc = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    kc = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function Pc(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = kc[e]) ? !!t[e] : !1
}

function xl() {
    return Pc
}
var _c = H({}, Nn, {
        key: function(e) {
            if (e.key) {
                var t = xc[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = zr(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? Tc[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: xl,
        charCode: function(e) {
            return e.type === "keypress" ? zr(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? zr(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    Lc = ge(_c),
    Oc = H({}, $r, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    na = ge(Oc),
    Mc = H({}, Nn, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: xl
    }),
    Nc = ge(Mc),
    zc = H({}, Wt, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    Ic = ge(zc),
    $c = H({}, $r, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    Dc = ge($c),
    Rc = [9, 13, 27, 32],
    Tl = Ae && "CompositionEvent" in window,
    In = null;
Ae && "documentMode" in document && (In = document.documentMode);
var Ac = Ae && "TextEvent" in window && !In,
    ra = Ae && (!Tl || In && 8 < In && 11 >= In),
    ia = String.fromCharCode(32),
    la = !1;

function sa(e, t) {
    switch (e) {
        case "keyup":
            return Rc.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function oa(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var Gt = !1;

function Fc(e, t) {
    switch (e) {
        case "compositionend":
            return oa(t);
        case "keypress":
            return t.which !== 32 ? null : (la = !0, ia);
        case "textInput":
            return e = t.data, e === ia && la ? null : e;
        default:
            return null
    }
}

function jc(e, t) {
    if (Gt) return e === "compositionend" || !Tl && sa(e, t) ? (e = Zo(), Nr = yl = qe = null, Gt = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return ra && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var Bc = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function aa(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!Bc[e.type] : t === "textarea"
}

function ua(e, t, n, r) {
    Mo(r), t = Rr(t, "onChange"), 0 < t.length && (n = new wl("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var $n = null,
    Dn = null;

function Vc(e) {
    Ca(e, 0)
}

function Dr(e) {
    var t = qt(e);
    if (yo(t)) return e
}

function Hc(e, t) {
    if (e === "change") return t
}
var fa = !1;
if (Ae) {
    var kl;
    if (Ae) {
        var Pl = "oninput" in document;
        if (!Pl) {
            var ca = document.createElement("div");
            ca.setAttribute("oninput", "return;"), Pl = typeof ca.oninput == "function"
        }
        kl = Pl
    } else kl = !1;
    fa = kl && (!document.documentMode || 9 < document.documentMode)
}

function da() {
    $n && ($n.detachEvent("onpropertychange", pa), Dn = $n = null)
}

function pa(e) {
    if (e.propertyName === "value" && Dr(Dn)) {
        var t = [];
        if (ua(t, Dn, e, tl(e)), e = Vc, St) e(t);
        else {
            St = !0;
            try {
                rl(e, t)
            } finally {
                St = !1, sl()
            }
        }
    }
}

function Uc(e, t, n) {
    e === "focusin" ? (da(), $n = t, Dn = n, $n.attachEvent("onpropertychange", pa)) : e === "focusout" && da()
}

function Wc(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return Dr(Dn)
}

function Gc(e, t) {
    if (e === "click") return Dr(t)
}

function Yc(e, t) {
    if (e === "input" || e === "change") return Dr(t)
}

function bc(e, t) {
    return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
}
var Se = typeof Object.is == "function" ? Object.is : bc,
    Xc = Object.prototype.hasOwnProperty;

function Rn(e, t) {
    if (Se(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++)
        if (!Xc.call(t, n[r]) || !Se(e[n[r]], t[n[r]])) return !1;
    return !0
}

function ha(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function ma(e, t) {
    var n = ha(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = ha(n)
    }
}

function ga(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? ga(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function va() {
    for (var e = window, t = Er(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Er(e.document)
    }
    return t
}

function _l(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}
var Qc = Ae && "documentMode" in document && 11 >= document.documentMode,
    Yt = null,
    Ll = null,
    An = null,
    Ol = !1;

function ya(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Ol || Yt == null || Yt !== Er(r) || (r = Yt, "selectionStart" in r && _l(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), An && Rn(An, r) || (An = r, r = Rr(Ll, "onSelect"), 0 < r.length && (t = new wl("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = Yt)))
}
hl("cancel cancel click click close close contextmenu contextMenu copy copy cut cut auxclick auxClick dblclick doubleClick dragend dragEnd dragstart dragStart drop drop focusin focus focusout blur input input invalid invalid keydown keyDown keypress keyPress keyup keyUp mousedown mouseDown mouseup mouseUp paste paste pause pause play play pointercancel pointerCancel pointerdown pointerDown pointerup pointerUp ratechange rateChange reset reset seeked seeked submit submit touchcancel touchCancel touchend touchEnd touchstart touchStart volumechange volumeChange".split(" "), 0);
hl("drag drag dragenter dragEnter dragexit dragExit dragleave dragLeave dragover dragOver mousemove mouseMove mouseout mouseOut mouseover mouseOver pointermove pointerMove pointerout pointerOut pointerover pointerOver scroll scroll toggle toggle touchmove touchMove wheel wheel".split(" "), 1);
hl(rc, 2);
for (var wa = "change selectionchange textInput compositionstart compositionend compositionupdate".split(" "), Ml = 0; Ml < wa.length; Ml++) pl.set(wa[Ml], 0);
Rt("onMouseEnter", ["mouseout", "mouseover"]);
Rt("onMouseLeave", ["mouseout", "mouseover"]);
Rt("onPointerEnter", ["pointerout", "pointerover"]);
Rt("onPointerLeave", ["pointerout", "pointerover"]);
vt("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
vt("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
vt("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
vt("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
vt("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
vt("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var Fn = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    Sa = new Set("cancel close invalid load scroll toggle".split(" ").concat(Fn));

function Ea(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, Zf(r, t, void 0, e), e.currentTarget = null
}

function Ca(e, t) {
    t = (t & 4) != 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            i = r.event;
        r = r.listeners;
        e: {
            var l = void 0;
            if (t)
                for (var s = r.length - 1; 0 <= s; s--) {
                    var a = r[s],
                        o = a.instance,
                        f = a.currentTarget;
                    if (a = a.listener, o !== l && i.isPropagationStopped()) break e;
                    Ea(i, a, f), l = o
                } else
                    for (s = 0; s < r.length; s++) {
                        if (a = r[s], o = a.instance, f = a.currentTarget, a = a.listener, o !== l && i.isPropagationStopped()) break e;
                        Ea(i, a, f), l = o
                    }
        }
    }
    if (Tr) throw e = al, Tr = !1, al = null, e
}

function B(e, t) {
    var n = Ia(t),
        r = e + "__bubble";
    n.has(r) || (Pa(t, e, 2, !1), n.add(r))
}
var xa = "_reactListening" + Math.random().toString(36).slice(2);

function Ta(e) {
    e[xa] || (e[xa] = !0, fo.forEach(function(t) {
        Sa.has(t) || ka(t, !1, e, null), ka(t, !0, e, null)
    }))
}

function ka(e, t, n, r) {
    var i = 4 < arguments.length && arguments[4] !== void 0 ? arguments[4] : 0,
        l = n;
    if (e === "selectionchange" && n.nodeType !== 9 && (l = n.ownerDocument), r !== null && !t && Sa.has(e)) {
        if (e !== "scroll") return;
        i |= 2, l = r
    }
    var s = Ia(l),
        a = e + "__" + (t ? "capture" : "bubble");
    s.has(a) || (t && (i |= 4), Pa(l, e, i, t), s.add(a))
}

function Pa(e, t, n, r) {
    var i = pl.get(t);
    switch (i === void 0 ? 2 : i) {
        case 0:
            i = dc;
            break;
        case 1:
            i = pc;
            break;
        default:
            i = gl
    }
    n = i.bind(null, t, n, e), i = void 0, !ol || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), r ? i !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: i
    }) : e.addEventListener(t, n, !0) : i !== void 0 ? e.addEventListener(t, n, {
        passive: i
    }) : e.addEventListener(t, n, !1)
}

function _a(e, t, n, r, i) {
    var l = r;
    if ((t & 1) == 0 && (t & 2) == 0 && r !== null) e: for (;;) {
        if (r === null) return;
        var s = r.tag;
        if (s === 3 || s === 4) {
            var a = r.stateNode.containerInfo;
            if (a === i || a.nodeType === 8 && a.parentNode === i) break;
            if (s === 4)
                for (s = r.return; s !== null;) {
                    var o = s.tag;
                    if ((o === 3 || o === 4) && (o = s.stateNode.containerInfo, o === i || o.nodeType === 8 && o.parentNode === i)) return;
                    s = s.return
                }
            for (; a !== null;) {
                if (s = Ct(a), s === null) return;
                if (o = s.tag, o === 5 || o === 6) {
                    r = l = s;
                    continue e
                }
                a = a.parentNode
            }
        }
        r = r.return
    }
    Xf(function() {
        var f = l,
            d = tl(n),
            m = [];
        e: {
            var h = qo.get(e);
            if (h !== void 0) {
                var y = wl,
                    S = e;
                switch (e) {
                    case "keypress":
                        if (zr(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        y = Lc;
                        break;
                    case "focusin":
                        S = "focus", y = Cl;
                        break;
                    case "focusout":
                        S = "blur", y = Cl;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        y = Cl;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        y = ea;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        y = gc;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        y = Nc;
                        break;
                    case Yo:
                    case bo:
                    case Xo:
                        y = wc;
                        break;
                    case Qo:
                        y = Ic;
                        break;
                    case "scroll":
                        y = hc;
                        break;
                    case "wheel":
                        y = Dc;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        y = Ec;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        y = na
                }
                var E = (t & 4) != 0,
                    c = !E && e === "scroll",
                    u = E ? h !== null ? h + "Capture" : null : h;
                E = [];
                for (var p = f, g; p !== null;) {
                    g = p;
                    var v = g.stateNode;
                    if (g.tag === 5 && v !== null && (g = v, u !== null && (v = Cn(p, u), v != null && E.push(jn(p, v, g)))), c) break;
                    p = p.return
                }
                0 < E.length && (h = new y(h, S, null, n, d), m.push({
                    event: h,
                    listeners: E
                }))
            }
        }
        if ((t & 7) == 0) {
            e: {
                if (h = e === "mouseover" || e === "pointerover", y = e === "mouseout" || e === "pointerout", h && (t & 16) == 0 && (S = n.relatedTarget || n.fromElement) && (Ct(S) || S[Qt])) break e;
                if ((y || h) && (h = d.window === d ? d : (h = d.ownerDocument) ? h.defaultView || h.parentWindow : window, y ? (S = n.relatedTarget || n.toElement, y = f, S = S ? Ct(S) : null, S !== null && (c = Et(S), S !== c || S.tag !== 5 && S.tag !== 6) && (S = null)) : (y = null, S = f), y !== S)) {
                    if (E = ea, v = "onMouseLeave", u = "onMouseEnter", p = "mouse", (e === "pointerout" || e === "pointerover") && (E = na, v = "onPointerLeave", u = "onPointerEnter", p = "pointer"), c = y == null ? h : qt(y), g = S == null ? h : qt(S), h = new E(v, p + "leave", y, n, d), h.target = c, h.relatedTarget = g, v = null, Ct(d) === f && (E = new E(u, p + "enter", S, n, d), E.target = g, E.relatedTarget = c, v = E), c = v, y && S) t: {
                        for (E = y, u = S, p = 0, g = E; g; g = bt(g)) p++;
                        for (g = 0, v = u; v; v = bt(v)) g++;
                        for (; 0 < p - g;) E = bt(E),
                        p--;
                        for (; 0 < g - p;) u = bt(u),
                        g--;
                        for (; p--;) {
                            if (E === u || u !== null && E === u.alternate) break t;
                            E = bt(E), u = bt(u)
                        }
                        E = null
                    }
                    else E = null;
                    y !== null && La(m, h, y, E, !1), S !== null && c !== null && La(m, c, S, E, !0)
                }
            }
            e: {
                if (h = f ? qt(f) : window, y = h.nodeName && h.nodeName.toLowerCase(), y === "select" || y === "input" && h.type === "file") var T = Hc;
                else if (aa(h))
                    if (fa) T = Yc;
                    else {
                        T = Wc;
                        var w = Uc
                    }
                else(y = h.nodeName) && y.toLowerCase() === "input" && (h.type === "checkbox" || h.type === "radio") && (T = Gc);
                if (T && (T = T(e, f))) {
                    ua(m, T, n, d);
                    break e
                }
                w && w(e, h, f),
                e === "focusout" && (w = h._wrapperState) && w.controlled && h.type === "number" && Xi(h, "number", h.value)
            }
            switch (w = f ? qt(f) : window, e) {
                case "focusin":
                    (aa(w) || w.contentEditable === "true") && (Yt = w, Ll = f, An = null);
                    break;
                case "focusout":
                    An = Ll = Yt = null;
                    break;
                case "mousedown":
                    Ol = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    Ol = !1, ya(m, n, d);
                    break;
                case "selectionchange":
                    if (Qc) break;
                case "keydown":
                case "keyup":
                    ya(m, n, d)
            }
            var P;
            if (Tl) e: {
                switch (e) {
                    case "compositionstart":
                        var x = "onCompositionStart";
                        break e;
                    case "compositionend":
                        x = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        x = "onCompositionUpdate";
                        break e
                }
                x = void 0
            }
            else Gt ? sa(e, n) && (x = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (x = "onCompositionStart");x && (ra && n.locale !== "ko" && (Gt || x !== "onCompositionStart" ? x === "onCompositionEnd" && Gt && (P = Zo()) : (qe = d, yl = "value" in qe ? qe.value : qe.textContent, Gt = !0)), w = Rr(f, x), 0 < w.length && (x = new ta(x, e, null, n, d), m.push({
                event: x,
                listeners: w
            }), P ? x.data = P : (P = oa(n), P !== null && (x.data = P)))),
            (P = Ac ? Fc(e, n) : jc(e, n)) && (f = Rr(f, "onBeforeInput"), 0 < f.length && (d = new ta("onBeforeInput", "beforeinput", null, n, d), m.push({
                event: d,
                listeners: f
            }), d.data = P))
        }
        Ca(m, t)
    })
}

function jn(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function Rr(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var i = e,
            l = i.stateNode;
        i.tag === 5 && l !== null && (i = l, l = Cn(e, n), l != null && r.unshift(jn(e, l, i)), l = Cn(e, t), l != null && r.push(jn(e, l, i))), e = e.return
    }
    return r
}

function bt(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function La(e, t, n, r, i) {
    for (var l = t._reactName, s = []; n !== null && n !== r;) {
        var a = n,
            o = a.alternate,
            f = a.stateNode;
        if (o !== null && o === r) break;
        a.tag === 5 && f !== null && (a = f, i ? (o = Cn(n, l), o != null && s.unshift(jn(n, o, a))) : i || (o = Cn(n, l), o != null && s.push(jn(n, o, a)))), n = n.return
    }
    s.length !== 0 && e.push({
        event: t,
        listeners: s
    })
}

function Ar() {}
var Nl = null,
    zl = null;

function Oa(e, t) {
    switch (e) {
        case "button":
        case "input":
        case "select":
        case "textarea":
            return !!t.autoFocus
    }
    return !1
}

function Il(e, t) {
    return e === "textarea" || e === "option" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var Ma = typeof setTimeout == "function" ? setTimeout : void 0,
    qc = typeof clearTimeout == "function" ? clearTimeout : void 0;

function $l(e) {
    e.nodeType === 1 ? e.textContent = "" : e.nodeType === 9 && (e = e.body, e != null && (e.textContent = ""))
}

function Xt(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break
    }
    return e
}

function Na(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var Dl = 0;

function Kc(e) {
    return {
        $$typeof: Vi,
        toString: e,
        valueOf: e
    }
}
var Fr = Math.random().toString(36).slice(2),
    Ke = "__reactFiber$" + Fr,
    jr = "__reactProps$" + Fr,
    Qt = "__reactContainer$" + Fr,
    za = "__reactEvents$" + Fr;

function Ct(e) {
    var t = e[Ke];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[Qt] || n[Ke]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = Na(e); e !== null;) {
                    if (n = e[Ke]) return n;
                    e = Na(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function Bn(e) {
    return e = e[Ke] || e[Qt], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function qt(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(C(33))
}

function Br(e) {
    return e[jr] || null
}

function Ia(e) {
    var t = e[za];
    return t === void 0 && (t = e[za] = new Set), t
}
var Rl = [],
    Kt = -1;

function Ze(e) {
    return {
        current: e
    }
}

function V(e) {
    0 > Kt || (e.current = Rl[Kt], Rl[Kt] = null, Kt--)
}

function U(e, t) {
    Kt++, Rl[Kt] = e.current, e.current = t
}
var Je = {},
    ie = Ze(Je),
    ce = Ze(!1),
    xt = Je;

function Zt(e, t) {
    var n = e.type.contextTypes;
    if (!n) return Je;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var i = {},
        l;
    for (l in n) i[l] = t[l];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i
}

function de(e) {
    return e = e.childContextTypes, e != null
}

function Vr() {
    V(ce), V(ie)
}

function $a(e, t, n) {
    if (ie.current !== Je) throw Error(C(168));
    U(ie, t), U(ce, n)
}

function Da(e, t, n) {
    var r = e.stateNode;
    if (e = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var i in r)
        if (!(i in e)) throw Error(C(108, At(t) || "Unknown", i));
    return H({}, n, r)
}

function Hr(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || Je, xt = ie.current, U(ie, e), U(ce, ce.current), !0
}

function Ra(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(C(169));
    n ? (e = Da(e, t, xt), r.__reactInternalMemoizedMergedChildContext = e, V(ce), V(ie), U(ie, e)) : V(ce), U(ce, n)
}
var Al = null,
    Tt = null,
    Zc = q.unstable_runWithPriority,
    Fl = q.unstable_scheduleCallback,
    jl = q.unstable_cancelCallback,
    Jc = q.unstable_shouldYield,
    Aa = q.unstable_requestPaint,
    Bl = q.unstable_now,
    ed = q.unstable_getCurrentPriorityLevel,
    Ur = q.unstable_ImmediatePriority,
    Fa = q.unstable_UserBlockingPriority,
    ja = q.unstable_NormalPriority,
    Ba = q.unstable_LowPriority,
    Va = q.unstable_IdlePriority,
    Vl = {},
    td = Aa !== void 0 ? Aa : function() {},
    Fe = null,
    Wr = null,
    Hl = !1,
    Ha = Bl(),
    le = 1e4 > Ha ? Bl : function() {
        return Bl() - Ha
    };

function Jt() {
    switch (ed()) {
        case Ur:
            return 99;
        case Fa:
            return 98;
        case ja:
            return 97;
        case Ba:
            return 96;
        case Va:
            return 95;
        default:
            throw Error(C(332))
    }
}

function Ua(e) {
    switch (e) {
        case 99:
            return Ur;
        case 98:
            return Fa;
        case 97:
            return ja;
        case 96:
            return Ba;
        case 95:
            return Va;
        default:
            throw Error(C(332))
    }
}

function kt(e, t) {
    return e = Ua(e), Zc(e, t)
}

function Vn(e, t, n) {
    return e = Ua(e), Fl(e, t, n)
}

function Oe() {
    if (Wr !== null) {
        var e = Wr;
        Wr = null, jl(e)
    }
    Wa()
}

function Wa() {
    if (!Hl && Fe !== null) {
        Hl = !0;
        var e = 0;
        try {
            var t = Fe;
            kt(99, function() {
                for (; e < t.length; e++) {
                    var n = t[e];
                    do n = n(!0); while (n !== null)
                }
            }), Fe = null
        } catch (n) {
            throw Fe !== null && (Fe = Fe.slice(e + 1)), Fl(Ur, Oe), n
        } finally {
            Hl = !1
        }
    }
}
var nd = yt.ReactCurrentBatchConfig;

function Pe(e, t) {
    if (e && e.defaultProps) {
        t = H({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}
var Gr = Ze(null),
    Yr = null,
    en = null,
    br = null;

function Ul() {
    br = en = Yr = null
}

function Wl(e) {
    var t = Gr.current;
    V(Gr), e.type._context._currentValue = t
}

function Ga(e, t) {
    for (; e !== null;) {
        var n = e.alternate;
        if ((e.childLanes & t) === t) {
            if (n === null || (n.childLanes & t) === t) break;
            n.childLanes |= t
        } else e.childLanes |= t, n !== null && (n.childLanes |= t);
        e = e.return
    }
}

function tn(e, t) {
    Yr = e, br = en = null, e = e.dependencies, e !== null && e.firstContext !== null && ((e.lanes & t) != 0 && (_e = !0), e.firstContext = null)
}

function Ee(e, t) {
    if (br !== e && t !== !1 && t !== 0)
        if ((typeof t != "number" || t === 1073741823) && (br = e, t = 1073741823), t = {
                context: e,
                observedBits: t,
                next: null
            }, en === null) {
            if (Yr === null) throw Error(C(308));
            en = t, Yr.dependencies = {
                lanes: 0,
                firstContext: t,
                responders: null
            }
        } else en = en.next = t;
    return e._currentValue
}
var et = !1;

function Gl(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null
        },
        effects: null
    }
}

function Ya(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function tt(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function nt(e, t) {
    if (e = e.updateQueue, e !== null) {
        e = e.shared;
        var n = e.pending;
        n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
    }
}

function ba(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var i = null,
            l = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var s = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                l === null ? i = l = s : l = l.next = s, n = n.next
            } while (n !== null);
            l === null ? i = l = t : l = l.next = t
        } else i = l = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: i,
            lastBaseUpdate: l,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function Hn(e, t, n, r) {
    var i = e.updateQueue;
    et = !1;
    var l = i.firstBaseUpdate,
        s = i.lastBaseUpdate,
        a = i.shared.pending;
    if (a !== null) {
        i.shared.pending = null;
        var o = a,
            f = o.next;
        o.next = null, s === null ? l = f : s.next = f, s = o;
        var d = e.alternate;
        if (d !== null) {
            d = d.updateQueue;
            var m = d.lastBaseUpdate;
            m !== s && (m === null ? d.firstBaseUpdate = f : m.next = f, d.lastBaseUpdate = o)
        }
    }
    if (l !== null) {
        m = i.baseState, s = 0, d = f = o = null;
        do {
            a = l.lane;
            var h = l.eventTime;
            if ((r & a) === a) {
                d !== null && (d = d.next = {
                    eventTime: h,
                    lane: 0,
                    tag: l.tag,
                    payload: l.payload,
                    callback: l.callback,
                    next: null
                });
                e: {
                    var y = e,
                        S = l;
                    switch (a = t, h = n, S.tag) {
                        case 1:
                            if (y = S.payload, typeof y == "function") {
                                m = y.call(h, m, a);
                                break e
                            }
                            m = y;
                            break e;
                        case 3:
                            y.flags = y.flags & -4097 | 64;
                        case 0:
                            if (y = S.payload, a = typeof y == "function" ? y.call(h, m, a) : y, a == null) break e;
                            m = H({}, m, a);
                            break e;
                        case 2:
                            et = !0
                    }
                }
                l.callback !== null && (e.flags |= 32, a = i.effects, a === null ? i.effects = [l] : a.push(l))
            } else h = {
                eventTime: h,
                lane: a,
                tag: l.tag,
                payload: l.payload,
                callback: l.callback,
                next: null
            }, d === null ? (f = d = h, o = m) : d = d.next = h, s |= a;
            if (l = l.next, l === null) {
                if (a = i.shared.pending, a === null) break;
                l = a.next, a.next = null, i.lastBaseUpdate = a, i.shared.pending = null
            }
        } while (1);
        d === null && (o = m), i.baseState = o, i.firstBaseUpdate = f, i.lastBaseUpdate = d, er |= s, e.lanes = s, e.memoizedState = m
    }
}

function Xa(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                i = r.callback;
            if (i !== null) {
                if (r.callback = null, r = n, typeof i != "function") throw Error(C(191, i));
                i.call(r)
            }
        }
}
var Qa = new mr.Component().refs;

function Xr(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : H({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var Qr = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? Et(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = ve(),
            i = lt(e),
            l = tt(r, i);
        l.payload = t, n != null && (l.callback = n), nt(e, l), st(e, i, r)
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = ve(),
            i = lt(e),
            l = tt(r, i);
        l.tag = 1, l.payload = t, n != null && (l.callback = n), nt(e, l), st(e, i, r)
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = ve(),
            r = lt(e),
            i = tt(n, r);
        i.tag = 2, t != null && (i.callback = t), nt(e, i), st(e, r, n)
    }
};

function qa(e, t, n, r, i, l, s) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, l, s) : t.prototype && t.prototype.isPureReactComponent ? !Rn(n, r) || !Rn(i, l) : !0
}

function Ka(e, t, n) {
    var r = !1,
        i = Je,
        l = t.contextType;
    return typeof l == "object" && l !== null ? l = Ee(l) : (i = de(t) ? xt : ie.current, r = t.contextTypes, l = (r = r != null) ? Zt(e, i) : Je), t = new t(n, l), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = Qr, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = l), t
}

function Za(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Qr.enqueueReplaceState(t, t.state, null)
}

function Yl(e, t, n, r) {
    var i = e.stateNode;
    i.props = n, i.state = e.memoizedState, i.refs = Qa, Gl(e);
    var l = t.contextType;
    typeof l == "object" && l !== null ? i.context = Ee(l) : (l = de(t) ? xt : ie.current, i.context = Zt(e, l)), Hn(e, n, i, r), i.state = e.memoizedState, l = t.getDerivedStateFromProps, typeof l == "function" && (Xr(e, t, l, n), i.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (t = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), t !== i.state && Qr.enqueueReplaceState(i, i.state, null), Hn(e, n, i, r), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4)
}
var qr = Array.isArray;

function Un(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(C(309));
                var r = n.stateNode
            }
            if (!r) throw Error(C(147, e));
            var i = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === i ? t.ref : (t = function(l) {
                var s = r.refs;
                s === Qa && (s = r.refs = {}), l === null ? delete s[i] : s[i] = l
            }, t._stringRef = i, t)
        }
        if (typeof e != "string") throw Error(C(284));
        if (!n._owner) throw Error(C(290, e))
    }
    return e
}

function Kr(e, t) {
    if (e.type !== "textarea") throw Error(C(31, Object.prototype.toString.call(t) === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : t))
}

function Ja(e) {
    function t(c, u) {
        if (e) {
            var p = c.lastEffect;
            p !== null ? (p.nextEffect = u, c.lastEffect = u) : c.firstEffect = c.lastEffect = u, u.nextEffect = null, u.flags = 8
        }
    }

    function n(c, u) {
        if (!e) return null;
        for (; u !== null;) t(c, u), u = u.sibling;
        return null
    }

    function r(c, u) {
        for (c = new Map; u !== null;) u.key !== null ? c.set(u.key, u) : c.set(u.index, u), u = u.sibling;
        return c
    }

    function i(c, u) {
        return c = ut(c, u), c.index = 0, c.sibling = null, c
    }

    function l(c, u, p) {
        return c.index = p, e ? (p = c.alternate, p !== null ? (p = p.index, p < u ? (c.flags = 2, u) : p) : (c.flags = 2, u)) : u
    }

    function s(c) {
        return e && c.alternate === null && (c.flags = 2), c
    }

    function a(c, u, p, g) {
        return u === null || u.tag !== 6 ? (u = Ls(p, c.mode, g), u.return = c, u) : (u = i(u, p), u.return = c, u)
    }

    function o(c, u, p, g) {
        return u !== null && u.elementType === p.type ? (g = i(u, p.props), g.ref = Un(c, u, p), g.return = c, g) : (g = mi(p.type, p.key, p.props, null, c.mode, g), g.ref = Un(c, u, p), g.return = c, g)
    }

    function f(c, u, p, g) {
        return u === null || u.tag !== 4 || u.stateNode.containerInfo !== p.containerInfo || u.stateNode.implementation !== p.implementation ? (u = Os(p, c.mode, g), u.return = c, u) : (u = i(u, p.children || []), u.return = c, u)
    }

    function d(c, u, p, g, v) {
        return u === null || u.tag !== 7 ? (u = fn(p, c.mode, g, v), u.return = c, u) : (u = i(u, p), u.return = c, u)
    }

    function m(c, u, p) {
        if (typeof u == "string" || typeof u == "number") return u = Ls("" + u, c.mode, p), u.return = c, u;
        if (typeof u == "object" && u !== null) {
            switch (u.$$typeof) {
                case mn:
                    return p = mi(u.type, u.key, u.props, null, c.mode, p), p.ref = Un(c, null, u), p.return = c, p;
                case wt:
                    return u = Os(u, c.mode, p), u.return = c, u
            }
            if (qr(u) || yn(u)) return u = fn(u, c.mode, p, null), u.return = c, u;
            Kr(c, u)
        }
        return null
    }

    function h(c, u, p, g) {
        var v = u !== null ? u.key : null;
        if (typeof p == "string" || typeof p == "number") return v !== null ? null : a(c, u, "" + p, g);
        if (typeof p == "object" && p !== null) {
            switch (p.$$typeof) {
                case mn:
                    return p.key === v ? p.type === We ? d(c, u, p.props.children, g, v) : o(c, u, p, g) : null;
                case wt:
                    return p.key === v ? f(c, u, p, g) : null
            }
            if (qr(p) || yn(p)) return v !== null ? null : d(c, u, p, g, null);
            Kr(c, p)
        }
        return null
    }

    function y(c, u, p, g, v) {
        if (typeof g == "string" || typeof g == "number") return c = c.get(p) || null, a(u, c, "" + g, v);
        if (typeof g == "object" && g !== null) {
            switch (g.$$typeof) {
                case mn:
                    return c = c.get(g.key === null ? p : g.key) || null, g.type === We ? d(u, c, g.props.children, v, g.key) : o(u, c, g, v);
                case wt:
                    return c = c.get(g.key === null ? p : g.key) || null, f(u, c, g, v)
            }
            if (qr(g) || yn(g)) return c = c.get(p) || null, d(u, c, g, v, null);
            Kr(u, g)
        }
        return null
    }

    function S(c, u, p, g) {
        for (var v = null, T = null, w = u, P = u = 0, x = null; w !== null && P < p.length; P++) {
            w.index > P ? (x = w, w = null) : x = w.sibling;
            var O = h(c, w, p[P], g);
            if (O === null) {
                w === null && (w = x);
                break
            }
            e && w && O.alternate === null && t(c, w), u = l(O, u, P), T === null ? v = O : T.sibling = O, T = O, w = x
        }
        if (P === p.length) return n(c, w), v;
        if (w === null) {
            for (; P < p.length; P++) w = m(c, p[P], g), w !== null && (u = l(w, u, P), T === null ? v = w : T.sibling = w, T = w);
            return v
        }
        for (w = r(c, w); P < p.length; P++) x = y(w, c, P, p[P], g), x !== null && (e && x.alternate !== null && w.delete(x.key === null ? P : x.key), u = l(x, u, P), T === null ? v = x : T.sibling = x, T = x);
        return e && w.forEach(function(_) {
            return t(c, _)
        }), v
    }

    function E(c, u, p, g) {
        var v = yn(p);
        if (typeof v != "function") throw Error(C(150));
        if (p = v.call(p), p == null) throw Error(C(151));
        for (var T = v = null, w = u, P = u = 0, x = null, O = p.next(); w !== null && !O.done; P++, O = p.next()) {
            w.index > P ? (x = w, w = null) : x = w.sibling;
            var _ = h(c, w, O.value, g);
            if (_ === null) {
                w === null && (w = x);
                break
            }
            e && w && _.alternate === null && t(c, w), u = l(_, u, P), T === null ? v = _ : T.sibling = _, T = _, w = x
        }
        if (O.done) return n(c, w), v;
        if (w === null) {
            for (; !O.done; P++, O = p.next()) O = m(c, O.value, g), O !== null && (u = l(O, u, P), T === null ? v = O : T.sibling = O, T = O);
            return v
        }
        for (w = r(c, w); !O.done; P++, O = p.next()) O = y(w, c, P, O.value, g), O !== null && (e && O.alternate !== null && w.delete(O.key === null ? P : O.key), u = l(O, u, P), T === null ? v = O : T.sibling = O, T = O);
        return e && w.forEach(function(z) {
            return t(c, z)
        }), v
    }
    return function(c, u, p, g) {
        var v = typeof p == "object" && p !== null && p.type === We && p.key === null;
        v && (p = p.props.children);
        var T = typeof p == "object" && p !== null;
        if (T) switch (p.$$typeof) {
            case mn:
                e: {
                    for (T = p.key, v = u; v !== null;) {
                        if (v.key === T) {
                            switch (v.tag) {
                                case 7:
                                    if (p.type === We) {
                                        n(c, v.sibling), u = i(v, p.props.children), u.return = c, c = u;
                                        break e
                                    }
                                    break;
                                default:
                                    if (v.elementType === p.type) {
                                        n(c, v.sibling), u = i(v, p.props), u.ref = Un(c, v, p), u.return = c, c = u;
                                        break e
                                    }
                            }
                            n(c, v);
                            break
                        } else t(c, v);
                        v = v.sibling
                    }
                    p.type === We ? (u = fn(p.props.children, c.mode, g, p.key), u.return = c, c = u) : (g = mi(p.type, p.key, p.props, null, c.mode, g), g.ref = Un(c, u, p), g.return = c, c = g)
                }
                return s(c);
            case wt:
                e: {
                    for (v = p.key; u !== null;) {
                        if (u.key === v)
                            if (u.tag === 4 && u.stateNode.containerInfo === p.containerInfo && u.stateNode.implementation === p.implementation) {
                                n(c, u.sibling), u = i(u, p.children || []), u.return = c, c = u;
                                break e
                            } else {
                                n(c, u);
                                break
                            }
                        else t(c, u);
                        u = u.sibling
                    }
                    u = Os(p, c.mode, g),
                    u.return = c,
                    c = u
                }
                return s(c)
        }
        if (typeof p == "string" || typeof p == "number") return p = "" + p, u !== null && u.tag === 6 ? (n(c, u.sibling), u = i(u, p), u.return = c, c = u) : (n(c, u), u = Ls(p, c.mode, g), u.return = c, c = u), s(c);
        if (qr(p)) return S(c, u, p, g);
        if (yn(p)) return E(c, u, p, g);
        if (T && Kr(c, p), typeof p == "undefined" && !v) switch (c.tag) {
            case 1:
            case 22:
            case 0:
            case 11:
            case 15:
                throw Error(C(152, At(c.type) || "Component"))
        }
        return n(c, u)
    }
}
var Zr = Ja(!0),
    eu = Ja(!1),
    Wn = {},
    Me = Ze(Wn),
    Gn = Ze(Wn),
    Yn = Ze(Wn);

function Pt(e) {
    if (e === Wn) throw Error(C(174));
    return e
}

function bl(e, t) {
    switch (U(Yn, t), U(Gn, e), U(Me, Wn), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : Zi(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = Zi(t, e)
    }
    V(Me), U(Me, t)
}

function nn() {
    V(Me), V(Gn), V(Yn)
}

function tu(e) {
    Pt(Yn.current);
    var t = Pt(Me.current),
        n = Zi(t, e.type);
    t !== n && (U(Gn, e), U(Me, n))
}

function Xl(e) {
    Gn.current === e && (V(Me), V(Gn))
}
var W = Ze(0);

function Jr(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if ((t.flags & 64) != 0) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var je = null,
    rt = null,
    Ne = !1;

function nu(e, t) {
    var n = Te(5, null, null, 0);
    n.elementType = "DELETED", n.type = "DELETED", n.stateNode = t, n.return = e, n.flags = 8, e.lastEffect !== null ? (e.lastEffect.nextEffect = n, e.lastEffect = n) : e.firstEffect = e.lastEffect = n
}

function ru(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, !0) : !1;
        case 13:
            return !1;
        default:
            return !1
    }
}

function Ql(e) {
    if (Ne) {
        var t = rt;
        if (t) {
            var n = t;
            if (!ru(e, t)) {
                if (t = Xt(n.nextSibling), !t || !ru(e, t)) {
                    e.flags = e.flags & -1025 | 2, Ne = !1, je = e;
                    return
                }
                nu(je, n)
            }
            je = e, rt = Xt(t.firstChild)
        } else e.flags = e.flags & -1025 | 2, Ne = !1, je = e
    }
}

function iu(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    je = e
}

function ei(e) {
    if (e !== je) return !1;
    if (!Ne) return iu(e), Ne = !0, !1;
    var t = e.type;
    if (e.tag !== 5 || t !== "head" && t !== "body" && !Il(t, e.memoizedProps))
        for (t = rt; t;) nu(e, t), t = Xt(t.nextSibling);
    if (iu(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(C(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            rt = Xt(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            rt = null
        }
    } else rt = je ? Xt(e.stateNode.nextSibling) : null;
    return !0
}

function ql() {
    rt = je = null, Ne = !1
}
var rn = [];

function Kl() {
    for (var e = 0; e < rn.length; e++) rn[e]._workInProgressVersionPrimary = null;
    rn.length = 0
}
var bn = yt.ReactCurrentDispatcher,
    Ce = yt.ReactCurrentBatchConfig,
    Xn = 0,
    Y = null,
    se = null,
    te = null,
    ti = !1,
    Qn = !1;

function pe() {
    throw Error(C(321))
}

function Zl(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!Se(e[n], t[n])) return !1;
    return !0
}

function Jl(e, t, n, r, i, l) {
    if (Xn = l, Y = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, bn.current = e === null || e.memoizedState === null ? id : ld, e = n(r, i), Qn) {
        l = 0;
        do {
            if (Qn = !1, !(25 > l)) throw Error(C(301));
            l += 1, te = se = null, t.updateQueue = null, bn.current = sd, e = n(r, i)
        } while (Qn)
    }
    if (bn.current = li, t = se !== null && se.next !== null, Xn = 0, te = se = Y = null, ti = !1, t) throw Error(C(300));
    return e
}

function _t() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return te === null ? Y.memoizedState = te = e : te = te.next = e, te
}

function Lt() {
    if (se === null) {
        var e = Y.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = se.next;
    var t = te === null ? Y.memoizedState : te.next;
    if (t !== null) te = t, se = e;
    else {
        if (e === null) throw Error(C(310));
        se = e, e = {
            memoizedState: se.memoizedState,
            baseState: se.baseState,
            baseQueue: se.baseQueue,
            queue: se.queue,
            next: null
        }, te === null ? Y.memoizedState = te = e : te = te.next = e
    }
    return te
}

function ze(e, t) {
    return typeof t == "function" ? t(e) : t
}

function qn(e) {
    var t = Lt(),
        n = t.queue;
    if (n === null) throw Error(C(311));
    n.lastRenderedReducer = e;
    var r = se,
        i = r.baseQueue,
        l = n.pending;
    if (l !== null) {
        if (i !== null) {
            var s = i.next;
            i.next = l.next, l.next = s
        }
        r.baseQueue = i = l, n.pending = null
    }
    if (i !== null) {
        i = i.next, r = r.baseState;
        var a = s = l = null,
            o = i;
        do {
            var f = o.lane;
            if ((Xn & f) === f) a !== null && (a = a.next = {
                lane: 0,
                action: o.action,
                eagerReducer: o.eagerReducer,
                eagerState: o.eagerState,
                next: null
            }), r = o.eagerReducer === e ? o.eagerState : e(r, o.action);
            else {
                var d = {
                    lane: f,
                    action: o.action,
                    eagerReducer: o.eagerReducer,
                    eagerState: o.eagerState,
                    next: null
                };
                a === null ? (s = a = d, l = r) : a = a.next = d, Y.lanes |= f, er |= f
            }
            o = o.next
        } while (o !== null && o !== i);
        a === null ? l = r : a.next = s, Se(r, t.memoizedState) || (_e = !0), t.memoizedState = r, t.baseState = l, t.baseQueue = a, n.lastRenderedState = r
    }
    return [t.memoizedState, n.dispatch]
}

function Kn(e) {
    var t = Lt(),
        n = t.queue;
    if (n === null) throw Error(C(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        i = n.pending,
        l = t.memoizedState;
    if (i !== null) {
        n.pending = null;
        var s = i = i.next;
        do l = e(l, s.action), s = s.next; while (s !== i);
        Se(l, t.memoizedState) || (_e = !0), t.memoizedState = l, t.baseQueue === null && (t.baseState = l), n.lastRenderedState = l
    }
    return [l, r]
}

function lu(e, t, n) {
    var r = t._getVersion;
    r = r(t._source);
    var i = t._workInProgressVersionPrimary;
    if (i !== null ? e = i === r : (e = e.mutableReadLanes, (e = (Xn & e) === e) && (t._workInProgressVersionPrimary = r, rn.push(t))), e) return n(t._source);
    throw rn.push(t), Error(C(350))
}

function su(e, t, n, r) {
    var i = ue;
    if (i === null) throw Error(C(349));
    var l = t._getVersion,
        s = l(t._source),
        a = bn.current,
        o = a.useState(function() {
            return lu(i, t, n)
        }),
        f = o[1],
        d = o[0];
    o = te;
    var m = e.memoizedState,
        h = m.refs,
        y = h.getSnapshot,
        S = m.source;
    m = m.subscribe;
    var E = Y;
    return e.memoizedState = {
        refs: h,
        source: t,
        subscribe: r
    }, a.useEffect(function() {
        h.getSnapshot = n, h.setSnapshot = f;
        var c = l(t._source);
        if (!Se(s, c)) {
            c = n(t._source), Se(d, c) || (f(c), c = lt(E), i.mutableReadLanes |= c & i.pendingLanes), c = i.mutableReadLanes, i.entangledLanes |= c;
            for (var u = i.entanglements, p = c; 0 < p;) {
                var g = 31 - Qe(p),
                    v = 1 << g;
                u[g] |= c, p &= ~v
            }
        }
    }, [n, t, r]), a.useEffect(function() {
        return r(t._source, function() {
            var c = h.getSnapshot,
                u = h.setSnapshot;
            try {
                u(c(t._source));
                var p = lt(E);
                i.mutableReadLanes |= p & i.pendingLanes
            } catch (g) {
                u(function() {
                    throw g
                })
            }
        })
    }, [t, r]), Se(y, n) && Se(S, t) && Se(m, r) || (e = {
        pending: null,
        dispatch: null,
        lastRenderedReducer: ze,
        lastRenderedState: d
    }, e.dispatch = f = rs.bind(null, Y, e), o.queue = e, o.baseQueue = null, d = lu(i, t, n), o.memoizedState = o.baseState = d), d
}

function ou(e, t, n) {
    var r = Lt();
    return su(r, e, t, n)
}

function Zn(e) {
    var t = _t();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = t.queue = {
        pending: null,
        dispatch: null,
        lastRenderedReducer: ze,
        lastRenderedState: e
    }, e = e.dispatch = rs.bind(null, Y, e), [t.memoizedState, e]
}

function ni(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = Y.updateQueue, t === null ? (t = {
        lastEffect: null
    }, Y.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function au(e) {
    var t = _t();
    return e = {
        current: e
    }, t.memoizedState = e
}

function ri() {
    return Lt().memoizedState
}

function es(e, t, n, r) {
    var i = _t();
    Y.flags |= e, i.memoizedState = ni(1 | t, n, void 0, r === void 0 ? null : r)
}

function ts(e, t, n, r) {
    var i = Lt();
    r = r === void 0 ? null : r;
    var l = void 0;
    if (se !== null) {
        var s = se.memoizedState;
        if (l = s.destroy, r !== null && Zl(r, s.deps)) {
            ni(t, n, l, r);
            return
        }
    }
    Y.flags |= e, i.memoizedState = ni(1 | t, n, l, r)
}

function uu(e, t) {
    return es(516, 4, e, t)
}

function ii(e, t) {
    return ts(516, 4, e, t)
}

function fu(e, t) {
    return ts(4, 2, e, t)
}

function cu(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function du(e, t, n) {
    return n = n != null ? n.concat([e]) : null, ts(4, 2, cu.bind(null, t, e), n)
}

function ns() {}

function pu(e, t) {
    var n = Lt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Zl(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function hu(e, t) {
    var n = Lt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Zl(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function rd(e, t) {
    var n = Jt();
    kt(98 > n ? 98 : n, function() {
        e(!0)
    }), kt(97 < n ? 97 : n, function() {
        var r = Ce.transition;
        Ce.transition = 1;
        try {
            e(!1), t()
        } finally {
            Ce.transition = r
        }
    })
}

function rs(e, t, n) {
    var r = ve(),
        i = lt(e),
        l = {
            lane: i,
            action: n,
            eagerReducer: null,
            eagerState: null,
            next: null
        },
        s = t.pending;
    if (s === null ? l.next = l : (l.next = s.next, s.next = l), t.pending = l, s = e.alternate, e === Y || s !== null && s === Y) Qn = ti = !0;
    else {
        if (e.lanes === 0 && (s === null || s.lanes === 0) && (s = t.lastRenderedReducer, s !== null)) try {
            var a = t.lastRenderedState,
                o = s(a, n);
            if (l.eagerReducer = s, l.eagerState = o, Se(o, a)) return
        } catch {} finally {}
        st(e, i, r)
    }
}
var li = {
        readContext: Ee,
        useCallback: pe,
        useContext: pe,
        useEffect: pe,
        useImperativeHandle: pe,
        useLayoutEffect: pe,
        useMemo: pe,
        useReducer: pe,
        useRef: pe,
        useState: pe,
        useDebugValue: pe,
        useDeferredValue: pe,
        useTransition: pe,
        useMutableSource: pe,
        useOpaqueIdentifier: pe,
        unstable_isNewReconciler: !1
    },
    id = {
        readContext: Ee,
        useCallback: function(e, t) {
            return _t().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: Ee,
        useEffect: uu,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, es(4, 2, cu.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return es(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = _t();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = _t();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = r.queue = {
                pending: null,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, e = e.dispatch = rs.bind(null, Y, e), [r.memoizedState, e]
        },
        useRef: au,
        useState: Zn,
        useDebugValue: ns,
        useDeferredValue: function(e) {
            var t = Zn(e),
                n = t[0],
                r = t[1];
            return uu(function() {
                var i = Ce.transition;
                Ce.transition = 1;
                try {
                    r(e)
                } finally {
                    Ce.transition = i
                }
            }, [e]), n
        },
        useTransition: function() {
            var e = Zn(!1),
                t = e[0];
            return e = rd.bind(null, e[1]), au(e), [e, t]
        },
        useMutableSource: function(e, t, n) {
            var r = _t();
            return r.memoizedState = {
                refs: {
                    getSnapshot: t,
                    setSnapshot: null
                },
                source: e,
                subscribe: n
            }, su(r, e, t, n)
        },
        useOpaqueIdentifier: function() {
            if (Ne) {
                var e = !1,
                    t = Kc(function() {
                        throw e || (e = !0, n("r:" + (Dl++).toString(36))), Error(C(355))
                    }),
                    n = Zn(t)[1];
                return (Y.mode & 2) == 0 && (Y.flags |= 516, ni(5, function() {
                    n("r:" + (Dl++).toString(36))
                }, void 0, null)), t
            }
            return t = "r:" + (Dl++).toString(36), Zn(t), t
        },
        unstable_isNewReconciler: !1
    },
    ld = {
        readContext: Ee,
        useCallback: pu,
        useContext: Ee,
        useEffect: ii,
        useImperativeHandle: du,
        useLayoutEffect: fu,
        useMemo: hu,
        useReducer: qn,
        useRef: ri,
        useState: function() {
            return qn(ze)
        },
        useDebugValue: ns,
        useDeferredValue: function(e) {
            var t = qn(ze),
                n = t[0],
                r = t[1];
            return ii(function() {
                var i = Ce.transition;
                Ce.transition = 1;
                try {
                    r(e)
                } finally {
                    Ce.transition = i
                }
            }, [e]), n
        },
        useTransition: function() {
            var e = qn(ze)[0];
            return [ri().current, e]
        },
        useMutableSource: ou,
        useOpaqueIdentifier: function() {
            return qn(ze)[0]
        },
        unstable_isNewReconciler: !1
    },
    sd = {
        readContext: Ee,
        useCallback: pu,
        useContext: Ee,
        useEffect: ii,
        useImperativeHandle: du,
        useLayoutEffect: fu,
        useMemo: hu,
        useReducer: Kn,
        useRef: ri,
        useState: function() {
            return Kn(ze)
        },
        useDebugValue: ns,
        useDeferredValue: function(e) {
            var t = Kn(ze),
                n = t[0],
                r = t[1];
            return ii(function() {
                var i = Ce.transition;
                Ce.transition = 1;
                try {
                    r(e)
                } finally {
                    Ce.transition = i
                }
            }, [e]), n
        },
        useTransition: function() {
            var e = Kn(ze)[0];
            return [ri().current, e]
        },
        useMutableSource: ou,
        useOpaqueIdentifier: function() {
            return Kn(ze)[0]
        },
        unstable_isNewReconciler: !1
    },
    od = yt.ReactCurrentOwner,
    _e = !1;

function he(e, t, n, r) {
    t.child = e === null ? eu(t, null, n, r) : Zr(t, e.child, n, r)
}

function mu(e, t, n, r, i) {
    n = n.render;
    var l = t.ref;
    return tn(t, i), r = Jl(e, t, n, r, l, i), e !== null && !_e ? (t.updateQueue = e.updateQueue, t.flags &= -517, e.lanes &= ~i, Be(e, t, i)) : (t.flags |= 1, he(e, t, r, i), t.child)
}

function gu(e, t, n, r, i, l) {
    if (e === null) {
        var s = n.type;
        return typeof s == "function" && !Ps(s) && s.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = s, vu(e, t, s, r, i, l)) : (e = mi(n.type, null, r, t, t.mode, l), e.ref = t.ref, e.return = t, t.child = e)
    }
    return s = e.child, (i & l) == 0 && (i = s.memoizedProps, n = n.compare, n = n !== null ? n : Rn, n(i, r) && e.ref === t.ref) ? Be(e, t, l) : (t.flags |= 1, e = ut(s, r), e.ref = t.ref, e.return = t, t.child = e)
}

function vu(e, t, n, r, i, l) {
    if (e !== null && Rn(e.memoizedProps, r) && e.ref === t.ref)
        if (_e = !1, (l & i) != 0)(e.flags & 16384) != 0 && (_e = !0);
        else return t.lanes = e.lanes, Be(e, t, l);
    return ls(e, t, n, r, l)
}

function is(e, t, n) {
    var r = t.pendingProps,
        i = r.children,
        l = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden" || r.mode === "unstable-defer-without-hiding")
        if ((t.mode & 4) == 0) t.memoizedState = {
            baseLanes: 0
        }, hi(t, n);
        else if ((n & 1073741824) != 0) t.memoizedState = {
        baseLanes: 0
    }, hi(t, l !== null ? l.baseLanes : n);
    else return e = l !== null ? l.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
        baseLanes: e
    }, hi(t, e), null;
    else l !== null ? (r = l.baseLanes | n, t.memoizedState = null) : r = n, hi(t, r);
    return he(e, t, i, n), t.child
}

function yu(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 128)
}

function ls(e, t, n, r, i) {
    var l = de(n) ? xt : ie.current;
    return l = Zt(t, l), tn(t, i), n = Jl(e, t, n, r, l, i), e !== null && !_e ? (t.updateQueue = e.updateQueue, t.flags &= -517, e.lanes &= ~i, Be(e, t, i)) : (t.flags |= 1, he(e, t, n, i), t.child)
}

function wu(e, t, n, r, i) {
    if (de(n)) {
        var l = !0;
        Hr(t)
    } else l = !1;
    if (tn(t, i), t.stateNode === null) e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), Ka(t, n, r), Yl(t, n, r, i), r = !0;
    else if (e === null) {
        var s = t.stateNode,
            a = t.memoizedProps;
        s.props = a;
        var o = s.context,
            f = n.contextType;
        typeof f == "object" && f !== null ? f = Ee(f) : (f = de(n) ? xt : ie.current, f = Zt(t, f));
        var d = n.getDerivedStateFromProps,
            m = typeof d == "function" || typeof s.getSnapshotBeforeUpdate == "function";
        m || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (a !== r || o !== f) && Za(t, s, r, f), et = !1;
        var h = t.memoizedState;
        s.state = h, Hn(t, r, s, i), o = t.memoizedState, a !== r || h !== o || ce.current || et ? (typeof d == "function" && (Xr(t, n, d, r), o = t.memoizedState), (a = et || qa(t, n, a, r, h, o, f)) ? (m || typeof s.UNSAFE_componentWillMount != "function" && typeof s.componentWillMount != "function" || (typeof s.componentWillMount == "function" && s.componentWillMount(), typeof s.UNSAFE_componentWillMount == "function" && s.UNSAFE_componentWillMount()), typeof s.componentDidMount == "function" && (t.flags |= 4)) : (typeof s.componentDidMount == "function" && (t.flags |= 4), t.memoizedProps = r, t.memoizedState = o), s.props = r, s.state = o, s.context = f, r = a) : (typeof s.componentDidMount == "function" && (t.flags |= 4), r = !1)
    } else {
        s = t.stateNode, Ya(e, t), a = t.memoizedProps, f = t.type === t.elementType ? a : Pe(t.type, a), s.props = f, m = t.pendingProps, h = s.context, o = n.contextType, typeof o == "object" && o !== null ? o = Ee(o) : (o = de(n) ? xt : ie.current, o = Zt(t, o));
        var y = n.getDerivedStateFromProps;
        (d = typeof y == "function" || typeof s.getSnapshotBeforeUpdate == "function") || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (a !== m || h !== o) && Za(t, s, r, o), et = !1, h = t.memoizedState, s.state = h, Hn(t, r, s, i);
        var S = t.memoizedState;
        a !== m || h !== S || ce.current || et ? (typeof y == "function" && (Xr(t, n, y, r), S = t.memoizedState), (f = et || qa(t, n, f, r, h, S, o)) ? (d || typeof s.UNSAFE_componentWillUpdate != "function" && typeof s.componentWillUpdate != "function" || (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(r, S, o), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(r, S, o)), typeof s.componentDidUpdate == "function" && (t.flags |= 4), typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= 256)) : (typeof s.componentDidUpdate != "function" || a === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || a === e.memoizedProps && h === e.memoizedState || (t.flags |= 256), t.memoizedProps = r, t.memoizedState = S), s.props = r, s.state = S, s.context = o, r = f) : (typeof s.componentDidUpdate != "function" || a === e.memoizedProps && h === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || a === e.memoizedProps && h === e.memoizedState || (t.flags |= 256), r = !1)
    }
    return ss(e, t, n, r, l, i)
}

function ss(e, t, n, r, i, l) {
    yu(e, t);
    var s = (t.flags & 64) != 0;
    if (!r && !s) return i && Ra(t, n, !1), Be(e, t, l);
    r = t.stateNode, od.current = t;
    var a = s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && s ? (t.child = Zr(t, e.child, null, l), t.child = Zr(t, null, a, l)) : he(e, t, a, l), t.memoizedState = r.state, i && Ra(t, n, !0), t.child
}

function Su(e) {
    var t = e.stateNode;
    t.pendingContext ? $a(e, t.pendingContext, t.pendingContext !== t.context) : t.context && $a(e, t.context, !1), bl(e, t.containerInfo)
}
var si = {
    dehydrated: null,
    retryLane: 0
};

function Eu(e, t, n) {
    var r = t.pendingProps,
        i = W.current,
        l = !1,
        s;
    return (s = (t.flags & 64) != 0) || (s = e !== null && e.memoizedState === null ? !1 : (i & 2) != 0), s ? (l = !0, t.flags &= -65) : e !== null && e.memoizedState === null || r.fallback === void 0 || r.unstable_avoidThisFallback === !0 || (i |= 1), U(W, i & 1), e === null ? (r.fallback !== void 0 && Ql(t), e = r.children, i = r.fallback, l ? (e = Cu(t, e, i, n), t.child.memoizedState = {
        baseLanes: n
    }, t.memoizedState = si, e) : typeof r.unstable_expectedLoadTime == "number" ? (e = Cu(t, e, i, n), t.child.memoizedState = {
        baseLanes: n
    }, t.memoizedState = si, t.lanes = 33554432, e) : (n = _s({
        mode: "visible",
        children: e
    }, t.mode, n, null), n.return = t, t.child = n)) : e.memoizedState !== null ? l ? (r = Tu(e, t, r.children, r.fallback, n), l = t.child, i = e.child.memoizedState, l.memoizedState = i === null ? {
        baseLanes: n
    } : {
        baseLanes: i.baseLanes | n
    }, l.childLanes = e.childLanes & ~n, t.memoizedState = si, r) : (n = xu(e, t, r.children, n), t.memoizedState = null, n) : l ? (r = Tu(e, t, r.children, r.fallback, n), l = t.child, i = e.child.memoizedState, l.memoizedState = i === null ? {
        baseLanes: n
    } : {
        baseLanes: i.baseLanes | n
    }, l.childLanes = e.childLanes & ~n, t.memoizedState = si, r) : (n = xu(e, t, r.children, n), t.memoizedState = null, n)
}

function Cu(e, t, n, r) {
    var i = e.mode,
        l = e.child;
    return t = {
        mode: "hidden",
        children: t
    }, (i & 2) == 0 && l !== null ? (l.childLanes = 0, l.pendingProps = t) : l = _s(t, i, 0, null), n = fn(n, i, r, null), l.return = e, n.return = e, l.sibling = n, e.child = l, n
}

function xu(e, t, n, r) {
    var i = e.child;
    return e = i.sibling, n = ut(i, {
        mode: "visible",
        children: n
    }), (t.mode & 2) == 0 && (n.lanes = r), n.return = t, n.sibling = null, e !== null && (e.nextEffect = null, e.flags = 8, t.firstEffect = t.lastEffect = e), t.child = n
}

function Tu(e, t, n, r, i) {
    var l = t.mode,
        s = e.child;
    e = s.sibling;
    var a = {
        mode: "hidden",
        children: n
    };
    return (l & 2) == 0 && t.child !== s ? (n = t.child, n.childLanes = 0, n.pendingProps = a, s = n.lastEffect, s !== null ? (t.firstEffect = n.firstEffect, t.lastEffect = s, s.nextEffect = null) : t.firstEffect = t.lastEffect = null) : n = ut(s, a), e !== null ? r = ut(e, r) : (r = fn(r, l, i, null), r.flags |= 2), r.return = t, n.return = t, n.sibling = r, t.child = n, r
}

function ku(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    n !== null && (n.lanes |= t), Ga(e.return, t)
}

function os(e, t, n, r, i, l) {
    var s = e.memoizedState;
    s === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: i,
        lastEffect: l
    } : (s.isBackwards = t, s.rendering = null, s.renderingStartTime = 0, s.last = r, s.tail = n, s.tailMode = i, s.lastEffect = l)
}

function Pu(e, t, n) {
    var r = t.pendingProps,
        i = r.revealOrder,
        l = r.tail;
    if (he(e, t, r.children, n), r = W.current, (r & 2) != 0) r = r & 1 | 2, t.flags |= 64;
    else {
        if (e !== null && (e.flags & 64) != 0) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && ku(e, n);
            else if (e.tag === 19) ku(e, n);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (U(W, r), (t.mode & 2) == 0) t.memoizedState = null;
    else switch (i) {
        case "forwards":
            for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && Jr(e) === null && (i = n), n = n.sibling;
            n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), os(t, !1, i, n, l, t.lastEffect);
            break;
        case "backwards":
            for (n = null, i = t.child, t.child = null; i !== null;) {
                if (e = i.alternate, e !== null && Jr(e) === null) {
                    t.child = i;
                    break
                }
                e = i.sibling, i.sibling = n, n = i, i = e
            }
            os(t, !0, n, null, l, t.lastEffect);
            break;
        case "together":
            os(t, !1, null, null, void 0, t.lastEffect);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function Be(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), er |= t.lanes, (n & t.childLanes) != 0) {
        if (e !== null && t.child !== e.child) throw Error(C(153));
        if (t.child !== null) {
            for (e = t.child, n = ut(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = ut(e, e.pendingProps), n.return = t;
            n.sibling = null
        }
        return t.child
    }
    return null
}
var _u, as, Lu, Ou;
_u = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
as = function() {};
Lu = function(e, t, n, r) {
    var i = e.memoizedProps;
    if (i !== r) {
        e = t.stateNode, Pt(Me.current);
        var l = null;
        switch (n) {
            case "input":
                i = Yi(e, i), r = Yi(e, r), l = [];
                break;
            case "option":
                i = Qi(e, i), r = Qi(e, r), l = [];
                break;
            case "select":
                i = H({}, i, {
                    value: void 0
                }), r = H({}, r, {
                    value: void 0
                }), l = [];
                break;
            case "textarea":
                i = qi(e, i), r = qi(e, r), l = [];
                break;
            default:
                typeof i.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Ar)
        }
        Ji(n, r);
        var s;
        n = null;
        for (f in i)
            if (!r.hasOwnProperty(f) && i.hasOwnProperty(f) && i[f] != null)
                if (f === "style") {
                    var a = i[f];
                    for (s in a) a.hasOwnProperty(s) && (n || (n = {}), n[s] = "")
                } else f !== "dangerouslySetInnerHTML" && f !== "children" && f !== "suppressContentEditableWarning" && f !== "suppressHydrationWarning" && f !== "autoFocus" && (hn.hasOwnProperty(f) ? l || (l = []) : (l = l || []).push(f, null));
        for (f in r) {
            var o = r[f];
            if (a = i != null ? i[f] : void 0, r.hasOwnProperty(f) && o !== a && (o != null || a != null))
                if (f === "style")
                    if (a) {
                        for (s in a) !a.hasOwnProperty(s) || o && o.hasOwnProperty(s) || (n || (n = {}), n[s] = "");
                        for (s in o) o.hasOwnProperty(s) && a[s] !== o[s] && (n || (n = {}), n[s] = o[s])
                    } else n || (l || (l = []), l.push(f, n)), n = o;
            else f === "dangerouslySetInnerHTML" ? (o = o ? o.__html : void 0, a = a ? a.__html : void 0, o != null && a !== o && (l = l || []).push(f, o)) : f === "children" ? typeof o != "string" && typeof o != "number" || (l = l || []).push(f, "" + o) : f !== "suppressContentEditableWarning" && f !== "suppressHydrationWarning" && (hn.hasOwnProperty(f) ? (o != null && f === "onScroll" && B("scroll", e), l || a === o || (l = [])) : typeof o == "object" && o !== null && o.$$typeof === Vi ? o.toString() : (l = l || []).push(f, o))
        }
        n && (l = l || []).push("style", n);
        var f = l;
        (t.updateQueue = f) && (t.flags |= 4)
    }
};
Ou = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function Jn(e, t) {
    if (!Ne) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function ad(e, t, n) {
    var r = t.pendingProps;
    switch (t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return null;
        case 1:
            return de(t.type) && Vr(), null;
        case 3:
            return nn(), V(ce), V(ie), Kl(), r = t.stateNode, r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (ei(t) ? t.flags |= 4 : r.hydrate || (t.flags |= 256)), as(t), null;
        case 5:
            Xl(t);
            var i = Pt(Yn.current);
            if (n = t.type, e !== null && t.stateNode != null) Lu(e, t, n, r, i), e.ref !== t.ref && (t.flags |= 128);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(C(166));
                    return null
                }
                if (e = Pt(Me.current), ei(t)) {
                    r = t.stateNode, n = t.type;
                    var l = t.memoizedProps;
                    switch (r[Ke] = t, r[jr] = l, n) {
                        case "dialog":
                            B("cancel", r), B("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            B("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (e = 0; e < Fn.length; e++) B(Fn[e], r);
                            break;
                        case "source":
                            B("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            B("error", r), B("load", r);
                            break;
                        case "details":
                            B("toggle", r);
                            break;
                        case "input":
                            wo(r, l), B("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!l.multiple
                            }, B("invalid", r);
                            break;
                        case "textarea":
                            Co(r, l), B("invalid", r)
                    }
                    Ji(n, l), e = null;
                    for (var s in l) l.hasOwnProperty(s) && (i = l[s], s === "children" ? typeof i == "string" ? r.textContent !== i && (e = ["children", i]) : typeof i == "number" && r.textContent !== "" + i && (e = ["children", "" + i]) : hn.hasOwnProperty(s) && i != null && s === "onScroll" && B("scroll", r));
                    switch (n) {
                        case "input":
                            Sr(r), Eo(r, l, !0);
                            break;
                        case "textarea":
                            Sr(r), To(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof l.onClick == "function" && (r.onclick = Ar)
                    }
                    r = e, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    switch (s = i.nodeType === 9 ? i : i.ownerDocument, e === Ki.html && (e = ko(n)), e === Ki.html ? n === "script" ? (e = s.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = s.createElement(n, {
                        is: r.is
                    }) : (e = s.createElement(n), n === "select" && (s = e, r.multiple ? s.multiple = !0 : r.size && (s.size = r.size))) : e = s.createElementNS(e, n), e[Ke] = t, e[jr] = r, _u(e, t, !1, !1), t.stateNode = e, s = el(n, r), n) {
                        case "dialog":
                            B("cancel", e), B("close", e), i = r;
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            B("load", e), i = r;
                            break;
                        case "video":
                        case "audio":
                            for (i = 0; i < Fn.length; i++) B(Fn[i], e);
                            i = r;
                            break;
                        case "source":
                            B("error", e), i = r;
                            break;
                        case "img":
                        case "image":
                        case "link":
                            B("error", e), B("load", e), i = r;
                            break;
                        case "details":
                            B("toggle", e), i = r;
                            break;
                        case "input":
                            wo(e, r), i = Yi(e, r), B("invalid", e);
                            break;
                        case "option":
                            i = Qi(e, r);
                            break;
                        case "select":
                            e._wrapperState = {
                                wasMultiple: !!r.multiple
                            }, i = H({}, r, {
                                value: void 0
                            }), B("invalid", e);
                            break;
                        case "textarea":
                            Co(e, r), i = qi(e, r), B("invalid", e);
                            break;
                        default:
                            i = r
                    }
                    Ji(n, i);
                    var a = i;
                    for (l in a)
                        if (a.hasOwnProperty(l)) {
                            var o = a[l];
                            l === "style" ? Lo(e, o) : l === "dangerouslySetInnerHTML" ? (o = o ? o.__html : void 0, o != null && Po(e, o)) : l === "children" ? typeof o == "string" ? (n !== "textarea" || o !== "") && Sn(e, o) : typeof o == "number" && Sn(e, "" + o) : l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && l !== "autoFocus" && (hn.hasOwnProperty(l) ? o != null && l === "onScroll" && B("scroll", e) : o != null && Di(e, l, o, s))
                        }
                    switch (n) {
                        case "input":
                            Sr(e), Eo(e, r, !1);
                            break;
                        case "textarea":
                            Sr(e), To(e);
                            break;
                        case "option":
                            r.value != null && e.setAttribute("value", "" + Ge(r.value));
                            break;
                        case "select":
                            e.multiple = !!r.multiple, l = r.value, l != null ? Ft(e, !!r.multiple, l, !1) : r.defaultValue != null && Ft(e, !!r.multiple, r.defaultValue, !0);
                            break;
                        default:
                            typeof i.onClick == "function" && (e.onclick = Ar)
                    }
                    Oa(n, r) && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 128)
            }
            return null;
        case 6:
            if (e && t.stateNode != null) Ou(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(C(166));
                n = Pt(Yn.current), Pt(Me.current), ei(t) ? (r = t.stateNode, n = t.memoizedProps, r[Ke] = t, r.nodeValue !== n && (t.flags |= 4)) : (r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Ke] = t, t.stateNode = r)
            }
            return null;
        case 13:
            return V(W), r = t.memoizedState, (t.flags & 64) != 0 ? (t.lanes = n, t) : (r = r !== null, n = !1, e === null ? t.memoizedProps.fallback !== void 0 && ei(t) : n = e.memoizedState !== null, r && !n && (t.mode & 2) != 0 && (e === null && t.memoizedProps.unstable_avoidThisFallback !== !0 || (W.current & 1) != 0 ? ne === 0 && (ne = 3) : ((ne === 0 || ne === 3) && (ne = 4), ue === null || (er & 134217727) == 0 && (sn & 134217727) == 0 || an(ue, oe))), (r || n) && (t.flags |= 4), null);
        case 4:
            return nn(), as(t), e === null && Ta(t.stateNode.containerInfo), null;
        case 10:
            return Wl(t), null;
        case 17:
            return de(t.type) && Vr(), null;
        case 19:
            if (V(W), r = t.memoizedState, r === null) return null;
            if (l = (t.flags & 64) != 0, s = r.rendering, s === null)
                if (l) Jn(r, !1);
                else {
                    if (ne !== 0 || e !== null && (e.flags & 64) != 0)
                        for (e = t.child; e !== null;) {
                            if (s = Jr(e), s !== null) {
                                for (t.flags |= 64, Jn(r, !1), l = s.updateQueue, l !== null && (t.updateQueue = l, t.flags |= 4), r.lastEffect === null && (t.firstEffect = null), t.lastEffect = r.lastEffect, r = n, n = t.child; n !== null;) l = n, e = r, l.flags &= 2, l.nextEffect = null, l.firstEffect = null, l.lastEffect = null, s = l.alternate, s === null ? (l.childLanes = 0, l.lanes = e, l.child = null, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = s.childLanes, l.lanes = s.lanes, l.child = s.child, l.memoizedProps = s.memoizedProps, l.memoizedState = s.memoizedState, l.updateQueue = s.updateQueue, l.type = s.type, e = s.dependencies, l.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return U(W, W.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    r.tail !== null && le() > ws && (t.flags |= 64, l = !0, Jn(r, !1), t.lanes = 33554432)
                }
            else {
                if (!l)
                    if (e = Jr(s), e !== null) {
                        if (t.flags |= 64, l = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), Jn(r, !0), r.tail === null && r.tailMode === "hidden" && !s.alternate && !Ne) return t = t.lastEffect = r.lastEffect, t !== null && (t.nextEffect = null), null
                    } else 2 * le() - r.renderingStartTime > ws && n !== 1073741824 && (t.flags |= 64, l = !0, Jn(r, !1), t.lanes = 33554432);
                r.isBackwards ? (s.sibling = t.child, t.child = s) : (n = r.last, n !== null ? n.sibling = s : t.child = s, r.last = s)
            }
            return r.tail !== null ? (n = r.tail, r.rendering = n, r.tail = n.sibling, r.lastEffect = t.lastEffect, r.renderingStartTime = le(), n.sibling = null, t = W.current, U(W, l ? t & 1 | 2 : t & 1), n) : null;
        case 23:
        case 24:
            return ks(), e !== null && e.memoizedState !== null != (t.memoizedState !== null) && r.mode !== "unstable-defer-without-hiding" && (t.flags |= 4), null
    }
    throw Error(C(156, t.tag))
}

function ud(e) {
    switch (e.tag) {
        case 1:
            de(e.type) && Vr();
            var t = e.flags;
            return t & 4096 ? (e.flags = t & -4097 | 64, e) : null;
        case 3:
            if (nn(), V(ce), V(ie), Kl(), t = e.flags, (t & 64) != 0) throw Error(C(285));
            return e.flags = t & -4097 | 64, e;
        case 5:
            return Xl(e), null;
        case 13:
            return V(W), t = e.flags, t & 4096 ? (e.flags = t & -4097 | 64, e) : null;
        case 19:
            return V(W), null;
        case 4:
            return nn(), null;
        case 10:
            return Wl(e), null;
        case 23:
        case 24:
            return ks(), null;
        default:
            return null
    }
}

function us(e, t) {
    try {
        var n = "",
            r = t;
        do n += Uf(r), r = r.return; while (r);
        var i = n
    } catch (l) {
        i = `
Error generating stack: ` + l.message + `
` + l.stack
    }
    return {
        value: e,
        source: t,
        stack: i
    }
}

function fs(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var fd = typeof WeakMap == "function" ? WeakMap : Map;

function Mu(e, t, n) {
    n = tt(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        ui || (ui = !0, Ss = r), fs(e, t)
    }, n
}

function Nu(e, t, n) {
    n = tt(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var i = t.value;
        n.payload = function() {
            return fs(e, t), r(i)
        }
    }
    var l = e.stateNode;
    return l !== null && typeof l.componentDidCatch == "function" && (n.callback = function() {
        typeof r != "function" && (Ie === null ? Ie = new Set([this]) : Ie.add(this), fs(e, t));
        var s = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: s !== null ? s : ""
        })
    }), n
}
var cd = typeof WeakSet == "function" ? WeakSet : Set;

function zu(e) {
    var t = e.ref;
    if (t !== null)
        if (typeof t == "function") try {
            t(null)
        } catch (n) {
            at(e, n)
        } else t.current = null
}

function dd(e, t) {
    switch (t.tag) {
        case 0:
        case 11:
        case 15:
        case 22:
            return;
        case 1:
            if (t.flags & 256 && e !== null) {
                var n = e.memoizedProps,
                    r = e.memoizedState;
                e = t.stateNode, t = e.getSnapshotBeforeUpdate(t.elementType === t.type ? n : Pe(t.type, n), r), e.__reactInternalSnapshotBeforeUpdate = t
            }
            return;
        case 3:
            t.flags & 256 && $l(t.stateNode.containerInfo);
            return;
        case 5:
        case 6:
        case 4:
        case 17:
            return
    }
    throw Error(C(163))
}

function pd(e, t, n) {
    switch (n.tag) {
        case 0:
        case 11:
        case 15:
        case 22:
            if (t = n.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
                e = t = t.next;
                do {
                    if ((e.tag & 3) == 3) {
                        var r = e.create;
                        e.destroy = r()
                    }
                    e = e.next
                } while (e !== t)
            }
            if (t = n.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
                e = t = t.next;
                do {
                    var i = e;
                    r = i.next, i = i.tag, (i & 4) != 0 && (i & 1) != 0 && (bu(n, e), Ed(n, e)), e = r
                } while (e !== t)
            }
            return;
        case 1:
            e = n.stateNode, n.flags & 4 && (t === null ? e.componentDidMount() : (r = n.elementType === n.type ? t.memoizedProps : Pe(n.type, t.memoizedProps), e.componentDidUpdate(r, t.memoizedState, e.__reactInternalSnapshotBeforeUpdate))), t = n.updateQueue, t !== null && Xa(n, t, e);
            return;
        case 3:
            if (t = n.updateQueue, t !== null) {
                if (e = null, n.child !== null) switch (n.child.tag) {
                    case 5:
                        e = n.child.stateNode;
                        break;
                    case 1:
                        e = n.child.stateNode
                }
                Xa(n, t, e)
            }
            return;
        case 5:
            e = n.stateNode, t === null && n.flags & 4 && Oa(n.type, n.memoizedProps) && e.focus();
            return;
        case 6:
            return;
        case 4:
            return;
        case 12:
            return;
        case 13:
            n.memoizedState === null && (n = n.alternate, n !== null && (n = n.memoizedState, n !== null && (n = n.dehydrated, n !== null && Wo(n))));
            return;
        case 19:
        case 17:
        case 20:
        case 21:
        case 23:
        case 24:
            return
    }
    throw Error(C(163))
}

function Iu(e, t) {
    for (var n = e;;) {
        if (n.tag === 5) {
            var r = n.stateNode;
            if (t) r = r.style, typeof r.setProperty == "function" ? r.setProperty("display", "none", "important") : r.display = "none";
            else {
                r = n.stateNode;
                var i = n.memoizedProps.style;
                i = i != null && i.hasOwnProperty("display") ? i.display : null, r.style.display = _o("display", i)
            }
        } else if (n.tag === 6) n.stateNode.nodeValue = t ? "" : n.memoizedProps;
        else if ((n.tag !== 23 && n.tag !== 24 || n.memoizedState === null || n === e) && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === e) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === e) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
}

function $u(e, t) {
    if (Tt && typeof Tt.onCommitFiberUnmount == "function") try {
        Tt.onCommitFiberUnmount(Al, t)
    } catch {}
    switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
        case 22:
            if (e = t.updateQueue, e !== null && (e = e.lastEffect, e !== null)) {
                var n = e = e.next;
                do {
                    var r = n,
                        i = r.destroy;
                    if (r = r.tag, i !== void 0)
                        if ((r & 4) != 0) bu(t, n);
                        else {
                            r = t;
                            try {
                                i()
                            } catch (l) {
                                at(r, l)
                            }
                        }
                    n = n.next
                } while (n !== e)
            }
            break;
        case 1:
            if (zu(t), e = t.stateNode, typeof e.componentWillUnmount == "function") try {
                e.props = t.memoizedProps, e.state = t.memoizedState, e.componentWillUnmount()
            } catch (l) {
                at(t, l)
            }
            break;
        case 5:
            zu(t);
            break;
        case 4:
            Fu(e, t)
    }
}

function Du(e) {
    e.alternate = null, e.child = null, e.dependencies = null, e.firstEffect = null, e.lastEffect = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.return = null, e.updateQueue = null
}

function Ru(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function Au(e) {
    e: {
        for (var t = e.return; t !== null;) {
            if (Ru(t)) break e;
            t = t.return
        }
        throw Error(C(160))
    }
    var n = t;
    switch (t = n.stateNode, n.tag) {
        case 5:
            var r = !1;
            break;
        case 3:
            t = t.containerInfo, r = !0;
            break;
        case 4:
            t = t.containerInfo, r = !0;
            break;
        default:
            throw Error(C(161))
    }
    n.flags & 16 && (Sn(t, ""), n.flags &= -17);e: t: for (n = e;;) {
        for (; n.sibling === null;) {
            if (n.return === null || Ru(n.return)) {
                n = null;
                break e
            }
            n = n.return
        }
        for (n.sibling.return = n.return, n = n.sibling; n.tag !== 5 && n.tag !== 6 && n.tag !== 18;) {
            if (n.flags & 2 || n.child === null || n.tag === 4) continue t;
            n.child.return = n, n = n.child
        }
        if (!(n.flags & 2)) {
            n = n.stateNode;
            break e
        }
    }
    r ? cs(e, n, t) : ds(e, n, t)
}

function cs(e, t, n) {
    var r = e.tag,
        i = r === 5 || r === 6;
    if (i) e = i ? e.stateNode : e.stateNode.instance, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Ar));
    else if (r !== 4 && (e = e.child, e !== null))
        for (cs(e, t, n), e = e.sibling; e !== null;) cs(e, t, n), e = e.sibling
}

function ds(e, t, n) {
    var r = e.tag,
        i = r === 5 || r === 6;
    if (i) e = i ? e.stateNode : e.stateNode.instance, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (ds(e, t, n), e = e.sibling; e !== null;) ds(e, t, n), e = e.sibling
}

function Fu(e, t) {
    for (var n = t, r = !1, i, l;;) {
        if (!r) {
            r = n.return;
            e: for (;;) {
                if (r === null) throw Error(C(160));
                switch (i = r.stateNode, r.tag) {
                    case 5:
                        l = !1;
                        break e;
                    case 3:
                        i = i.containerInfo, l = !0;
                        break e;
                    case 4:
                        i = i.containerInfo, l = !0;
                        break e
                }
                r = r.return
            }
            r = !0
        }
        if (n.tag === 5 || n.tag === 6) {
            e: for (var s = e, a = n, o = a;;)
                if ($u(s, o), o.child !== null && o.tag !== 4) o.child.return = o, o = o.child;
                else {
                    if (o === a) break e;
                    for (; o.sibling === null;) {
                        if (o.return === null || o.return === a) break e;
                        o = o.return
                    }
                    o.sibling.return = o.return, o = o.sibling
                }l ? (s = i, a = n.stateNode, s.nodeType === 8 ? s.parentNode.removeChild(a) : s.removeChild(a)) : i.removeChild(n.stateNode)
        }
        else if (n.tag === 4) {
            if (n.child !== null) {
                i = n.stateNode.containerInfo, l = !0, n.child.return = n, n = n.child;
                continue
            }
        } else if ($u(e, n), n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return, n.tag === 4 && (r = !1)
        }
        n.sibling.return = n.return, n = n.sibling
    }
}

function ps(e, t) {
    switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
        case 22:
            var n = t.updateQueue;
            if (n = n !== null ? n.lastEffect : null, n !== null) {
                var r = n = n.next;
                do(r.tag & 3) == 3 && (e = r.destroy, r.destroy = void 0, e !== void 0 && e()), r = r.next; while (r !== n)
            }
            return;
        case 1:
            return;
        case 5:
            if (n = t.stateNode, n != null) {
                r = t.memoizedProps;
                var i = e !== null ? e.memoizedProps : r;
                e = t.type;
                var l = t.updateQueue;
                if (t.updateQueue = null, l !== null) {
                    for (n[jr] = r, e === "input" && r.type === "radio" && r.name != null && So(n, r), el(e, i), t = el(e, r), i = 0; i < l.length; i += 2) {
                        var s = l[i],
                            a = l[i + 1];
                        s === "style" ? Lo(n, a) : s === "dangerouslySetInnerHTML" ? Po(n, a) : s === "children" ? Sn(n, a) : Di(n, s, a, t)
                    }
                    switch (e) {
                        case "input":
                            bi(n, r);
                            break;
                        case "textarea":
                            xo(n, r);
                            break;
                        case "select":
                            e = n._wrapperState.wasMultiple, n._wrapperState.wasMultiple = !!r.multiple, l = r.value, l != null ? Ft(n, !!r.multiple, l, !1) : e !== !!r.multiple && (r.defaultValue != null ? Ft(n, !!r.multiple, r.defaultValue, !0) : Ft(n, !!r.multiple, r.multiple ? [] : "", !1))
                    }
                }
            }
            return;
        case 6:
            if (t.stateNode === null) throw Error(C(162));
            t.stateNode.nodeValue = t.memoizedProps;
            return;
        case 3:
            n = t.stateNode, n.hydrate && (n.hydrate = !1, Wo(n.containerInfo));
            return;
        case 12:
            return;
        case 13:
            t.memoizedState !== null && (ys = le(), Iu(t.child, !0)), ju(t);
            return;
        case 19:
            ju(t);
            return;
        case 17:
            return;
        case 23:
        case 24:
            Iu(t, t.memoizedState !== null);
            return
    }
    throw Error(C(163))
}

function ju(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new cd), t.forEach(function(r) {
            var i = Td.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(i, i))
        })
    }
}

function hd(e, t) {
    return e !== null && (e = e.memoizedState, e === null || e.dehydrated !== null) ? (t = t.memoizedState, t !== null && t.dehydrated === null) : !1
}
var md = Math.ceil,
    oi = yt.ReactCurrentDispatcher,
    hs = yt.ReactCurrentOwner,
    $ = 0,
    ue = null,
    Q = null,
    oe = 0,
    Ot = 0,
    ms = Ze(0),
    ne = 0,
    ai = null,
    ln = 0,
    er = 0,
    sn = 0,
    gs = 0,
    vs = null,
    ys = 0,
    ws = 1 / 0;

function on() {
    ws = le() + 500
}
var M = null,
    ui = !1,
    Ss = null,
    Ie = null,
    it = !1,
    tr = null,
    nr = 90,
    Es = [],
    Cs = [],
    Ve = null,
    rr = 0,
    xs = null,
    fi = -1,
    He = 0,
    ci = 0,
    ir = null,
    di = !1;

function ve() {
    return ($ & 48) != 0 ? le() : fi !== -1 ? fi : fi = le()
}

function lt(e) {
    if (e = e.mode, (e & 2) == 0) return 1;
    if ((e & 4) == 0) return Jt() === 99 ? 1 : 2;
    if (He === 0 && (He = ln), nd.transition !== 0) {
        ci !== 0 && (ci = vs !== null ? vs.pendingLanes : 0), e = He;
        var t = 4186112 & ~ci;
        return t &= -t, t === 0 && (e = 4186112 & ~e, t = e & -e, t === 0 && (t = 8192)), t
    }
    return e = Jt(), ($ & 4) != 0 && e === 98 ? e = Lr(12, He) : (e = lc(e), e = Lr(e, He)), e
}

function st(e, t, n) {
    if (50 < rr) throw rr = 0, xs = null, Error(C(185));
    if (e = pi(e, t), e === null) return null;
    Or(e, t, n), e === ue && (sn |= t, ne === 4 && an(e, oe));
    var r = Jt();
    t === 1 ? ($ & 8) != 0 && ($ & 48) == 0 ? Ts(e) : (xe(e, n), $ === 0 && (on(), Oe())) : (($ & 4) == 0 || r !== 98 && r !== 99 || (Ve === null ? Ve = new Set([e]) : Ve.add(e)), xe(e, n)), vs = e
}

function pi(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}

function xe(e, t) {
    for (var n = e.callbackNode, r = e.suspendedLanes, i = e.pingedLanes, l = e.expirationTimes, s = e.pendingLanes; 0 < s;) {
        var a = 31 - Qe(s),
            o = 1 << a,
            f = l[a];
        if (f === -1) {
            if ((o & r) == 0 || (o & i) != 0) {
                f = t, Ht(o);
                var d = j;
                l[a] = 10 <= d ? f + 250 : 6 <= d ? f + 5e3 : -1
            }
        } else f <= t && (e.expiredLanes |= o);
        s &= ~o
    }
    if (r = Mn(e, e === ue ? oe : 0), t = j, r === 0) n !== null && (n !== Vl && jl(n), e.callbackNode = null, e.callbackPriority = 0);
    else {
        if (n !== null) {
            if (e.callbackPriority === t) return;
            n !== Vl && jl(n)
        }
        t === 15 ? (n = Ts.bind(null, e), Fe === null ? (Fe = [n], Wr = Fl(Ur, Wa)) : Fe.push(n), n = Vl) : t === 14 ? n = Vn(99, Ts.bind(null, e)) : (n = sc(t), n = Vn(n, Bu.bind(null, e))), e.callbackPriority = t, e.callbackNode = n
    }
}

function Bu(e) {
    if (fi = -1, ci = He = 0, ($ & 48) != 0) throw Error(C(327));
    var t = e.callbackNode;
    if (ot() && e.callbackNode !== t) return null;
    var n = Mn(e, e === ue ? oe : 0);
    if (n === 0) return null;
    var r = n,
        i = $;
    $ |= 16;
    var l = Wu();
    (ue !== e || oe !== r) && (on(), un(e, r));
    do try {
        yd();
        break
    } catch (a) {
        Uu(e, a)
    }
    while (1);
    if (Ul(), oi.current = l, $ = i, Q !== null ? r = 0 : (ue = null, oe = 0, r = ne), (ln & sn) != 0) un(e, 0);
    else if (r !== 0) {
        if (r === 2 && ($ |= 64, e.hydrate && (e.hydrate = !1, $l(e.containerInfo)), n = Ko(e), n !== 0 && (r = lr(e, n))), r === 1) throw t = ai, un(e, 0), an(e, n), xe(e, le()), t;
        switch (e.finishedWork = e.current.alternate, e.finishedLanes = n, r) {
            case 0:
            case 1:
                throw Error(C(345));
            case 2:
                Mt(e);
                break;
            case 3:
                if (an(e, n), (n & 62914560) === n && (r = ys + 500 - le(), 10 < r)) {
                    if (Mn(e, 0) !== 0) break;
                    if (i = e.suspendedLanes, (i & n) !== n) {
                        ve(), e.pingedLanes |= e.suspendedLanes & i;
                        break
                    }
                    e.timeoutHandle = Ma(Mt.bind(null, e), r);
                    break
                }
                Mt(e);
                break;
            case 4:
                if (an(e, n), (n & 4186112) === n) break;
                for (r = e.eventTimes, i = -1; 0 < n;) {
                    var s = 31 - Qe(n);
                    l = 1 << s, s = r[s], s > i && (i = s), n &= ~l
                }
                if (n = i, n = le() - n, n = (120 > n ? 120 : 480 > n ? 480 : 1080 > n ? 1080 : 1920 > n ? 1920 : 3e3 > n ? 3e3 : 4320 > n ? 4320 : 1960 * md(n / 1960)) - n, 10 < n) {
                    e.timeoutHandle = Ma(Mt.bind(null, e), n);
                    break
                }
                Mt(e);
                break;
            case 5:
                Mt(e);
                break;
            default:
                throw Error(C(329))
        }
    }
    return xe(e, le()), e.callbackNode === t ? Bu.bind(null, e) : null
}

function an(e, t) {
    for (t &= ~gs, t &= ~sn, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - Qe(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function Ts(e) {
    if (($ & 48) != 0) throw Error(C(327));
    if (ot(), e === ue && (e.expiredLanes & oe) != 0) {
        var t = oe,
            n = lr(e, t);
        (ln & sn) != 0 && (t = Mn(e, t), n = lr(e, t))
    } else t = Mn(e, 0), n = lr(e, t);
    if (e.tag !== 0 && n === 2 && ($ |= 64, e.hydrate && (e.hydrate = !1, $l(e.containerInfo)), t = Ko(e), t !== 0 && (n = lr(e, t))), n === 1) throw n = ai, un(e, 0), an(e, t), xe(e, le()), n;
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, Mt(e), xe(e, le()), null
}

function gd() {
    if (Ve !== null) {
        var e = Ve;
        Ve = null, e.forEach(function(t) {
            t.expiredLanes |= 24 & t.pendingLanes, xe(t, le())
        })
    }
    Oe()
}

function Vu(e, t) {
    var n = $;
    $ |= 1;
    try {
        return e(t)
    } finally {
        $ = n, $ === 0 && (on(), Oe())
    }
}

function Hu(e, t) {
    var n = $;
    $ &= -2, $ |= 8;
    try {
        return e(t)
    } finally {
        $ = n, $ === 0 && (on(), Oe())
    }
}

function hi(e, t) {
    U(ms, Ot), Ot |= t, ln |= t
}

function ks() {
    Ot = ms.current, V(ms)
}

function un(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, qc(n)), Q !== null)
        for (n = Q.return; n !== null;) {
            var r = n;
            switch (r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && Vr();
                    break;
                case 3:
                    nn(), V(ce), V(ie), Kl();
                    break;
                case 5:
                    Xl(r);
                    break;
                case 4:
                    nn();
                    break;
                case 13:
                    V(W);
                    break;
                case 19:
                    V(W);
                    break;
                case 10:
                    Wl(r);
                    break;
                case 23:
                case 24:
                    ks()
            }
            n = n.return
        }
    ue = e, Q = ut(e.current, null), oe = Ot = ln = t, ne = 0, ai = null, gs = sn = er = 0
}

function Uu(e, t) {
    do {
        var n = Q;
        try {
            if (Ul(), bn.current = li, ti) {
                for (var r = Y.memoizedState; r !== null;) {
                    var i = r.queue;
                    i !== null && (i.pending = null), r = r.next
                }
                ti = !1
            }
            if (Xn = 0, te = se = Y = null, Qn = !1, hs.current = null, n === null || n.return === null) {
                ne = 1, ai = t, Q = null;
                break
            }
            e: {
                var l = e,
                    s = n.return,
                    a = n,
                    o = t;
                if (t = oe, a.flags |= 2048, a.firstEffect = a.lastEffect = null, o !== null && typeof o == "object" && typeof o.then == "function") {
                    var f = o;
                    if ((a.mode & 2) == 0) {
                        var d = a.alternate;
                        d ? (a.updateQueue = d.updateQueue, a.memoizedState = d.memoizedState, a.lanes = d.lanes) : (a.updateQueue = null, a.memoizedState = null)
                    }
                    var m = (W.current & 1) != 0,
                        h = s;
                    do {
                        var y;
                        if (y = h.tag === 13) {
                            var S = h.memoizedState;
                            if (S !== null) y = S.dehydrated !== null;
                            else {
                                var E = h.memoizedProps;
                                y = E.fallback === void 0 ? !1 : E.unstable_avoidThisFallback !== !0 ? !0 : !m
                            }
                        }
                        if (y) {
                            var c = h.updateQueue;
                            if (c === null) {
                                var u = new Set;
                                u.add(f), h.updateQueue = u
                            } else c.add(f);
                            if ((h.mode & 2) == 0) {
                                if (h.flags |= 64, a.flags |= 16384, a.flags &= -2981, a.tag === 1)
                                    if (a.alternate === null) a.tag = 17;
                                    else {
                                        var p = tt(-1, 1);
                                        p.tag = 2, nt(a, p)
                                    }
                                a.lanes |= 1;
                                break e
                            }
                            o = void 0, a = t;
                            var g = l.pingCache;
                            if (g === null ? (g = l.pingCache = new fd, o = new Set, g.set(f, o)) : (o = g.get(f), o === void 0 && (o = new Set, g.set(f, o))), !o.has(a)) {
                                o.add(a);
                                var v = xd.bind(null, l, f, a);
                                f.then(v, v)
                            }
                            h.flags |= 4096, h.lanes = t;
                            break e
                        }
                        h = h.return
                    } while (h !== null);
                    o = Error((At(a.type) || "A React component") + ` suspended while rendering, but no fallback UI was specified.

Add a <Suspense fallback=...> component higher in the tree to provide a loading indicator or placeholder to display.`)
                }
                ne !== 5 && (ne = 2),
                o = us(o, a),
                h = s;do {
                    switch (h.tag) {
                        case 3:
                            l = o, h.flags |= 4096, t &= -t, h.lanes |= t;
                            var T = Mu(h, l, t);
                            ba(h, T);
                            break e;
                        case 1:
                            l = o;
                            var w = h.type,
                                P = h.stateNode;
                            if ((h.flags & 64) == 0 && (typeof w.getDerivedStateFromError == "function" || P !== null && typeof P.componentDidCatch == "function" && (Ie === null || !Ie.has(P)))) {
                                h.flags |= 4096, t &= -t, h.lanes |= t;
                                var x = Nu(h, l, t);
                                ba(h, x);
                                break e
                            }
                    }
                    h = h.return
                } while (h !== null)
            }
            Yu(n)
        } catch (O) {
            t = O, Q === n && n !== null && (Q = n = n.return);
            continue
        }
        break
    } while (1)
}

function Wu() {
    var e = oi.current;
    return oi.current = li, e === null ? li : e
}

function lr(e, t) {
    var n = $;
    $ |= 16;
    var r = Wu();
    ue === e && oe === t || un(e, t);
    do try {
        vd();
        break
    } catch (i) {
        Uu(e, i)
    }
    while (1);
    if (Ul(), $ = n, oi.current = r, Q !== null) throw Error(C(261));
    return ue = null, oe = 0, ne
}

function vd() {
    for (; Q !== null;) Gu(Q)
}

function yd() {
    for (; Q !== null && !Jc();) Gu(Q)
}

function Gu(e) {
    var t = Qu(e.alternate, e, Ot);
    e.memoizedProps = e.pendingProps, t === null ? Yu(e) : Q = t, hs.current = null
}

function Yu(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, (t.flags & 2048) == 0) {
            if (n = ad(n, t, Ot), n !== null) {
                Q = n;
                return
            }
            if (n = t, n.tag !== 24 && n.tag !== 23 || n.memoizedState === null || (Ot & 1073741824) != 0 || (n.mode & 4) == 0) {
                for (var r = 0, i = n.child; i !== null;) r |= i.lanes | i.childLanes, i = i.sibling;
                n.childLanes = r
            }
            e !== null && (e.flags & 2048) == 0 && (e.firstEffect === null && (e.firstEffect = t.firstEffect), t.lastEffect !== null && (e.lastEffect !== null && (e.lastEffect.nextEffect = t.firstEffect), e.lastEffect = t.lastEffect), 1 < t.flags && (e.lastEffect !== null ? e.lastEffect.nextEffect = t : e.firstEffect = t, e.lastEffect = t))
        } else {
            if (n = ud(t), n !== null) {
                n.flags &= 2047, Q = n;
                return
            }
            e !== null && (e.firstEffect = e.lastEffect = null, e.flags |= 2048)
        }
        if (t = t.sibling, t !== null) {
            Q = t;
            return
        }
        Q = t = e
    } while (t !== null);
    ne === 0 && (ne = 5)
}

function Mt(e) {
    var t = Jt();
    return kt(99, wd.bind(null, e, t)), null
}

function wd(e, t) {
    do ot(); while (tr !== null);
    if (($ & 48) != 0) throw Error(C(327));
    var n = e.finishedWork;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(C(177));
    e.callbackNode = null;
    var r = n.lanes | n.childLanes,
        i = r,
        l = e.pendingLanes & ~i;
    e.pendingLanes = i, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= i, e.mutableReadLanes &= i, e.entangledLanes &= i, i = e.entanglements;
    for (var s = e.eventTimes, a = e.expirationTimes; 0 < l;) {
        var o = 31 - Qe(l),
            f = 1 << o;
        i[o] = 0, s[o] = -1, a[o] = -1, l &= ~f
    }
    if (Ve !== null && (r & 24) == 0 && Ve.has(e) && Ve.delete(e), e === ue && (Q = ue = null, oe = 0), 1 < n.flags ? n.lastEffect !== null ? (n.lastEffect.nextEffect = n, r = n.firstEffect) : r = n : r = n.firstEffect, r !== null) {
        if (i = $, $ |= 32, hs.current = null, Nl = Mr, s = va(), _l(s)) {
            if ("selectionStart" in s) a = {
                start: s.selectionStart,
                end: s.selectionEnd
            };
            else e: if (a = (a = s.ownerDocument) && a.defaultView || window, (f = a.getSelection && a.getSelection()) && f.rangeCount !== 0) {
                a = f.anchorNode, l = f.anchorOffset, o = f.focusNode, f = f.focusOffset;
                try {
                    a.nodeType, o.nodeType
                } catch {
                    a = null;
                    break e
                }
                var d = 0,
                    m = -1,
                    h = -1,
                    y = 0,
                    S = 0,
                    E = s,
                    c = null;
                t: for (;;) {
                    for (var u; E !== a || l !== 0 && E.nodeType !== 3 || (m = d + l), E !== o || f !== 0 && E.nodeType !== 3 || (h = d + f), E.nodeType === 3 && (d += E.nodeValue.length), (u = E.firstChild) !== null;) c = E, E = u;
                    for (;;) {
                        if (E === s) break t;
                        if (c === a && ++y === l && (m = d), c === o && ++S === f && (h = d), (u = E.nextSibling) !== null) break;
                        E = c, c = E.parentNode
                    }
                    E = u
                }
                a = m === -1 || h === -1 ? null : {
                    start: m,
                    end: h
                }
            } else a = null;
            a = a || {
                start: 0,
                end: 0
            }
        } else a = null;
        zl = {
            focusedElem: s,
            selectionRange: a
        }, Mr = !1, ir = null, di = !1, M = r;
        do try {
            Sd()
        } catch (O) {
            if (M === null) throw Error(C(330));
            at(M, O), M = M.nextEffect
        }
        while (M !== null);
        ir = null, M = r;
        do try {
            for (s = e; M !== null;) {
                var p = M.flags;
                if (p & 16 && Sn(M.stateNode, ""), p & 128) {
                    var g = M.alternate;
                    if (g !== null) {
                        var v = g.ref;
                        v !== null && (typeof v == "function" ? v(null) : v.current = null)
                    }
                }
                switch (p & 1038) {
                    case 2:
                        Au(M), M.flags &= -3;
                        break;
                    case 6:
                        Au(M), M.flags &= -3, ps(M.alternate, M);
                        break;
                    case 1024:
                        M.flags &= -1025;
                        break;
                    case 1028:
                        M.flags &= -1025, ps(M.alternate, M);
                        break;
                    case 4:
                        ps(M.alternate, M);
                        break;
                    case 8:
                        a = M, Fu(s, a);
                        var T = a.alternate;
                        Du(a), T !== null && Du(T)
                }
                M = M.nextEffect
            }
        } catch (O) {
            if (M === null) throw Error(C(330));
            at(M, O), M = M.nextEffect
        }
        while (M !== null);
        if (v = zl, g = va(), p = v.focusedElem, s = v.selectionRange, g !== p && p && p.ownerDocument && ga(p.ownerDocument.documentElement, p)) {
            for (s !== null && _l(p) && (g = s.start, v = s.end, v === void 0 && (v = g), "selectionStart" in p ? (p.selectionStart = g, p.selectionEnd = Math.min(v, p.value.length)) : (v = (g = p.ownerDocument || document) && g.defaultView || window, v.getSelection && (v = v.getSelection(), a = p.textContent.length, T = Math.min(s.start, a), s = s.end === void 0 ? T : Math.min(s.end, a), !v.extend && T > s && (a = s, s = T, T = a), a = ma(p, T), l = ma(p, s), a && l && (v.rangeCount !== 1 || v.anchorNode !== a.node || v.anchorOffset !== a.offset || v.focusNode !== l.node || v.focusOffset !== l.offset) && (g = g.createRange(), g.setStart(a.node, a.offset), v.removeAllRanges(), T > s ? (v.addRange(g), v.extend(l.node, l.offset)) : (g.setEnd(l.node, l.offset), v.addRange(g)))))), g = [], v = p; v = v.parentNode;) v.nodeType === 1 && g.push({
                element: v,
                left: v.scrollLeft,
                top: v.scrollTop
            });
            for (typeof p.focus == "function" && p.focus(), p = 0; p < g.length; p++) v = g[p], v.element.scrollLeft = v.left, v.element.scrollTop = v.top
        }
        Mr = !!Nl, zl = Nl = null, e.current = n, M = r;
        do try {
            for (p = e; M !== null;) {
                var w = M.flags;
                if (w & 36 && pd(p, M.alternate, M), w & 128) {
                    g = void 0;
                    var P = M.ref;
                    if (P !== null) {
                        var x = M.stateNode;
                        switch (M.tag) {
                            case 5:
                                g = x;
                                break;
                            default:
                                g = x
                        }
                        typeof P == "function" ? P(g) : P.current = g
                    }
                }
                M = M.nextEffect
            }
        } catch (O) {
            if (M === null) throw Error(C(330));
            at(M, O), M = M.nextEffect
        }
        while (M !== null);
        M = null, td(), $ = i
    } else e.current = n;
    if (it) it = !1, tr = e, nr = t;
    else
        for (M = r; M !== null;) t = M.nextEffect, M.nextEffect = null, M.flags & 8 && (w = M, w.sibling = null, w.stateNode = null), M = t;
    if (r = e.pendingLanes, r === 0 && (Ie = null), r === 1 ? e === xs ? rr++ : (rr = 0, xs = e) : rr = 0, n = n.stateNode, Tt && typeof Tt.onCommitFiberRoot == "function") try {
        Tt.onCommitFiberRoot(Al, n, void 0, (n.current.flags & 64) == 64)
    } catch {}
    if (xe(e, le()), ui) throw ui = !1, e = Ss, Ss = null, e;
    return ($ & 8) != 0 || Oe(), null
}

function Sd() {
    for (; M !== null;) {
        var e = M.alternate;
        di || ir === null || ((M.flags & 8) != 0 ? Ao(M, ir) && (di = !0) : M.tag === 13 && hd(e, M) && Ao(M, ir) && (di = !0));
        var t = M.flags;
        (t & 256) != 0 && dd(e, M), (t & 512) == 0 || it || (it = !0, Vn(97, function() {
            return ot(), null
        })), M = M.nextEffect
    }
}

function ot() {
    if (nr !== 90) {
        var e = 97 < nr ? 97 : nr;
        return nr = 90, kt(e, Cd)
    }
    return !1
}

function Ed(e, t) {
    Es.push(t, e), it || (it = !0, Vn(97, function() {
        return ot(), null
    }))
}

function bu(e, t) {
    Cs.push(t, e), it || (it = !0, Vn(97, function() {
        return ot(), null
    }))
}

function Cd() {
    if (tr === null) return !1;
    var e = tr;
    if (tr = null, ($ & 48) != 0) throw Error(C(331));
    var t = $;
    $ |= 32;
    var n = Cs;
    Cs = [];
    for (var r = 0; r < n.length; r += 2) {
        var i = n[r],
            l = n[r + 1],
            s = i.destroy;
        if (i.destroy = void 0, typeof s == "function") try {
            s()
        } catch (o) {
            if (l === null) throw Error(C(330));
            at(l, o)
        }
    }
    for (n = Es, Es = [], r = 0; r < n.length; r += 2) {
        i = n[r], l = n[r + 1];
        try {
            var a = i.create;
            i.destroy = a()
        } catch (o) {
            if (l === null) throw Error(C(330));
            at(l, o)
        }
    }
    for (a = e.current.firstEffect; a !== null;) e = a.nextEffect, a.nextEffect = null, a.flags & 8 && (a.sibling = null, a.stateNode = null), a = e;
    return $ = t, Oe(), !0
}

function Xu(e, t, n) {
    t = us(n, t), t = Mu(e, t, 1), nt(e, t), t = ve(), e = pi(e, 1), e !== null && (Or(e, 1, t), xe(e, t))
}

function at(e, t) {
    if (e.tag === 3) Xu(e, e, t);
    else
        for (var n = e.return; n !== null;) {
            if (n.tag === 3) {
                Xu(n, e, t);
                break
            } else if (n.tag === 1) {
                var r = n.stateNode;
                if (typeof n.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (Ie === null || !Ie.has(r))) {
                    e = us(t, e);
                    var i = Nu(n, e, 1);
                    if (nt(n, i), i = ve(), n = pi(n, 1), n !== null) Or(n, 1, i), xe(n, i);
                    else if (typeof r.componentDidCatch == "function" && (Ie === null || !Ie.has(r))) try {
                        r.componentDidCatch(t, e)
                    } catch {}
                    break
                }
            }
            n = n.return
        }
}

function xd(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = ve(), e.pingedLanes |= e.suspendedLanes & n, ue === e && (oe & n) === n && (ne === 4 || ne === 3 && (oe & 62914560) === oe && 500 > le() - ys ? un(e, 0) : gs |= n), xe(e, t)
}

function Td(e, t) {
    var n = e.stateNode;
    n !== null && n.delete(t), t = 0, t === 0 && (t = e.mode, (t & 2) == 0 ? t = 1 : (t & 4) == 0 ? t = Jt() === 99 ? 1 : 2 : (He === 0 && (He = ln), t = Ut(62914560 & ~He), t === 0 && (t = 4194304))), n = ve(), e = pi(e, t), e !== null && (Or(e, t, n), xe(e, n))
}
var Qu;
Qu = function(e, t, n) {
    var r = t.lanes;
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || ce.current) _e = !0;
        else if ((n & r) != 0) _e = (e.flags & 16384) != 0;
    else {
        switch (_e = !1, t.tag) {
            case 3:
                Su(t), ql();
                break;
            case 5:
                tu(t);
                break;
            case 1:
                de(t.type) && Hr(t);
                break;
            case 4:
                bl(t, t.stateNode.containerInfo);
                break;
            case 10:
                r = t.memoizedProps.value;
                var i = t.type._context;
                U(Gr, i._currentValue), i._currentValue = r;
                break;
            case 13:
                if (t.memoizedState !== null) return (n & t.child.childLanes) != 0 ? Eu(e, t, n) : (U(W, W.current & 1), t = Be(e, t, n), t !== null ? t.sibling : null);
                U(W, W.current & 1);
                break;
            case 19:
                if (r = (n & t.childLanes) != 0, (e.flags & 64) != 0) {
                    if (r) return Pu(e, t, n);
                    t.flags |= 64
                }
                if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), U(W, W.current), r) break;
                return null;
            case 23:
            case 24:
                return t.lanes = 0, is(e, t, n)
        }
        return Be(e, t, n)
    } else _e = !1;
    switch (t.lanes = 0, t.tag) {
        case 2:
            if (r = t.type, e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), e = t.pendingProps, i = Zt(t, ie.current), tn(t, n), i = Jl(null, t, r, e, i, n), t.flags |= 1, typeof i == "object" && i !== null && typeof i.render == "function" && i.$$typeof === void 0) {
                if (t.tag = 1, t.memoizedState = null, t.updateQueue = null, de(r)) {
                    var l = !0;
                    Hr(t)
                } else l = !1;
                t.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, Gl(t);
                var s = r.getDerivedStateFromProps;
                typeof s == "function" && Xr(t, r, s, e), i.updater = Qr, t.stateNode = i, i._reactInternals = t, Yl(t, r, e, n), t = ss(null, t, r, !0, l, n)
            } else t.tag = 0, he(null, t, i, n), t = t.child;
            return t;
        case 16:
            i = t.elementType;
            e: {
                switch (e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), e = t.pendingProps, l = i._init, i = l(i._payload), t.type = i, l = t.tag = Pd(i), e = Pe(i, e), l) {
                    case 0:
                        t = ls(null, t, i, e, n);
                        break e;
                    case 1:
                        t = wu(null, t, i, e, n);
                        break e;
                    case 11:
                        t = mu(null, t, i, e, n);
                        break e;
                    case 14:
                        t = gu(null, t, i, Pe(i.type, e), r, n);
                        break e
                }
                throw Error(C(306, i, ""))
            }
            return t;
        case 0:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Pe(r, i), ls(e, t, r, i, n);
        case 1:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Pe(r, i), wu(e, t, r, i, n);
        case 3:
            if (Su(t), r = t.updateQueue, e === null || r === null) throw Error(C(282));
            if (r = t.pendingProps, i = t.memoizedState, i = i !== null ? i.element : null, Ya(e, t), Hn(t, r, null, n), r = t.memoizedState.element, r === i) ql(), t = Be(e, t, n);
            else {
                if (i = t.stateNode, (l = i.hydrate) && (rt = Xt(t.stateNode.containerInfo.firstChild), je = t, l = Ne = !0), l) {
                    if (e = i.mutableSourceEagerHydrationData, e != null)
                        for (i = 0; i < e.length; i += 2) l = e[i], l._workInProgressVersionPrimary = e[i + 1], rn.push(l);
                    for (n = eu(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 1024, n = n.sibling
                } else he(e, t, r, n), ql();
                t = t.child
            }
            return t;
        case 5:
            return tu(t), e === null && Ql(t), r = t.type, i = t.pendingProps, l = e !== null ? e.memoizedProps : null, s = i.children, Il(r, i) ? s = null : l !== null && Il(r, l) && (t.flags |= 16), yu(e, t), he(e, t, s, n), t.child;
        case 6:
            return e === null && Ql(t), null;
        case 13:
            return Eu(e, t, n);
        case 4:
            return bl(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = Zr(t, null, r, n) : he(e, t, r, n), t.child;
        case 11:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Pe(r, i), mu(e, t, r, i, n);
        case 7:
            return he(e, t, t.pendingProps, n), t.child;
        case 8:
            return he(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return he(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                r = t.type._context,
                i = t.pendingProps,
                s = t.memoizedProps,
                l = i.value;
                var a = t.type._context;
                if (U(Gr, a._currentValue), a._currentValue = l, s !== null)
                    if (a = s.value, l = Se(a, l) ? 0 : (typeof r._calculateChangedBits == "function" ? r._calculateChangedBits(a, l) : 1073741823) | 0, l === 0) {
                        if (s.children === i.children && !ce.current) {
                            t = Be(e, t, n);
                            break e
                        }
                    } else
                        for (a = t.child, a !== null && (a.return = t); a !== null;) {
                            var o = a.dependencies;
                            if (o !== null) {
                                s = a.child;
                                for (var f = o.firstContext; f !== null;) {
                                    if (f.context === r && (f.observedBits & l) != 0) {
                                        a.tag === 1 && (f = tt(-1, n & -n), f.tag = 2, nt(a, f)), a.lanes |= n, f = a.alternate, f !== null && (f.lanes |= n), Ga(a.return, n), o.lanes |= n;
                                        break
                                    }
                                    f = f.next
                                }
                            } else s = a.tag === 10 && a.type === t.type ? null : a.child;
                            if (s !== null) s.return = a;
                            else
                                for (s = a; s !== null;) {
                                    if (s === t) {
                                        s = null;
                                        break
                                    }
                                    if (a = s.sibling, a !== null) {
                                        a.return = s.return, s = a;
                                        break
                                    }
                                    s = s.return
                                }
                            a = s
                        }
                he(e, t, i.children, n),
                t = t.child
            }
            return t;
        case 9:
            return i = t.type, l = t.pendingProps, r = l.children, tn(t, n), i = Ee(i, l.unstable_observedBits), r = r(i), t.flags |= 1, he(e, t, r, n), t.child;
        case 14:
            return i = t.type, l = Pe(i, t.pendingProps), l = Pe(i.type, l), gu(e, t, i, l, r, n);
        case 15:
            return vu(e, t, t.type, t.pendingProps, r, n);
        case 17:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Pe(r, i), e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2), t.tag = 1, de(r) ? (e = !0, Hr(t)) : e = !1, tn(t, n), Ka(t, r, i), Yl(t, r, i, n), ss(null, t, r, !0, e, n);
        case 19:
            return Pu(e, t, n);
        case 23:
            return is(e, t, n);
        case 24:
            return is(e, t, n)
    }
    throw Error(C(156, t.tag))
};

function kd(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.flags = 0, this.lastEffect = this.firstEffect = this.nextEffect = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function Te(e, t, n, r) {
    return new kd(e, t, n, r)
}

function Ps(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function Pd(e) {
    if (typeof e == "function") return Ps(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === gr) return 11;
        if (e === yr) return 14
    }
    return 2
}

function ut(e, t) {
    var n = e.alternate;
    return n === null ? (n = Te(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.nextEffect = null, n.firstEffect = null, n.lastEffect = null), n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function mi(e, t, n, r, i, l) {
    var s = 2;
    if (r = e, typeof e == "function") Ps(e) && (s = 1);
    else if (typeof e == "string") s = 5;
    else e: switch (e) {
        case We:
            return fn(n.children, i, l, t);
        case mo:
            s = 8, i |= 16;
            break;
        case Ri:
            s = 8, i |= 1;
            break;
        case gn:
            return e = Te(12, n, t, i | 8), e.elementType = gn, e.type = gn, e.lanes = l, e;
        case vn:
            return e = Te(13, n, t, i), e.type = vn, e.elementType = vn, e.lanes = l, e;
        case vr:
            return e = Te(19, n, t, i), e.elementType = vr, e.lanes = l, e;
        case Hi:
            return _s(n, i, l, t);
        case Ui:
            return e = Te(24, n, t, i), e.elementType = Ui, e.lanes = l, e;
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case Ai:
                    s = 10;
                    break e;
                case Fi:
                    s = 9;
                    break e;
                case gr:
                    s = 11;
                    break e;
                case yr:
                    s = 14;
                    break e;
                case ji:
                    s = 16, r = null;
                    break e;
                case Bi:
                    s = 22;
                    break e
            }
            throw Error(C(130, e == null ? e : typeof e, ""))
    }
    return t = Te(s, n, t, i), t.elementType = e, t.type = r, t.lanes = l, t
}

function fn(e, t, n, r) {
    return e = Te(7, e, r, t), e.lanes = n, e
}

function _s(e, t, n, r) {
    return e = Te(23, e, r, t), e.elementType = Hi, e.lanes = n, e
}

function Ls(e, t, n) {
    return e = Te(6, e, null, t), e.lanes = n, e
}

function Os(e, t, n) {
    return t = Te(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function _d(e, t, n) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.pendingContext = this.context = null, this.hydrate = n, this.callbackNode = null, this.callbackPriority = 0, this.eventTimes = ml(0), this.expirationTimes = ml(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = ml(0), this.mutableSourceEagerHydrationData = null
}

function Ld(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: wt,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function gi(e, t, n, r) {
    var i = t.current,
        l = ve(),
        s = lt(i);
    e: if (n) {
        n = n._reactInternals;
        t: {
            if (Et(n) !== n || n.tag !== 1) throw Error(C(170));
            var a = n;do {
                switch (a.tag) {
                    case 3:
                        a = a.stateNode.context;
                        break t;
                    case 1:
                        if (de(a.type)) {
                            a = a.stateNode.__reactInternalMemoizedMergedChildContext;
                            break t
                        }
                }
                a = a.return
            } while (a !== null);
            throw Error(C(171))
        }
        if (n.tag === 1) {
            var o = n.type;
            if (de(o)) {
                n = Da(n, o, a);
                break e
            }
        }
        n = a
    } else n = Je;
    return t.context === null ? t.context = n : t.pendingContext = n, t = tt(l, s), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), nt(i, t), st(i, s, l), s
}

function Ms(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function qu(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function Ns(e, t) {
    qu(e, t), (e = e.alternate) && qu(e, t)
}

function Od() {
    return null
}

function zs(e, t, n) {
    var r = n != null && n.hydrationOptions != null && n.hydrationOptions.mutableSources || null;
    if (n = new _d(e, t, n != null && n.hydrate === !0), t = Te(3, null, null, t === 2 ? 7 : t === 1 ? 3 : 0), n.current = t, t.stateNode = n, Gl(t), e[Qt] = n.current, Ta(e.nodeType === 8 ? e.parentNode : e), r)
        for (e = 0; e < r.length; e++) {
            t = r[e];
            var i = t._getVersion;
            i = i(t._source), n.mutableSourceEagerHydrationData == null ? n.mutableSourceEagerHydrationData = [t, i] : n.mutableSourceEagerHydrationData.push(t, i)
        }
    this._internalRoot = n
}
zs.prototype.render = function(e) {
    gi(e, this._internalRoot, null, null)
};
zs.prototype.unmount = function() {
    var e = this._internalRoot,
        t = e.containerInfo;
    gi(null, e, null, function() {
        t[Qt] = null
    })
};

function sr(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function Md(e, t) {
    if (t || (t = e ? e.nodeType === 9 ? e.documentElement : e.firstChild : null, t = !(!t || t.nodeType !== 1 || !t.hasAttribute("data-reactroot"))), !t)
        for (var n; n = e.lastChild;) e.removeChild(n);
    return new zs(e, 0, t ? {
        hydrate: !0
    } : void 0)
}

function vi(e, t, n, r, i) {
    var l = n._reactRootContainer;
    if (l) {
        var s = l._internalRoot;
        if (typeof i == "function") {
            var a = i;
            i = function() {
                var f = Ms(s);
                a.call(f)
            }
        }
        gi(t, s, e, i)
    } else {
        if (l = n._reactRootContainer = Md(n, r), s = l._internalRoot, typeof i == "function") {
            var o = i;
            i = function() {
                var f = Ms(s);
                o.call(f)
            }
        }
        Hu(function() {
            gi(t, s, e, i)
        })
    }
    return Ms(s)
}
Fo = function(e) {
    if (e.tag === 13) {
        var t = ve();
        st(e, 4, t), Ns(e, 4)
    }
};
ul = function(e) {
    if (e.tag === 13) {
        var t = ve();
        st(e, 67108864, t), Ns(e, 67108864)
    }
};
jo = function(e) {
    if (e.tag === 13) {
        var t = ve(),
            n = lt(e);
        st(e, n, t), Ns(e, n)
    }
};
Bo = function(e, t) {
    return t()
};
nl = function(e, t, n) {
    switch (t) {
        case "input":
            if (bi(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var i = Br(r);
                        if (!i) throw Error(C(90));
                        yo(r), bi(r, i)
                    }
                }
            }
            break;
        case "textarea":
            xo(e, n);
            break;
        case "select":
            t = n.value, t != null && Ft(e, !!n.multiple, t, !1)
    }
};
rl = Vu;
zo = function(e, t, n, r, i) {
    var l = $;
    $ |= 4;
    try {
        return kt(98, e.bind(null, t, n, r, i))
    } finally {
        $ = l, $ === 0 && (on(), Oe())
    }
};
il = function() {
    ($ & 49) == 0 && (gd(), ot())
};
Io = function(e, t) {
    var n = $;
    $ |= 2;
    try {
        return e(t)
    } finally {
        $ = n, $ === 0 && (on(), Oe())
    }
};

function Ku(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!sr(t)) throw Error(C(200));
    return Ld(e, t, null, n)
}
var Nd = {
        Events: [Bn, qt, Br, Mo, No, ot, {
            current: !1
        }]
    },
    or = {
        findFiberByHostInstance: Ct,
        bundleType: 0,
        version: "17.0.2",
        rendererPackageName: "react-dom"
    },
    zd = {
        bundleType: or.bundleType,
        version: or.version,
        rendererPackageName: or.rendererPackageName,
        rendererConfig: or.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: yt.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = Ro(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: or.findFiberByHostInstance || Od,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ != "undefined") {
    var yi = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!yi.isDisabled && yi.supportsFiber) try {
        Al = yi.inject(zd), Tt = yi
    } catch {}
}
we.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Nd;
we.createPortal = Ku;
we.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(C(188)) : Error(C(268, Object.keys(e)));
    return e = Ro(t), e = e === null ? null : e.stateNode, e
};
we.flushSync = function(e, t) {
    var n = $;
    if ((n & 48) != 0) return e(t);
    $ |= 1;
    try {
        if (e) return kt(99, e.bind(null, t))
    } finally {
        $ = n, Oe()
    }
};
we.hydrate = function(e, t, n) {
    if (!sr(t)) throw Error(C(200));
    return vi(null, e, t, !0, n)
};
we.render = function(e, t, n) {
    if (!sr(t)) throw Error(C(200));
    return vi(null, e, t, !1, n)
};
we.unmountComponentAtNode = function(e) {
    if (!sr(e)) throw Error(C(40));
    return e._reactRootContainer ? (Hu(function() {
        vi(null, null, e, !1, function() {
            e._reactRootContainer = null, e[Qt] = null
        })
    }), !0) : !1
};
we.unstable_batchedUpdates = Vu;
we.unstable_createPortal = function(e, t) {
    return Ku(e, t, 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null)
};
we.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!sr(n)) throw Error(C(200));
    if (e == null || e._reactInternals === void 0) throw Error(C(38));
    return vi(e, t, n, !1, r)
};
we.version = "17.0.2";

function Zu() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ == "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Zu)
    } catch (e) {
        console.error(e)
    }
}
Zu(), oo.exports = we;
var um = oo.exports;

function wi() {
    return wi = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, wi.apply(this, arguments)
}
var Nt, Is = Nt || (Nt = {});
Is.Pop = "POP";
Is.Push = "PUSH";
Is.Replace = "REPLACE";
var Ju = function(e) {
    return e
};

function ef(e) {
    e.preventDefault(), e.returnValue = ""
}

function tf() {
    var e = [];
    return {
        get length() {
            return e.length
        },
        push: function(t) {
            return e.push(t),
                function() {
                    e = e.filter(function(n) {
                        return n !== t
                    })
                }
        },
        call: function(t) {
            e.forEach(function(n) {
                return n && n(t)
            })
        }
    }
}

function Id() {
    return Math.random().toString(36).substr(2, 8)
}

function $d(e) {
    var t = e.pathname;
    t = t === void 0 ? "/" : t;
    var n = e.search;
    return n = n === void 0 ? "" : n, e = e.hash, e = e === void 0 ? "" : e, n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), e && e !== "#" && (t += e.charAt(0) === "#" ? e : "#" + e), t
}

function nf(e) {
    var t = {};
    if (e) {
        var n = e.indexOf("#");
        0 <= n && (t.hash = e.substr(n), e = e.substr(0, n)), n = e.indexOf("?"), 0 <= n && (t.search = e.substr(n), e = e.substr(0, n)), e && (t.pathname = e)
    }
    return t
}

function Dd(e) {
    function t() {
        var c = o.location,
            u = f.state || {};
        return [u.idx, Ju({
            pathname: c.pathname,
            search: c.search,
            hash: c.hash,
            state: u.usr || null,
            key: u.key || "default"
        })]
    }

    function n(c) {
        return typeof c == "string" ? c : $d(c)
    }

    function r(c, u) {
        return u === void 0 && (u = null), Ju(wi({
            pathname: y.pathname,
            hash: "",
            search: ""
        }, typeof c == "string" ? nf(c) : c, {
            state: u,
            key: Id()
        }))
    }

    function i(c) {
        m = c, c = t(), h = c[0], y = c[1], S.call({
            action: m,
            location: y
        })
    }

    function l(c, u) {
        function p() {
            l(c, u)
        }
        var g = Nt.Push,
            v = r(c, u);
        if (!E.length || (E.call({
                action: g,
                location: v,
                retry: p
            }), !1)) {
            var T = [{
                usr: v.state,
                key: v.key,
                idx: h + 1
            }, n(v)];
            v = T[0], T = T[1];
            try {
                f.pushState(v, "", T)
            } catch {
                o.location.assign(T)
            }
            i(g)
        }
    }

    function s(c, u) {
        function p() {
            s(c, u)
        }
        var g = Nt.Replace,
            v = r(c, u);
        E.length && (E.call({
            action: g,
            location: v,
            retry: p
        }), 1) || (v = [{
            usr: v.state,
            key: v.key,
            idx: h
        }, n(v)], f.replaceState(v[0], "", v[1]), i(g))
    }

    function a(c) {
        f.go(c)
    }
    e === void 0 && (e = {}), e = e.window;
    var o = e === void 0 ? document.defaultView : e,
        f = o.history,
        d = null;
    o.addEventListener("popstate", function() {
        if (d) E.call(d), d = null;
        else {
            var c = Nt.Pop,
                u = t(),
                p = u[0];
            if (u = u[1], E.length) {
                if (p != null) {
                    var g = h - p;
                    g && (d = {
                        action: c,
                        location: u,
                        retry: function() {
                            a(-1 * g)
                        }
                    }, a(g))
                }
            } else i(c)
        }
    });
    var m = Nt.Pop;
    e = t();
    var h = e[0],
        y = e[1],
        S = tf(),
        E = tf();
    return h == null && (h = 0, f.replaceState(wi({}, f.state, {
        idx: h
    }), "")), {
        get action() {
            return m
        },
        get location() {
            return y
        },
        createHref: n,
        push: l,
        replace: s,
        go: a,
        back: function() {
            a(-1)
        },
        forward: function() {
            a(1)
        },
        listen: function(c) {
            return S.push(c)
        },
        block: function(c) {
            var u = E.push(c);
            return E.length === 1 && o.addEventListener("beforeunload", ef),
                function() {
                    u(), E.length || o.removeEventListener("beforeunload", ef)
                }
        }
    }
}
/**
 * React Router v6.2.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function Rd(e, t) {
    if (!e) throw new Error(t)
}
const Ad = R.exports.createContext(null),
    rf = R.exports.createContext(null);

function Fd(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: i = Nt.Pop,
        navigator: l,
        static: s = !1
    } = e;
    jd() && Rd(!1);
    let a = Vd(t),
        o = R.exports.useMemo(() => ({
            basename: a,
            navigator: l,
            static: s
        }), [a, l, s]);
    typeof r == "string" && (r = nf(r));
    let {
        pathname: f = "/",
        search: d = "",
        hash: m = "",
        state: h = null,
        key: y = "default"
    } = r, S = R.exports.useMemo(() => {
        let E = Bd(f, a);
        return E == null ? null : {
            pathname: E,
            search: d,
            hash: m,
            state: h,
            key: y
        }
    }, [a, f, d, m, h, y]);
    return S == null ? null : R.exports.createElement(Ad.Provider, {
        value: o
    }, R.exports.createElement(rf.Provider, {
        children: n,
        value: {
            location: S,
            navigationType: i
        }
    }))
}

function jd() {
    return R.exports.useContext(rf) != null
}

function Bd(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = e.charAt(t.length);
    return n && n !== "/" ? null : e.slice(t.length) || "/"
}
const Vd = e => e.replace(/\/+$/, "").replace(/^\/*/, "/");
/**
 * React Router DOM v6.2.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function fm(e) {
    let {
        basename: t,
        children: n,
        window: r
    } = e, i = R.exports.useRef();
    i.current == null && (i.current = Dd({
        window: r
    }));
    let l = i.current,
        [s, a] = R.exports.useState({
            action: l.action,
            location: l.location
        });
    return R.exports.useLayoutEffect(() => l.listen(a), [l]), R.exports.createElement(Fd, {
        basename: t,
        children: n,
        location: s.location,
        navigationType: s.action,
        navigator: l
    })
}
var Si = {
        exports: {}
    },
    ar = {};
/** @license React v17.0.2
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Hd = R.exports,
    lf = 60103;
ar.Fragment = 60107;
if (typeof Symbol == "function" && Symbol.for) {
    var sf = Symbol.for;
    lf = sf("react.element"), ar.Fragment = sf("react.fragment")
}
var Ud = Hd.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    Wd = Object.prototype.hasOwnProperty,
    Gd = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function of (e, t, n) {
    var r, i = {},
        l = null,
        s = null;
    n !== void 0 && (l = "" + n), t.key !== void 0 && (l = "" + t.key), t.ref !== void 0 && (s = t.ref);
    for (r in t) Wd.call(t, r) && !Gd.hasOwnProperty(r) && (i[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps, t) i[r] === void 0 && (i[r] = t[r]);
    return {
        $$typeof: lf,
        type: e,
        key: l,
        ref: s,
        props: i,
        _owner: Ud.current
    }
}
ar.jsx = of ;
ar.jsxs = of ;
Si.exports = ar;
const ft = Si.exports.jsx,
    $s = Si.exports.jsxs,
    Yd = Si.exports.Fragment;

function af(e) {
    return e !== null && typeof e == "object" && "constructor" in e && e.constructor === Object
}

function Ds(e = {}, t = {}) {
    Object.keys(t).forEach(n => {
        typeof e[n] == "undefined" ? e[n] = t[n] : af(t[n]) && af(e[n]) && Object.keys(t[n]).length > 0 && Ds(e[n], t[n])
    })
}
const uf = {
    body: {},
    addEventListener() {},
    removeEventListener() {},
    activeElement: {
        blur() {},
        nodeName: ""
    },
    querySelector() {
        return null
    },
    querySelectorAll() {
        return []
    },
    getElementById() {
        return null
    },
    createEvent() {
        return {
            initEvent() {}
        }
    },
    createElement() {
        return {
            children: [],
            childNodes: [],
            style: {},
            setAttribute() {},
            getElementsByTagName() {
                return []
            }
        }
    },
    createElementNS() {
        return {}
    },
    importNode() {
        return null
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    }
};

function re() {
    const e = typeof document != "undefined" ? document : {};
    return Ds(e, uf), e
}
const bd = {
    document: uf,
    navigator: {
        userAgent: ""
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    },
    history: {
        replaceState() {},
        pushState() {},
        go() {},
        back() {}
    },
    CustomEvent: function() {
        return this
    },
    addEventListener() {},
    removeEventListener() {},
    getComputedStyle() {
        return {
            getPropertyValue() {
                return ""
            }
        }
    },
    Image() {},
    Date() {},
    screen: {},
    setTimeout() {},
    clearTimeout() {},
    matchMedia() {
        return {}
    },
    requestAnimationFrame(e) {
        return typeof setTimeout == "undefined" ? (e(), null) : setTimeout(e, 0)
    },
    cancelAnimationFrame(e) {
        typeof setTimeout != "undefined" && clearTimeout(e)
    }
};

function Z() {
    const e = typeof window != "undefined" ? window : {};
    return Ds(e, bd), e
}

function Xd(e) {
    const t = e.__proto__;
    Object.defineProperty(e, "__proto__", {
        get() {
            return t
        },
        set(n) {
            t.__proto__ = n
        }
    })
}
class ct extends Array {
    constructor(t) {
        if (typeof t == "number") super(t);
        else {
            super(...t || []);
            Xd(this)
        }
    }
}

function ur(e = []) {
    const t = [];
    return e.forEach(n => {
        Array.isArray(n) ? t.push(...ur(n)) : t.push(n)
    }), t
}

function ff(e, t) {
    return Array.prototype.filter.call(e, t)
}

function Qd(e) {
    const t = [];
    for (let n = 0; n < e.length; n += 1) t.indexOf(e[n]) === -1 && t.push(e[n]);
    return t
}

function qd(e, t) {
    if (typeof e != "string") return [e];
    const n = [],
        r = t.querySelectorAll(e);
    for (let i = 0; i < r.length; i += 1) n.push(r[i]);
    return n
}

function L(e, t) {
    const n = Z(),
        r = re();
    let i = [];
    if (!t && e instanceof ct) return e;
    if (!e) return new ct(i);
    if (typeof e == "string") {
        const l = e.trim();
        if (l.indexOf("<") >= 0 && l.indexOf(">") >= 0) {
            let s = "div";
            l.indexOf("<li") === 0 && (s = "ul"), l.indexOf("<tr") === 0 && (s = "tbody"), (l.indexOf("<td") === 0 || l.indexOf("<th") === 0) && (s = "tr"), l.indexOf("<tbody") === 0 && (s = "table"), l.indexOf("<option") === 0 && (s = "select");
            const a = r.createElement(s);
            a.innerHTML = l;
            for (let o = 0; o < a.childNodes.length; o += 1) i.push(a.childNodes[o])
        } else i = qd(e.trim(), t || r)
    } else if (e.nodeType || e === n || e === r) i.push(e);
    else if (Array.isArray(e)) {
        if (e instanceof ct) return e;
        i = e
    }
    return new ct(Qd(i))
}
L.fn = ct.prototype;

function Kd(...e) {
    const t = ur(e.map(n => n.split(" ")));
    return this.forEach(n => {
        n.classList.add(...t)
    }), this
}

function Zd(...e) {
    const t = ur(e.map(n => n.split(" ")));
    return this.forEach(n => {
        n.classList.remove(...t)
    }), this
}

function Jd(...e) {
    const t = ur(e.map(n => n.split(" ")));
    this.forEach(n => {
        t.forEach(r => {
            n.classList.toggle(r)
        })
    })
}

function ep(...e) {
    const t = ur(e.map(n => n.split(" ")));
    return ff(this, n => t.filter(r => n.classList.contains(r)).length > 0).length > 0
}

function tp(e, t) {
    if (arguments.length === 1 && typeof e == "string") return this[0] ? this[0].getAttribute(e) : void 0;
    for (let n = 0; n < this.length; n += 1)
        if (arguments.length === 2) this[n].setAttribute(e, t);
        else
            for (const r in e) this[n][r] = e[r], this[n].setAttribute(r, e[r]);
    return this
}

function np(e) {
    for (let t = 0; t < this.length; t += 1) this[t].removeAttribute(e);
    return this
}

function rp(e) {
    for (let t = 0; t < this.length; t += 1) this[t].style.transform = e;
    return this
}

function ip(e) {
    for (let t = 0; t < this.length; t += 1) this[t].style.transitionDuration = typeof e != "string" ? `${e}ms` : e;
    return this
}

function lp(...e) {
    let [t, n, r, i] = e;
    typeof e[1] == "function" && ([t, r, i] = e, n = void 0), i || (i = !1);

    function l(f) {
        const d = f.target;
        if (!d) return;
        const m = f.target.dom7EventData || [];
        if (m.indexOf(f) < 0 && m.unshift(f), L(d).is(n)) r.apply(d, m);
        else {
            const h = L(d).parents();
            for (let y = 0; y < h.length; y += 1) L(h[y]).is(n) && r.apply(h[y], m)
        }
    }

    function s(f) {
        const d = f && f.target ? f.target.dom7EventData || [] : [];
        d.indexOf(f) < 0 && d.unshift(f), r.apply(this, d)
    }
    const a = t.split(" ");
    let o;
    for (let f = 0; f < this.length; f += 1) {
        const d = this[f];
        if (n)
            for (o = 0; o < a.length; o += 1) {
                const m = a[o];
                d.dom7LiveListeners || (d.dom7LiveListeners = {}), d.dom7LiveListeners[m] || (d.dom7LiveListeners[m] = []), d.dom7LiveListeners[m].push({
                    listener: r,
                    proxyListener: l
                }), d.addEventListener(m, l, i)
            } else
                for (o = 0; o < a.length; o += 1) {
                    const m = a[o];
                    d.dom7Listeners || (d.dom7Listeners = {}), d.dom7Listeners[m] || (d.dom7Listeners[m] = []), d.dom7Listeners[m].push({
                        listener: r,
                        proxyListener: s
                    }), d.addEventListener(m, s, i)
                }
    }
    return this
}

function sp(...e) {
    let [t, n, r, i] = e;
    typeof e[1] == "function" && ([t, r, i] = e, n = void 0), i || (i = !1);
    const l = t.split(" ");
    for (let s = 0; s < l.length; s += 1) {
        const a = l[s];
        for (let o = 0; o < this.length; o += 1) {
            const f = this[o];
            let d;
            if (!n && f.dom7Listeners ? d = f.dom7Listeners[a] : n && f.dom7LiveListeners && (d = f.dom7LiveListeners[a]), d && d.length)
                for (let m = d.length - 1; m >= 0; m -= 1) {
                    const h = d[m];
                    r && h.listener === r || r && h.listener && h.listener.dom7proxy && h.listener.dom7proxy === r ? (f.removeEventListener(a, h.proxyListener, i), d.splice(m, 1)) : r || (f.removeEventListener(a, h.proxyListener, i), d.splice(m, 1))
                }
        }
    }
    return this
}

function op(...e) {
    const t = Z(),
        n = e[0].split(" "),
        r = e[1];
    for (let i = 0; i < n.length; i += 1) {
        const l = n[i];
        for (let s = 0; s < this.length; s += 1) {
            const a = this[s];
            if (t.CustomEvent) {
                const o = new t.CustomEvent(l, {
                    detail: r,
                    bubbles: !0,
                    cancelable: !0
                });
                a.dom7EventData = e.filter((f, d) => d > 0), a.dispatchEvent(o), a.dom7EventData = [], delete a.dom7EventData
            }
        }
    }
    return this
}

function ap(e) {
    const t = this;

    function n(r) {
        r.target === this && (e.call(this, r), t.off("transitionend", n))
    }
    return e && t.on("transitionend", n), this
}

function up(e) {
    if (this.length > 0) {
        if (e) {
            const t = this.styles();
            return this[0].offsetWidth + parseFloat(t.getPropertyValue("margin-right")) + parseFloat(t.getPropertyValue("margin-left"))
        }
        return this[0].offsetWidth
    }
    return null
}

function fp(e) {
    if (this.length > 0) {
        if (e) {
            const t = this.styles();
            return this[0].offsetHeight + parseFloat(t.getPropertyValue("margin-top")) + parseFloat(t.getPropertyValue("margin-bottom"))
        }
        return this[0].offsetHeight
    }
    return null
}

function cp() {
    if (this.length > 0) {
        const e = Z(),
            t = re(),
            n = this[0],
            r = n.getBoundingClientRect(),
            i = t.body,
            l = n.clientTop || i.clientTop || 0,
            s = n.clientLeft || i.clientLeft || 0,
            a = n === e ? e.scrollY : n.scrollTop,
            o = n === e ? e.scrollX : n.scrollLeft;
        return {
            top: r.top + a - l,
            left: r.left + o - s
        }
    }
    return null
}

function dp() {
    const e = Z();
    return this[0] ? e.getComputedStyle(this[0], null) : {}
}

function pp(e, t) {
    const n = Z();
    let r;
    if (arguments.length === 1)
        if (typeof e == "string") {
            if (this[0]) return n.getComputedStyle(this[0], null).getPropertyValue(e)
        } else {
            for (r = 0; r < this.length; r += 1)
                for (const i in e) this[r].style[i] = e[i];
            return this
        }
    if (arguments.length === 2 && typeof e == "string") {
        for (r = 0; r < this.length; r += 1) this[r].style[e] = t;
        return this
    }
    return this
}

function hp(e) {
    return e ? (this.forEach((t, n) => {
        e.apply(t, [t, n])
    }), this) : this
}

function mp(e) {
    const t = ff(this, e);
    return L(t)
}

function gp(e) {
    if (typeof e == "undefined") return this[0] ? this[0].innerHTML : null;
    for (let t = 0; t < this.length; t += 1) this[t].innerHTML = e;
    return this
}

function vp(e) {
    if (typeof e == "undefined") return this[0] ? this[0].textContent.trim() : null;
    for (let t = 0; t < this.length; t += 1) this[t].textContent = e;
    return this
}

function yp(e) {
    const t = Z(),
        n = re(),
        r = this[0];
    let i, l;
    if (!r || typeof e == "undefined") return !1;
    if (typeof e == "string") {
        if (r.matches) return r.matches(e);
        if (r.webkitMatchesSelector) return r.webkitMatchesSelector(e);
        if (r.msMatchesSelector) return r.msMatchesSelector(e);
        for (i = L(e), l = 0; l < i.length; l += 1)
            if (i[l] === r) return !0;
        return !1
    }
    if (e === n) return r === n;
    if (e === t) return r === t;
    if (e.nodeType || e instanceof ct) {
        for (i = e.nodeType ? [e] : e, l = 0; l < i.length; l += 1)
            if (i[l] === r) return !0;
        return !1
    }
    return !1
}

function wp() {
    let e = this[0],
        t;
    if (e) {
        for (t = 0;
            (e = e.previousSibling) !== null;) e.nodeType === 1 && (t += 1);
        return t
    }
}

function Sp(e) {
    if (typeof e == "undefined") return this;
    const t = this.length;
    if (e > t - 1) return L([]);
    if (e < 0) {
        const n = t + e;
        return n < 0 ? L([]) : L([this[n]])
    }
    return L([this[e]])
}

function Ep(...e) {
    let t;
    const n = re();
    for (let r = 0; r < e.length; r += 1) {
        t = e[r];
        for (let i = 0; i < this.length; i += 1)
            if (typeof t == "string") {
                const l = n.createElement("div");
                for (l.innerHTML = t; l.firstChild;) this[i].appendChild(l.firstChild)
            } else if (t instanceof ct)
            for (let l = 0; l < t.length; l += 1) this[i].appendChild(t[l]);
        else this[i].appendChild(t)
    }
    return this
}

function Cp(e) {
    const t = re();
    let n, r;
    for (n = 0; n < this.length; n += 1)
        if (typeof e == "string") {
            const i = t.createElement("div");
            for (i.innerHTML = e, r = i.childNodes.length - 1; r >= 0; r -= 1) this[n].insertBefore(i.childNodes[r], this[n].childNodes[0])
        } else if (e instanceof ct)
        for (r = 0; r < e.length; r += 1) this[n].insertBefore(e[r], this[n].childNodes[0]);
    else this[n].insertBefore(e, this[n].childNodes[0]);
    return this
}

function xp(e) {
    return this.length > 0 ? e ? this[0].nextElementSibling && L(this[0].nextElementSibling).is(e) ? L([this[0].nextElementSibling]) : L([]) : this[0].nextElementSibling ? L([this[0].nextElementSibling]) : L([]) : L([])
}

function Tp(e) {
    const t = [];
    let n = this[0];
    if (!n) return L([]);
    for (; n.nextElementSibling;) {
        const r = n.nextElementSibling;
        e ? L(r).is(e) && t.push(r) : t.push(r), n = r
    }
    return L(t)
}

function kp(e) {
    if (this.length > 0) {
        const t = this[0];
        return e ? t.previousElementSibling && L(t.previousElementSibling).is(e) ? L([t.previousElementSibling]) : L([]) : t.previousElementSibling ? L([t.previousElementSibling]) : L([])
    }
    return L([])
}

function Pp(e) {
    const t = [];
    let n = this[0];
    if (!n) return L([]);
    for (; n.previousElementSibling;) {
        const r = n.previousElementSibling;
        e ? L(r).is(e) && t.push(r) : t.push(r), n = r
    }
    return L(t)
}

function _p(e) {
    const t = [];
    for (let n = 0; n < this.length; n += 1) this[n].parentNode !== null && (e ? L(this[n].parentNode).is(e) && t.push(this[n].parentNode) : t.push(this[n].parentNode));
    return L(t)
}

function Lp(e) {
    const t = [];
    for (let n = 0; n < this.length; n += 1) {
        let r = this[n].parentNode;
        for (; r;) e ? L(r).is(e) && t.push(r) : t.push(r), r = r.parentNode
    }
    return L(t)
}

function Op(e) {
    let t = this;
    return typeof e == "undefined" ? L([]) : (t.is(e) || (t = t.parents(e).eq(0)), t)
}

function Mp(e) {
    const t = [];
    for (let n = 0; n < this.length; n += 1) {
        const r = this[n].querySelectorAll(e);
        for (let i = 0; i < r.length; i += 1) t.push(r[i])
    }
    return L(t)
}

function Np(e) {
    const t = [];
    for (let n = 0; n < this.length; n += 1) {
        const r = this[n].children;
        for (let i = 0; i < r.length; i += 1)(!e || L(r[i]).is(e)) && t.push(r[i])
    }
    return L(t)
}

function zp() {
    for (let e = 0; e < this.length; e += 1) this[e].parentNode && this[e].parentNode.removeChild(this[e]);
    return this
}
const cf = {
    addClass: Kd,
    removeClass: Zd,
    hasClass: ep,
    toggleClass: Jd,
    attr: tp,
    removeAttr: np,
    transform: rp,
    transition: ip,
    on: lp,
    off: sp,
    trigger: op,
    transitionEnd: ap,
    outerWidth: up,
    outerHeight: fp,
    styles: dp,
    offset: cp,
    css: pp,
    each: hp,
    html: gp,
    text: vp,
    is: yp,
    index: wp,
    eq: Sp,
    append: Ep,
    prepend: Cp,
    next: xp,
    nextAll: Tp,
    prev: kp,
    prevAll: Pp,
    parent: _p,
    parents: Lp,
    closest: Op,
    find: Mp,
    children: Np,
    filter: mp,
    remove: zp
};
Object.keys(cf).forEach(e => {
    Object.defineProperty(L.fn, e, {
        value: cf[e],
        writable: !0
    })
});

function Ip(e) {
    const t = e;
    Object.keys(t).forEach(n => {
        try {
            t[n] = null
        } catch {}
        try {
            delete t[n]
        } catch {}
    })
}

function Ei(e, t) {
    return t === void 0 && (t = 0), setTimeout(e, t)
}

function fr() {
    return Date.now()
}

function $p(e) {
    const t = Z();
    let n;
    return t.getComputedStyle && (n = t.getComputedStyle(e, null)), !n && e.currentStyle && (n = e.currentStyle), n || (n = e.style), n
}

function Dp(e, t) {
    t === void 0 && (t = "x");
    const n = Z();
    let r, i, l;
    const s = $p(e);
    return n.WebKitCSSMatrix ? (i = s.transform || s.webkitTransform, i.split(",").length > 6 && (i = i.split(", ").map(a => a.replace(",", ".")).join(", ")), l = new n.WebKitCSSMatrix(i === "none" ? "" : i)) : (l = s.MozTransform || s.OTransform || s.MsTransform || s.msTransform || s.transform || s.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), r = l.toString().split(",")), t === "x" && (n.WebKitCSSMatrix ? i = l.m41 : r.length === 16 ? i = parseFloat(r[12]) : i = parseFloat(r[4])), t === "y" && (n.WebKitCSSMatrix ? i = l.m42 : r.length === 16 ? i = parseFloat(r[13]) : i = parseFloat(r[5])), i || 0
}

function Ci(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function Rp(e) {
    return typeof window != "undefined" && typeof window.HTMLElement != "undefined" ? e instanceof HTMLElement : e && (e.nodeType === 1 || e.nodeType === 11)
}

function ye() {
    const e = Object(arguments.length <= 0 ? void 0 : arguments[0]),
        t = ["__proto__", "constructor", "prototype"];
    for (let n = 1; n < arguments.length; n += 1) {
        const r = n < 0 || arguments.length <= n ? void 0 : arguments[n];
        if (r != null && !Rp(r)) {
            const i = Object.keys(Object(r)).filter(l => t.indexOf(l) < 0);
            for (let l = 0, s = i.length; l < s; l += 1) {
                const a = i[l],
                    o = Object.getOwnPropertyDescriptor(r, a);
                o !== void 0 && o.enumerable && (Ci(e[a]) && Ci(r[a]) ? r[a].__swiper__ ? e[a] = r[a] : ye(e[a], r[a]) : !Ci(e[a]) && Ci(r[a]) ? (e[a] = {}, r[a].__swiper__ ? e[a] = r[a] : ye(e[a], r[a])) : e[a] = r[a])
            }
        }
    }
    return e
}

function xi(e, t, n) {
    e.style.setProperty(t, n)
}

function df(e) {
    let {
        swiper: t,
        targetPosition: n,
        side: r
    } = e;
    const i = Z(),
        l = -t.translate;
    let s = null,
        a;
    const o = t.params.speed;
    t.wrapperEl.style.scrollSnapType = "none", i.cancelAnimationFrame(t.cssModeFrameID);
    const f = n > l ? "next" : "prev",
        d = (h, y) => f === "next" && h >= y || f === "prev" && h <= y,
        m = () => {
            a = new Date().getTime(), s === null && (s = a);
            const h = Math.max(Math.min((a - s) / o, 1), 0),
                y = .5 - Math.cos(h * Math.PI) / 2;
            let S = l + y * (n - l);
            if (d(S, n) && (S = n), t.wrapperEl.scrollTo({
                    [r]: S
                }), d(S, n)) {
                t.wrapperEl.style.overflow = "hidden", t.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
                    t.wrapperEl.style.overflow = "", t.wrapperEl.scrollTo({
                        [r]: S
                    })
                }), i.cancelAnimationFrame(t.cssModeFrameID);
                return
            }
            t.cssModeFrameID = i.requestAnimationFrame(m)
        };
    m()
}
let Rs;

function Ap() {
    const e = Z(),
        t = re();
    return {
        smoothScroll: t.documentElement && "scrollBehavior" in t.documentElement.style,
        touch: !!("ontouchstart" in e || e.DocumentTouch && t instanceof e.DocumentTouch),
        passiveListener: function() {
            let r = !1;
            try {
                const i = Object.defineProperty({}, "passive", {
                    get() {
                        r = !0
                    }
                });
                e.addEventListener("testPassiveListener", null, i)
            } catch {}
            return r
        }(),
        gestures: function() {
            return "ongesturestart" in e
        }()
    }
}

function pf() {
    return Rs || (Rs = Ap()), Rs
}
let As;

function Fp(e) {
    let {
        userAgent: t
    } = e === void 0 ? {} : e;
    const n = pf(),
        r = Z(),
        i = r.navigator.platform,
        l = t || r.navigator.userAgent,
        s = {
            ios: !1,
            android: !1
        },
        a = r.screen.width,
        o = r.screen.height,
        f = l.match(/(Android);?[\s\/]+([\d.]+)?/);
    let d = l.match(/(iPad).*OS\s([\d_]+)/);
    const m = l.match(/(iPod)(.*OS\s([\d_]+))?/),
        h = !d && l.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
        y = i === "Win32";
    let S = i === "MacIntel";
    const E = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
    return !d && S && n.touch && E.indexOf(`${a}x${o}`) >= 0 && (d = l.match(/(Version)\/([\d.]+)/), d || (d = [0, 1, "13_0_0"]), S = !1), f && !y && (s.os = "android", s.android = !0), (d || h || m) && (s.os = "ios", s.ios = !0), s
}

function jp(e) {
    return e === void 0 && (e = {}), As || (As = Fp(e)), As
}
let Fs;

function Bp() {
    const e = Z();

    function t() {
        const n = e.navigator.userAgent.toLowerCase();
        return n.indexOf("safari") >= 0 && n.indexOf("chrome") < 0 && n.indexOf("android") < 0
    }
    return {
        isSafari: t(),
        isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e.navigator.userAgent)
    }
}

function Vp() {
    return Fs || (Fs = Bp()), Fs
}

function Hp(e) {
    let {
        swiper: t,
        on: n,
        emit: r
    } = e;
    const i = Z();
    let l = null,
        s = null;
    const a = () => {
            !t || t.destroyed || !t.initialized || (r("beforeResize"), r("resize"))
        },
        o = () => {
            !t || t.destroyed || !t.initialized || (l = new ResizeObserver(m => {
                s = i.requestAnimationFrame(() => {
                    const {
                        width: h,
                        height: y
                    } = t;
                    let S = h,
                        E = y;
                    m.forEach(c => {
                        let {
                            contentBoxSize: u,
                            contentRect: p,
                            target: g
                        } = c;
                        g && g !== t.el || (S = p ? p.width : (u[0] || u).inlineSize, E = p ? p.height : (u[0] || u).blockSize)
                    }), (S !== h || E !== y) && a()
                })
            }), l.observe(t.el))
        },
        f = () => {
            s && i.cancelAnimationFrame(s), l && l.unobserve && t.el && (l.unobserve(t.el), l = null)
        },
        d = () => {
            !t || t.destroyed || !t.initialized || r("orientationchange")
        };
    n("init", () => {
        if (t.params.resizeObserver && typeof i.ResizeObserver != "undefined") {
            o();
            return
        }
        i.addEventListener("resize", a), i.addEventListener("orientationchange", d)
    }), n("destroy", () => {
        f(), i.removeEventListener("resize", a), i.removeEventListener("orientationchange", d)
    })
}

function Up(e) {
    let {
        swiper: t,
        extendParams: n,
        on: r,
        emit: i
    } = e;
    const l = [],
        s = Z(),
        a = function(d, m) {
            m === void 0 && (m = {});
            const h = s.MutationObserver || s.WebkitMutationObserver,
                y = new h(S => {
                    if (S.length === 1) {
                        i("observerUpdate", S[0]);
                        return
                    }
                    const E = function() {
                        i("observerUpdate", S[0])
                    };
                    s.requestAnimationFrame ? s.requestAnimationFrame(E) : s.setTimeout(E, 0)
                });
            y.observe(d, {
                attributes: typeof m.attributes == "undefined" ? !0 : m.attributes,
                childList: typeof m.childList == "undefined" ? !0 : m.childList,
                characterData: typeof m.characterData == "undefined" ? !0 : m.characterData
            }), l.push(y)
        },
        o = () => {
            if (!!t.params.observer) {
                if (t.params.observeParents) {
                    const d = t.$el.parents();
                    for (let m = 0; m < d.length; m += 1) a(d[m])
                }
                a(t.$el[0], {
                    childList: t.params.observeSlideChildren
                }), a(t.$wrapperEl[0], {
                    attributes: !1
                })
            }
        },
        f = () => {
            l.forEach(d => {
                d.disconnect()
            }), l.splice(0, l.length)
        };
    n({
        observer: !1,
        observeParents: !1,
        observeSlideChildren: !1
    }), r("init", o), r("destroy", f)
}
var Wp = {
    on(e, t, n) {
        const r = this;
        if (!r.eventsListeners || r.destroyed || typeof t != "function") return r;
        const i = n ? "unshift" : "push";
        return e.split(" ").forEach(l => {
            r.eventsListeners[l] || (r.eventsListeners[l] = []), r.eventsListeners[l][i](t)
        }), r
    },
    once(e, t, n) {
        const r = this;
        if (!r.eventsListeners || r.destroyed || typeof t != "function") return r;

        function i() {
            r.off(e, i), i.__emitterProxy && delete i.__emitterProxy;
            for (var l = arguments.length, s = new Array(l), a = 0; a < l; a++) s[a] = arguments[a];
            t.apply(r, s)
        }
        return i.__emitterProxy = t, r.on(e, i, n)
    },
    onAny(e, t) {
        const n = this;
        if (!n.eventsListeners || n.destroyed || typeof e != "function") return n;
        const r = t ? "unshift" : "push";
        return n.eventsAnyListeners.indexOf(e) < 0 && n.eventsAnyListeners[r](e), n
    },
    offAny(e) {
        const t = this;
        if (!t.eventsListeners || t.destroyed || !t.eventsAnyListeners) return t;
        const n = t.eventsAnyListeners.indexOf(e);
        return n >= 0 && t.eventsAnyListeners.splice(n, 1), t
    },
    off(e, t) {
        const n = this;
        return !n.eventsListeners || n.destroyed || !n.eventsListeners || e.split(" ").forEach(r => {
            typeof t == "undefined" ? n.eventsListeners[r] = [] : n.eventsListeners[r] && n.eventsListeners[r].forEach((i, l) => {
                (i === t || i.__emitterProxy && i.__emitterProxy === t) && n.eventsListeners[r].splice(l, 1)
            })
        }), n
    },
    emit() {
        const e = this;
        if (!e.eventsListeners || e.destroyed || !e.eventsListeners) return e;
        let t, n, r;
        for (var i = arguments.length, l = new Array(i), s = 0; s < i; s++) l[s] = arguments[s];
        return typeof l[0] == "string" || Array.isArray(l[0]) ? (t = l[0], n = l.slice(1, l.length), r = e) : (t = l[0].events, n = l[0].data, r = l[0].context || e), n.unshift(r), (Array.isArray(t) ? t : t.split(" ")).forEach(o => {
            e.eventsAnyListeners && e.eventsAnyListeners.length && e.eventsAnyListeners.forEach(f => {
                f.apply(r, [o, ...n])
            }), e.eventsListeners && e.eventsListeners[o] && e.eventsListeners[o].forEach(f => {
                f.apply(r, n)
            })
        }), e
    }
};

function Gp() {
    const e = this;
    let t, n;
    const r = e.$el;
    typeof e.params.width != "undefined" && e.params.width !== null ? t = e.params.width : t = r[0].clientWidth, typeof e.params.height != "undefined" && e.params.height !== null ? n = e.params.height : n = r[0].clientHeight, !(t === 0 && e.isHorizontal() || n === 0 && e.isVertical()) && (t = t - parseInt(r.css("padding-left") || 0, 10) - parseInt(r.css("padding-right") || 0, 10), n = n - parseInt(r.css("padding-top") || 0, 10) - parseInt(r.css("padding-bottom") || 0, 10), Number.isNaN(t) && (t = 0), Number.isNaN(n) && (n = 0), Object.assign(e, {
        width: t,
        height: n,
        size: e.isHorizontal() ? t : n
    }))
}

function Yp() {
    const e = this;

    function t(_) {
        return e.isHorizontal() ? _ : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
        }[_]
    }

    function n(_, z) {
        return parseFloat(_.getPropertyValue(t(z)) || 0)
    }
    const r = e.params,
        {
            $wrapperEl: i,
            size: l,
            rtlTranslate: s,
            wrongRTL: a
        } = e,
        o = e.virtual && r.virtual.enabled,
        f = o ? e.virtual.slides.length : e.slides.length,
        d = i.children(`.${e.params.slideClass}`),
        m = o ? e.virtual.slides.length : d.length;
    let h = [];
    const y = [],
        S = [];
    let E = r.slidesOffsetBefore;
    typeof E == "function" && (E = r.slidesOffsetBefore.call(e));
    let c = r.slidesOffsetAfter;
    typeof c == "function" && (c = r.slidesOffsetAfter.call(e));
    const u = e.snapGrid.length,
        p = e.slidesGrid.length;
    let g = r.spaceBetween,
        v = -E,
        T = 0,
        w = 0;
    if (typeof l == "undefined") return;
    typeof g == "string" && g.indexOf("%") >= 0 && (g = parseFloat(g.replace("%", "")) / 100 * l), e.virtualSize = -g, s ? d.css({
        marginLeft: "",
        marginBottom: "",
        marginTop: ""
    }) : d.css({
        marginRight: "",
        marginBottom: "",
        marginTop: ""
    }), r.centeredSlides && r.cssMode && (xi(e.wrapperEl, "--swiper-centered-offset-before", ""), xi(e.wrapperEl, "--swiper-centered-offset-after", ""));
    const P = r.grid && r.grid.rows > 1 && e.grid;
    P && e.grid.initSlides(m);
    let x;
    const O = r.slidesPerView === "auto" && r.breakpoints && Object.keys(r.breakpoints).filter(_ => typeof r.breakpoints[_].slidesPerView != "undefined").length > 0;
    for (let _ = 0; _ < m; _ += 1) {
        x = 0;
        const z = d.eq(_);
        if (P && e.grid.updateSlide(_, z, m, t), z.css("display") !== "none") {
            if (r.slidesPerView === "auto") {
                O && (d[_].style[t("width")] = "");
                const N = getComputedStyle(z[0]),
                    F = z[0].style.transform,
                    b = z[0].style.webkitTransform;
                if (F && (z[0].style.transform = "none"), b && (z[0].style.webkitTransform = "none"), r.roundLengths) x = e.isHorizontal() ? z.outerWidth(!0) : z.outerHeight(!0);
                else {
                    const me = n(N, "width"),
                        $e = n(N, "padding-left"),
                        pt = n(N, "padding-right"),
                        Ue = n(N, "margin-left"),
                        De = n(N, "margin-right"),
                        X = N.getPropertyValue("box-sizing");
                    if (X && X === "border-box") x = me + Ue + De;
                    else {
                        const {
                            clientWidth: k,
                            offsetWidth: I
                        } = z[0];
                        x = me + $e + pt + Ue + De + (I - k)
                    }
                }
                F && (z[0].style.transform = F), b && (z[0].style.webkitTransform = b), r.roundLengths && (x = Math.floor(x))
            } else x = (l - (r.slidesPerView - 1) * g) / r.slidesPerView, r.roundLengths && (x = Math.floor(x)), d[_] && (d[_].style[t("width")] = `${x}px`);
            d[_] && (d[_].swiperSlideSize = x), S.push(x), r.centeredSlides ? (v = v + x / 2 + T / 2 + g, T === 0 && _ !== 0 && (v = v - l / 2 - g), _ === 0 && (v = v - l / 2 - g), Math.abs(v) < 1 / 1e3 && (v = 0), r.roundLengths && (v = Math.floor(v)), w % r.slidesPerGroup == 0 && h.push(v), y.push(v)) : (r.roundLengths && (v = Math.floor(v)), (w - Math.min(e.params.slidesPerGroupSkip, w)) % e.params.slidesPerGroup == 0 && h.push(v), y.push(v), v = v + x + g), e.virtualSize += x + g, T = x, w += 1
        }
    }
    if (e.virtualSize = Math.max(e.virtualSize, l) + c, s && a && (r.effect === "slide" || r.effect === "coverflow") && i.css({
            width: `${e.virtualSize+r.spaceBetween}px`
        }), r.setWrapperSize && i.css({
            [t("width")]: `${e.virtualSize+r.spaceBetween}px`
        }), P && e.grid.updateWrapperSize(x, h, t), !r.centeredSlides) {
        const _ = [];
        for (let z = 0; z < h.length; z += 1) {
            let N = h[z];
            r.roundLengths && (N = Math.floor(N)), h[z] <= e.virtualSize - l && _.push(N)
        }
        h = _, Math.floor(e.virtualSize - l) - Math.floor(h[h.length - 1]) > 1 && h.push(e.virtualSize - l)
    }
    if (h.length === 0 && (h = [0]), r.spaceBetween !== 0) {
        const _ = e.isHorizontal() && s ? "marginLeft" : t("marginRight");
        d.filter((z, N) => r.cssMode ? N !== d.length - 1 : !0).css({
            [_]: `${g}px`
        })
    }
    if (r.centeredSlides && r.centeredSlidesBounds) {
        let _ = 0;
        S.forEach(N => {
            _ += N + (r.spaceBetween ? r.spaceBetween : 0)
        }), _ -= r.spaceBetween;
        const z = _ - l;
        h = h.map(N => N < 0 ? -E : N > z ? z + c : N)
    }
    if (r.centerInsufficientSlides) {
        let _ = 0;
        if (S.forEach(z => {
                _ += z + (r.spaceBetween ? r.spaceBetween : 0)
            }), _ -= r.spaceBetween, _ < l) {
            const z = (l - _) / 2;
            h.forEach((N, F) => {
                h[F] = N - z
            }), y.forEach((N, F) => {
                y[F] = N + z
            })
        }
    }
    if (Object.assign(e, {
            slides: d,
            snapGrid: h,
            slidesGrid: y,
            slidesSizesGrid: S
        }), r.centeredSlides && r.cssMode && !r.centeredSlidesBounds) {
        xi(e.wrapperEl, "--swiper-centered-offset-before", `${-h[0]}px`), xi(e.wrapperEl, "--swiper-centered-offset-after", `${e.size/2-S[S.length-1]/2}px`);
        const _ = -e.snapGrid[0],
            z = -e.slidesGrid[0];
        e.snapGrid = e.snapGrid.map(N => N + _), e.slidesGrid = e.slidesGrid.map(N => N + z)
    }
    if (m !== f && e.emit("slidesLengthChange"), h.length !== u && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")), y.length !== p && e.emit("slidesGridLengthChange"), r.watchSlidesProgress && e.updateSlidesOffset(), !o && !r.cssMode && (r.effect === "slide" || r.effect === "fade")) {
        const _ = `${r.containerModifierClass}backface-hidden`,
            z = e.$el.hasClass(_);
        m <= r.maxBackfaceHiddenSlides ? z || e.$el.addClass(_) : z && e.$el.removeClass(_)
    }
}

function bp(e) {
    const t = this,
        n = [],
        r = t.virtual && t.params.virtual.enabled;
    let i = 0,
        l;
    typeof e == "number" ? t.setTransition(e) : e === !0 && t.setTransition(t.params.speed);
    const s = a => r ? t.slides.filter(o => parseInt(o.getAttribute("data-swiper-slide-index"), 10) === a)[0] : t.slides.eq(a)[0];
    if (t.params.slidesPerView !== "auto" && t.params.slidesPerView > 1)
        if (t.params.centeredSlides)(t.visibleSlides || L([])).each(a => {
            n.push(a)
        });
        else
            for (l = 0; l < Math.ceil(t.params.slidesPerView); l += 1) {
                const a = t.activeIndex + l;
                if (a > t.slides.length && !r) break;
                n.push(s(a))
            } else n.push(s(t.activeIndex));
    for (l = 0; l < n.length; l += 1)
        if (typeof n[l] != "undefined") {
            const a = n[l].offsetHeight;
            i = a > i ? a : i
        }(i || i === 0) && t.$wrapperEl.css("height", `${i}px`)
}

function Xp() {
    const e = this,
        t = e.slides;
    for (let n = 0; n < t.length; n += 1) t[n].swiperSlideOffset = e.isHorizontal() ? t[n].offsetLeft : t[n].offsetTop
}

function Qp(e) {
    e === void 0 && (e = this && this.translate || 0);
    const t = this,
        n = t.params,
        {
            slides: r,
            rtlTranslate: i,
            snapGrid: l
        } = t;
    if (r.length === 0) return;
    typeof r[0].swiperSlideOffset == "undefined" && t.updateSlidesOffset();
    let s = -e;
    i && (s = e), r.removeClass(n.slideVisibleClass), t.visibleSlidesIndexes = [], t.visibleSlides = [];
    for (let a = 0; a < r.length; a += 1) {
        const o = r[a];
        let f = o.swiperSlideOffset;
        n.cssMode && n.centeredSlides && (f -= r[0].swiperSlideOffset);
        const d = (s + (n.centeredSlides ? t.minTranslate() : 0) - f) / (o.swiperSlideSize + n.spaceBetween),
            m = (s - l[0] + (n.centeredSlides ? t.minTranslate() : 0) - f) / (o.swiperSlideSize + n.spaceBetween),
            h = -(s - f),
            y = h + t.slidesSizesGrid[a];
        (h >= 0 && h < t.size - 1 || y > 1 && y <= t.size || h <= 0 && y >= t.size) && (t.visibleSlides.push(o), t.visibleSlidesIndexes.push(a), r.eq(a).addClass(n.slideVisibleClass)), o.progress = i ? -d : d, o.originalProgress = i ? -m : m
    }
    t.visibleSlides = L(t.visibleSlides)
}

function qp(e) {
    const t = this;
    if (typeof e == "undefined") {
        const f = t.rtlTranslate ? -1 : 1;
        e = t && t.translate && t.translate * f || 0
    }
    const n = t.params,
        r = t.maxTranslate() - t.minTranslate();
    let {
        progress: i,
        isBeginning: l,
        isEnd: s
    } = t;
    const a = l,
        o = s;
    r === 0 ? (i = 0, l = !0, s = !0) : (i = (e - t.minTranslate()) / r, l = i <= 0, s = i >= 1), Object.assign(t, {
        progress: i,
        isBeginning: l,
        isEnd: s
    }), (n.watchSlidesProgress || n.centeredSlides && n.autoHeight) && t.updateSlidesProgress(e), l && !a && t.emit("reachBeginning toEdge"), s && !o && t.emit("reachEnd toEdge"), (a && !l || o && !s) && t.emit("fromEdge"), t.emit("progress", i)
}

function Kp() {
    const e = this,
        {
            slides: t,
            params: n,
            $wrapperEl: r,
            activeIndex: i,
            realIndex: l
        } = e,
        s = e.virtual && n.virtual.enabled;
    t.removeClass(`${n.slideActiveClass} ${n.slideNextClass} ${n.slidePrevClass} ${n.slideDuplicateActiveClass} ${n.slideDuplicateNextClass} ${n.slideDuplicatePrevClass}`);
    let a;
    s ? a = e.$wrapperEl.find(`.${n.slideClass}[data-swiper-slide-index="${i}"]`) : a = t.eq(i), a.addClass(n.slideActiveClass), n.loop && (a.hasClass(n.slideDuplicateClass) ? r.children(`.${n.slideClass}:not(.${n.slideDuplicateClass})[data-swiper-slide-index="${l}"]`).addClass(n.slideDuplicateActiveClass) : r.children(`.${n.slideClass}.${n.slideDuplicateClass}[data-swiper-slide-index="${l}"]`).addClass(n.slideDuplicateActiveClass));
    let o = a.nextAll(`.${n.slideClass}`).eq(0).addClass(n.slideNextClass);
    n.loop && o.length === 0 && (o = t.eq(0), o.addClass(n.slideNextClass));
    let f = a.prevAll(`.${n.slideClass}`).eq(0).addClass(n.slidePrevClass);
    n.loop && f.length === 0 && (f = t.eq(-1), f.addClass(n.slidePrevClass)), n.loop && (o.hasClass(n.slideDuplicateClass) ? r.children(`.${n.slideClass}:not(.${n.slideDuplicateClass})[data-swiper-slide-index="${o.attr("data-swiper-slide-index")}"]`).addClass(n.slideDuplicateNextClass) : r.children(`.${n.slideClass}.${n.slideDuplicateClass}[data-swiper-slide-index="${o.attr("data-swiper-slide-index")}"]`).addClass(n.slideDuplicateNextClass), f.hasClass(n.slideDuplicateClass) ? r.children(`.${n.slideClass}:not(.${n.slideDuplicateClass})[data-swiper-slide-index="${f.attr("data-swiper-slide-index")}"]`).addClass(n.slideDuplicatePrevClass) : r.children(`.${n.slideClass}.${n.slideDuplicateClass}[data-swiper-slide-index="${f.attr("data-swiper-slide-index")}"]`).addClass(n.slideDuplicatePrevClass)), e.emitSlidesClasses()
}

function Zp(e) {
    const t = this,
        n = t.rtlTranslate ? t.translate : -t.translate,
        {
            slidesGrid: r,
            snapGrid: i,
            params: l,
            activeIndex: s,
            realIndex: a,
            snapIndex: o
        } = t;
    let f = e,
        d;
    if (typeof f == "undefined") {
        for (let h = 0; h < r.length; h += 1) typeof r[h + 1] != "undefined" ? n >= r[h] && n < r[h + 1] - (r[h + 1] - r[h]) / 2 ? f = h : n >= r[h] && n < r[h + 1] && (f = h + 1) : n >= r[h] && (f = h);
        l.normalizeSlideIndex && (f < 0 || typeof f == "undefined") && (f = 0)
    }
    if (i.indexOf(n) >= 0) d = i.indexOf(n);
    else {
        const h = Math.min(l.slidesPerGroupSkip, f);
        d = h + Math.floor((f - h) / l.slidesPerGroup)
    }
    if (d >= i.length && (d = i.length - 1), f === s) {
        d !== o && (t.snapIndex = d, t.emit("snapIndexChange"));
        return
    }
    const m = parseInt(t.slides.eq(f).attr("data-swiper-slide-index") || f, 10);
    Object.assign(t, {
        snapIndex: d,
        realIndex: m,
        previousIndex: s,
        activeIndex: f
    }), t.emit("activeIndexChange"), t.emit("snapIndexChange"), a !== m && t.emit("realIndexChange"), (t.initialized || t.params.runCallbacksOnInit) && t.emit("slideChange")
}

function Jp(e) {
    const t = this,
        n = t.params,
        r = L(e).closest(`.${n.slideClass}`)[0];
    let i = !1,
        l;
    if (r) {
        for (let s = 0; s < t.slides.length; s += 1)
            if (t.slides[s] === r) {
                i = !0, l = s;
                break
            }
    }
    if (r && i) t.clickedSlide = r, t.virtual && t.params.virtual.enabled ? t.clickedIndex = parseInt(L(r).attr("data-swiper-slide-index"), 10) : t.clickedIndex = l;
    else {
        t.clickedSlide = void 0, t.clickedIndex = void 0;
        return
    }
    n.slideToClickedSlide && t.clickedIndex !== void 0 && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide()
}
var eh = {
    updateSize: Gp,
    updateSlides: Yp,
    updateAutoHeight: bp,
    updateSlidesOffset: Xp,
    updateSlidesProgress: Qp,
    updateProgress: qp,
    updateSlidesClasses: Kp,
    updateActiveIndex: Zp,
    updateClickedSlide: Jp
};

function th(e) {
    e === void 0 && (e = this.isHorizontal() ? "x" : "y");
    const t = this,
        {
            params: n,
            rtlTranslate: r,
            translate: i,
            $wrapperEl: l
        } = t;
    if (n.virtualTranslate) return r ? -i : i;
    if (n.cssMode) return i;
    let s = Dp(l[0], e);
    return r && (s = -s), s || 0
}

function nh(e, t) {
    const n = this,
        {
            rtlTranslate: r,
            params: i,
            $wrapperEl: l,
            wrapperEl: s,
            progress: a
        } = n;
    let o = 0,
        f = 0;
    const d = 0;
    n.isHorizontal() ? o = r ? -e : e : f = e, i.roundLengths && (o = Math.floor(o), f = Math.floor(f)), i.cssMode ? s[n.isHorizontal() ? "scrollLeft" : "scrollTop"] = n.isHorizontal() ? -o : -f : i.virtualTranslate || l.transform(`translate3d(${o}px, ${f}px, ${d}px)`), n.previousTranslate = n.translate, n.translate = n.isHorizontal() ? o : f;
    let m;
    const h = n.maxTranslate() - n.minTranslate();
    h === 0 ? m = 0 : m = (e - n.minTranslate()) / h, m !== a && n.updateProgress(e), n.emit("setTranslate", n.translate, t)
}

function rh() {
    return -this.snapGrid[0]
}

function ih() {
    return -this.snapGrid[this.snapGrid.length - 1]
}

function lh(e, t, n, r, i) {
    e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), n === void 0 && (n = !0), r === void 0 && (r = !0);
    const l = this,
        {
            params: s,
            wrapperEl: a
        } = l;
    if (l.animating && s.preventInteractionOnTransition) return !1;
    const o = l.minTranslate(),
        f = l.maxTranslate();
    let d;
    if (r && e > o ? d = o : r && e < f ? d = f : d = e, l.updateProgress(d), s.cssMode) {
        const m = l.isHorizontal();
        if (t === 0) a[m ? "scrollLeft" : "scrollTop"] = -d;
        else {
            if (!l.support.smoothScroll) return df({
                swiper: l,
                targetPosition: -d,
                side: m ? "left" : "top"
            }), !0;
            a.scrollTo({
                [m ? "left" : "top"]: -d,
                behavior: "smooth"
            })
        }
        return !0
    }
    return t === 0 ? (l.setTransition(0), l.setTranslate(d), n && (l.emit("beforeTransitionStart", t, i), l.emit("transitionEnd"))) : (l.setTransition(t), l.setTranslate(d), n && (l.emit("beforeTransitionStart", t, i), l.emit("transitionStart")), l.animating || (l.animating = !0, l.onTranslateToWrapperTransitionEnd || (l.onTranslateToWrapperTransitionEnd = function(h) {
        !l || l.destroyed || h.target === this && (l.$wrapperEl[0].removeEventListener("transitionend", l.onTranslateToWrapperTransitionEnd), l.$wrapperEl[0].removeEventListener("webkitTransitionEnd", l.onTranslateToWrapperTransitionEnd), l.onTranslateToWrapperTransitionEnd = null, delete l.onTranslateToWrapperTransitionEnd, n && l.emit("transitionEnd"))
    }), l.$wrapperEl[0].addEventListener("transitionend", l.onTranslateToWrapperTransitionEnd), l.$wrapperEl[0].addEventListener("webkitTransitionEnd", l.onTranslateToWrapperTransitionEnd))), !0
}
var sh = {
    getTranslate: th,
    setTranslate: nh,
    minTranslate: rh,
    maxTranslate: ih,
    translateTo: lh
};

function oh(e, t) {
    const n = this;
    n.params.cssMode || n.$wrapperEl.transition(e), n.emit("setTransition", e, t)
}

function hf(e) {
    let {
        swiper: t,
        runCallbacks: n,
        direction: r,
        step: i
    } = e;
    const {
        activeIndex: l,
        previousIndex: s
    } = t;
    let a = r;
    if (a || (l > s ? a = "next" : l < s ? a = "prev" : a = "reset"), t.emit(`transition${i}`), n && l !== s) {
        if (a === "reset") {
            t.emit(`slideResetTransition${i}`);
            return
        }
        t.emit(`slideChangeTransition${i}`), a === "next" ? t.emit(`slideNextTransition${i}`) : t.emit(`slidePrevTransition${i}`)
    }
}

function ah(e, t) {
    e === void 0 && (e = !0);
    const n = this,
        {
            params: r
        } = n;
    r.cssMode || (r.autoHeight && n.updateAutoHeight(), hf({
        swiper: n,
        runCallbacks: e,
        direction: t,
        step: "Start"
    }))
}

function uh(e, t) {
    e === void 0 && (e = !0);
    const n = this,
        {
            params: r
        } = n;
    n.animating = !1, !r.cssMode && (n.setTransition(0), hf({
        swiper: n,
        runCallbacks: e,
        direction: t,
        step: "End"
    }))
}
var fh = {
    setTransition: oh,
    transitionStart: ah,
    transitionEnd: uh
};

function ch(e, t, n, r, i) {
    if (e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), n === void 0 && (n = !0), typeof e != "number" && typeof e != "string") throw new Error(`The 'index' argument cannot have type other than 'number' or 'string'. [${typeof e}] given.`);
    if (typeof e == "string") {
        const g = parseInt(e, 10);
        if (!isFinite(g)) throw new Error(`The passed-in 'index' (string) couldn't be converted to 'number'. [${e}] given.`);
        e = g
    }
    const l = this;
    let s = e;
    s < 0 && (s = 0);
    const {
        params: a,
        snapGrid: o,
        slidesGrid: f,
        previousIndex: d,
        activeIndex: m,
        rtlTranslate: h,
        wrapperEl: y,
        enabled: S
    } = l;
    if (l.animating && a.preventInteractionOnTransition || !S && !r && !i) return !1;
    const E = Math.min(l.params.slidesPerGroupSkip, s);
    let c = E + Math.floor((s - E) / l.params.slidesPerGroup);
    c >= o.length && (c = o.length - 1), (m || a.initialSlide || 0) === (d || 0) && n && l.emit("beforeSlideChangeStart");
    const u = -o[c];
    if (l.updateProgress(u), a.normalizeSlideIndex)
        for (let g = 0; g < f.length; g += 1) {
            const v = -Math.floor(u * 100),
                T = Math.floor(f[g] * 100),
                w = Math.floor(f[g + 1] * 100);
            typeof f[g + 1] != "undefined" ? v >= T && v < w - (w - T) / 2 ? s = g : v >= T && v < w && (s = g + 1) : v >= T && (s = g)
        }
    if (l.initialized && s !== m && (!l.allowSlideNext && u < l.translate && u < l.minTranslate() || !l.allowSlidePrev && u > l.translate && u > l.maxTranslate() && (m || 0) !== s)) return !1;
    let p;
    if (s > m ? p = "next" : s < m ? p = "prev" : p = "reset", h && -u === l.translate || !h && u === l.translate) return l.updateActiveIndex(s), a.autoHeight && l.updateAutoHeight(), l.updateSlidesClasses(), a.effect !== "slide" && l.setTranslate(u), p !== "reset" && (l.transitionStart(n, p), l.transitionEnd(n, p)), !1;
    if (a.cssMode) {
        const g = l.isHorizontal(),
            v = h ? u : -u;
        if (t === 0) {
            const T = l.virtual && l.params.virtual.enabled;
            T && (l.wrapperEl.style.scrollSnapType = "none", l._immediateVirtual = !0), y[g ? "scrollLeft" : "scrollTop"] = v, T && requestAnimationFrame(() => {
                l.wrapperEl.style.scrollSnapType = "", l._swiperImmediateVirtual = !1
            })
        } else {
            if (!l.support.smoothScroll) return df({
                swiper: l,
                targetPosition: v,
                side: g ? "left" : "top"
            }), !0;
            y.scrollTo({
                [g ? "left" : "top"]: v,
                behavior: "smooth"
            })
        }
        return !0
    }
    return l.setTransition(t), l.setTranslate(u), l.updateActiveIndex(s), l.updateSlidesClasses(), l.emit("beforeTransitionStart", t, r), l.transitionStart(n, p), t === 0 ? l.transitionEnd(n, p) : l.animating || (l.animating = !0, l.onSlideToWrapperTransitionEnd || (l.onSlideToWrapperTransitionEnd = function(v) {
        !l || l.destroyed || v.target === this && (l.$wrapperEl[0].removeEventListener("transitionend", l.onSlideToWrapperTransitionEnd), l.$wrapperEl[0].removeEventListener("webkitTransitionEnd", l.onSlideToWrapperTransitionEnd), l.onSlideToWrapperTransitionEnd = null, delete l.onSlideToWrapperTransitionEnd, l.transitionEnd(n, p))
    }), l.$wrapperEl[0].addEventListener("transitionend", l.onSlideToWrapperTransitionEnd), l.$wrapperEl[0].addEventListener("webkitTransitionEnd", l.onSlideToWrapperTransitionEnd)), !0
}

function dh(e, t, n, r) {
    if (e === void 0 && (e = 0), t === void 0 && (t = this.params.speed), n === void 0 && (n = !0), typeof e == "string") {
        const s = parseInt(e, 10);
        if (!isFinite(s)) throw new Error(`The passed-in 'index' (string) couldn't be converted to 'number'. [${e}] given.`);
        e = s
    }
    const i = this;
    let l = e;
    return i.params.loop && (l += i.loopedSlides), i.slideTo(l, t, n, r)
}

function ph(e, t, n) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const r = this,
        {
            animating: i,
            enabled: l,
            params: s
        } = r;
    if (!l) return r;
    let a = s.slidesPerGroup;
    s.slidesPerView === "auto" && s.slidesPerGroup === 1 && s.slidesPerGroupAuto && (a = Math.max(r.slidesPerViewDynamic("current", !0), 1));
    const o = r.activeIndex < s.slidesPerGroupSkip ? 1 : a;
    if (s.loop) {
        if (i && s.loopPreventsSlide) return !1;
        r.loopFix(), r._clientLeft = r.$wrapperEl[0].clientLeft
    }
    return s.rewind && r.isEnd ? r.slideTo(0, e, t, n) : r.slideTo(r.activeIndex + o, e, t, n)
}

function hh(e, t, n) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const r = this,
        {
            params: i,
            animating: l,
            snapGrid: s,
            slidesGrid: a,
            rtlTranslate: o,
            enabled: f
        } = r;
    if (!f) return r;
    if (i.loop) {
        if (l && i.loopPreventsSlide) return !1;
        r.loopFix(), r._clientLeft = r.$wrapperEl[0].clientLeft
    }
    const d = o ? r.translate : -r.translate;

    function m(c) {
        return c < 0 ? -Math.floor(Math.abs(c)) : Math.floor(c)
    }
    const h = m(d),
        y = s.map(c => m(c));
    let S = s[y.indexOf(h) - 1];
    if (typeof S == "undefined" && i.cssMode) {
        let c;
        s.forEach((u, p) => {
            h >= u && (c = p)
        }), typeof c != "undefined" && (S = s[c > 0 ? c - 1 : c])
    }
    let E = 0;
    if (typeof S != "undefined" && (E = a.indexOf(S), E < 0 && (E = r.activeIndex - 1), i.slidesPerView === "auto" && i.slidesPerGroup === 1 && i.slidesPerGroupAuto && (E = E - r.slidesPerViewDynamic("previous", !0) + 1, E = Math.max(E, 0))), i.rewind && r.isBeginning) {
        const c = r.params.virtual && r.params.virtual.enabled && r.virtual ? r.virtual.slides.length - 1 : r.slides.length - 1;
        return r.slideTo(c, e, t, n)
    }
    return r.slideTo(E, e, t, n)
}

function mh(e, t, n) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0);
    const r = this;
    return r.slideTo(r.activeIndex, e, t, n)
}

function gh(e, t, n, r) {
    e === void 0 && (e = this.params.speed), t === void 0 && (t = !0), r === void 0 && (r = .5);
    const i = this;
    let l = i.activeIndex;
    const s = Math.min(i.params.slidesPerGroupSkip, l),
        a = s + Math.floor((l - s) / i.params.slidesPerGroup),
        o = i.rtlTranslate ? i.translate : -i.translate;
    if (o >= i.snapGrid[a]) {
        const f = i.snapGrid[a],
            d = i.snapGrid[a + 1];
        o - f > (d - f) * r && (l += i.params.slidesPerGroup)
    } else {
        const f = i.snapGrid[a - 1],
            d = i.snapGrid[a];
        o - f <= (d - f) * r && (l -= i.params.slidesPerGroup)
    }
    return l = Math.max(l, 0), l = Math.min(l, i.slidesGrid.length - 1), i.slideTo(l, e, t, n)
}

function vh() {
    const e = this,
        {
            params: t,
            $wrapperEl: n
        } = e,
        r = t.slidesPerView === "auto" ? e.slidesPerViewDynamic() : t.slidesPerView;
    let i = e.clickedIndex,
        l;
    if (t.loop) {
        if (e.animating) return;
        l = parseInt(L(e.clickedSlide).attr("data-swiper-slide-index"), 10), t.centeredSlides ? i < e.loopedSlides - r / 2 || i > e.slides.length - e.loopedSlides + r / 2 ? (e.loopFix(), i = n.children(`.${t.slideClass}[data-swiper-slide-index="${l}"]:not(.${t.slideDuplicateClass})`).eq(0).index(), Ei(() => {
            e.slideTo(i)
        })) : e.slideTo(i) : i > e.slides.length - r ? (e.loopFix(), i = n.children(`.${t.slideClass}[data-swiper-slide-index="${l}"]:not(.${t.slideDuplicateClass})`).eq(0).index(), Ei(() => {
            e.slideTo(i)
        })) : e.slideTo(i)
    } else e.slideTo(i)
}
var yh = {
    slideTo: ch,
    slideToLoop: dh,
    slideNext: ph,
    slidePrev: hh,
    slideReset: mh,
    slideToClosest: gh,
    slideToClickedSlide: vh
};

function wh() {
    const e = this,
        t = re(),
        {
            params: n,
            $wrapperEl: r
        } = e,
        i = r.children().length > 0 ? L(r.children()[0].parentNode) : r;
    i.children(`.${n.slideClass}.${n.slideDuplicateClass}`).remove();
    let l = i.children(`.${n.slideClass}`);
    if (n.loopFillGroupWithBlank) {
        const o = n.slidesPerGroup - l.length % n.slidesPerGroup;
        if (o !== n.slidesPerGroup) {
            for (let f = 0; f < o; f += 1) {
                const d = L(t.createElement("div")).addClass(`${n.slideClass} ${n.slideBlankClass}`);
                i.append(d)
            }
            l = i.children(`.${n.slideClass}`)
        }
    }
    n.slidesPerView === "auto" && !n.loopedSlides && (n.loopedSlides = l.length), e.loopedSlides = Math.ceil(parseFloat(n.loopedSlides || n.slidesPerView, 10)), e.loopedSlides += n.loopAdditionalSlides, e.loopedSlides > l.length && e.params.loopedSlidesLimit && (e.loopedSlides = l.length);
    const s = [],
        a = [];
    l.each((o, f) => {
        L(o).attr("data-swiper-slide-index", f)
    });
    for (let o = 0; o < e.loopedSlides; o += 1) {
        const f = o - Math.floor(o / l.length) * l.length;
        a.push(l.eq(f)[0]), s.unshift(l.eq(l.length - f - 1)[0])
    }
    for (let o = 0; o < a.length; o += 1) i.append(L(a[o].cloneNode(!0)).addClass(n.slideDuplicateClass));
    for (let o = s.length - 1; o >= 0; o -= 1) i.prepend(L(s[o].cloneNode(!0)).addClass(n.slideDuplicateClass))
}

function Sh() {
    const e = this;
    e.emit("beforeLoopFix");
    const {
        activeIndex: t,
        slides: n,
        loopedSlides: r,
        allowSlidePrev: i,
        allowSlideNext: l,
        snapGrid: s,
        rtlTranslate: a
    } = e;
    let o;
    e.allowSlidePrev = !0, e.allowSlideNext = !0;
    const d = -s[t] - e.getTranslate();
    t < r ? (o = n.length - r * 3 + t, o += r, e.slideTo(o, 0, !1, !0) && d !== 0 && e.setTranslate((a ? -e.translate : e.translate) - d)) : t >= n.length - r && (o = -n.length + t + r, o += r, e.slideTo(o, 0, !1, !0) && d !== 0 && e.setTranslate((a ? -e.translate : e.translate) - d)), e.allowSlidePrev = i, e.allowSlideNext = l, e.emit("loopFix")
}

function Eh() {
    const e = this,
        {
            $wrapperEl: t,
            params: n,
            slides: r
        } = e;
    t.children(`.${n.slideClass}.${n.slideDuplicateClass},.${n.slideClass}.${n.slideBlankClass}`).remove(), r.removeAttr("data-swiper-slide-index")
}
var Ch = {
    loopCreate: wh,
    loopFix: Sh,
    loopDestroy: Eh
};

function xh(e) {
    const t = this;
    if (t.support.touch || !t.params.simulateTouch || t.params.watchOverflow && t.isLocked || t.params.cssMode) return;
    const n = t.params.touchEventsTarget === "container" ? t.el : t.wrapperEl;
    n.style.cursor = "move", n.style.cursor = e ? "grabbing" : "grab"
}

function Th() {
    const e = this;
    e.support.touch || e.params.watchOverflow && e.isLocked || e.params.cssMode || (e[e.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "")
}
var kh = {
    setGrabCursor: xh,
    unsetGrabCursor: Th
};

function Ph(e, t) {
    t === void 0 && (t = this);

    function n(r) {
        if (!r || r === re() || r === Z()) return null;
        r.assignedSlot && (r = r.assignedSlot);
        const i = r.closest(e);
        return !i && !r.getRootNode ? null : i || n(r.getRootNode().host)
    }
    return n(t)
}

function _h(e) {
    const t = this,
        n = re(),
        r = Z(),
        i = t.touchEventsData,
        {
            params: l,
            touches: s,
            enabled: a
        } = t;
    if (!a || t.animating && l.preventInteractionOnTransition) return;
    !t.animating && l.cssMode && l.loop && t.loopFix();
    let o = e;
    o.originalEvent && (o = o.originalEvent);
    let f = L(o.target);
    if (l.touchEventsTarget === "wrapper" && !f.closest(t.wrapperEl).length || (i.isTouchEvent = o.type === "touchstart", !i.isTouchEvent && "which" in o && o.which === 3) || !i.isTouchEvent && "button" in o && o.button > 0 || i.isTouched && i.isMoved) return;
    !!l.noSwipingClass && l.noSwipingClass !== "" && o.target && o.target.shadowRoot && e.path && e.path[0] && (f = L(e.path[0]));
    const m = l.noSwipingSelector ? l.noSwipingSelector : `.${l.noSwipingClass}`,
        h = !!(o.target && o.target.shadowRoot);
    if (l.noSwiping && (h ? Ph(m, f[0]) : f.closest(m)[0])) {
        t.allowClick = !0;
        return
    }
    if (l.swipeHandler && !f.closest(l.swipeHandler)[0]) return;
    s.currentX = o.type === "touchstart" ? o.targetTouches[0].pageX : o.pageX, s.currentY = o.type === "touchstart" ? o.targetTouches[0].pageY : o.pageY;
    const y = s.currentX,
        S = s.currentY,
        E = l.edgeSwipeDetection || l.iOSEdgeSwipeDetection,
        c = l.edgeSwipeThreshold || l.iOSEdgeSwipeThreshold;
    if (E && (y <= c || y >= r.innerWidth - c))
        if (E === "prevent") e.preventDefault();
        else return;
    if (Object.assign(i, {
            isTouched: !0,
            isMoved: !1,
            allowTouchCallbacks: !0,
            isScrolling: void 0,
            startMoving: void 0
        }), s.startX = y, s.startY = S, i.touchStartTime = fr(), t.allowClick = !0, t.updateSize(), t.swipeDirection = void 0, l.threshold > 0 && (i.allowThresholdMove = !1), o.type !== "touchstart") {
        let u = !0;
        f.is(i.focusableElements) && (u = !1, f[0].nodeName === "SELECT" && (i.isTouched = !1)), n.activeElement && L(n.activeElement).is(i.focusableElements) && n.activeElement !== f[0] && n.activeElement.blur();
        const p = u && t.allowTouchMove && l.touchStartPreventDefault;
        (l.touchStartForcePreventDefault || p) && !f[0].isContentEditable && o.preventDefault()
    }
    t.params.freeMode && t.params.freeMode.enabled && t.freeMode && t.animating && !l.cssMode && t.freeMode.onTouchStart(), t.emit("touchStart", o)
}

function Lh(e) {
    const t = re(),
        n = this,
        r = n.touchEventsData,
        {
            params: i,
            touches: l,
            rtlTranslate: s,
            enabled: a
        } = n;
    if (!a) return;
    let o = e;
    if (o.originalEvent && (o = o.originalEvent), !r.isTouched) {
        r.startMoving && r.isScrolling && n.emit("touchMoveOpposite", o);
        return
    }
    if (r.isTouchEvent && o.type !== "touchmove") return;
    const f = o.type === "touchmove" && o.targetTouches && (o.targetTouches[0] || o.changedTouches[0]),
        d = o.type === "touchmove" ? f.pageX : o.pageX,
        m = o.type === "touchmove" ? f.pageY : o.pageY;
    if (o.preventedByNestedSwiper) {
        l.startX = d, l.startY = m;
        return
    }
    if (!n.allowTouchMove) {
        L(o.target).is(r.focusableElements) || (n.allowClick = !1), r.isTouched && (Object.assign(l, {
            startX: d,
            startY: m,
            currentX: d,
            currentY: m
        }), r.touchStartTime = fr());
        return
    }
    if (r.isTouchEvent && i.touchReleaseOnEdges && !i.loop) {
        if (n.isVertical()) {
            if (m < l.startY && n.translate <= n.maxTranslate() || m > l.startY && n.translate >= n.minTranslate()) {
                r.isTouched = !1, r.isMoved = !1;
                return
            }
        } else if (d < l.startX && n.translate <= n.maxTranslate() || d > l.startX && n.translate >= n.minTranslate()) return
    }
    if (r.isTouchEvent && t.activeElement && o.target === t.activeElement && L(o.target).is(r.focusableElements)) {
        r.isMoved = !0, n.allowClick = !1;
        return
    }
    if (r.allowTouchCallbacks && n.emit("touchMove", o), o.targetTouches && o.targetTouches.length > 1) return;
    l.currentX = d, l.currentY = m;
    const h = l.currentX - l.startX,
        y = l.currentY - l.startY;
    if (n.params.threshold && Math.sqrt(h ** 2 + y ** 2) < n.params.threshold) return;
    if (typeof r.isScrolling == "undefined") {
        let u;
        n.isHorizontal() && l.currentY === l.startY || n.isVertical() && l.currentX === l.startX ? r.isScrolling = !1 : h * h + y * y >= 25 && (u = Math.atan2(Math.abs(y), Math.abs(h)) * 180 / Math.PI, r.isScrolling = n.isHorizontal() ? u > i.touchAngle : 90 - u > i.touchAngle)
    }
    if (r.isScrolling && n.emit("touchMoveOpposite", o), typeof r.startMoving == "undefined" && (l.currentX !== l.startX || l.currentY !== l.startY) && (r.startMoving = !0), r.isScrolling) {
        r.isTouched = !1;
        return
    }
    if (!r.startMoving) return;
    n.allowClick = !1, !i.cssMode && o.cancelable && o.preventDefault(), i.touchMoveStopPropagation && !i.nested && o.stopPropagation(), r.isMoved || (i.loop && !i.cssMode && n.loopFix(), r.startTranslate = n.getTranslate(), n.setTransition(0), n.animating && n.$wrapperEl.trigger("webkitTransitionEnd transitionend"), r.allowMomentumBounce = !1, i.grabCursor && (n.allowSlideNext === !0 || n.allowSlidePrev === !0) && n.setGrabCursor(!0), n.emit("sliderFirstMove", o)), n.emit("sliderMove", o), r.isMoved = !0;
    let S = n.isHorizontal() ? h : y;
    l.diff = S, S *= i.touchRatio, s && (S = -S), n.swipeDirection = S > 0 ? "prev" : "next", r.currentTranslate = S + r.startTranslate;
    let E = !0,
        c = i.resistanceRatio;
    if (i.touchReleaseOnEdges && (c = 0), S > 0 && r.currentTranslate > n.minTranslate() ? (E = !1, i.resistance && (r.currentTranslate = n.minTranslate() - 1 + (-n.minTranslate() + r.startTranslate + S) ** c)) : S < 0 && r.currentTranslate < n.maxTranslate() && (E = !1, i.resistance && (r.currentTranslate = n.maxTranslate() + 1 - (n.maxTranslate() - r.startTranslate - S) ** c)), E && (o.preventedByNestedSwiper = !0), !n.allowSlideNext && n.swipeDirection === "next" && r.currentTranslate < r.startTranslate && (r.currentTranslate = r.startTranslate), !n.allowSlidePrev && n.swipeDirection === "prev" && r.currentTranslate > r.startTranslate && (r.currentTranslate = r.startTranslate), !n.allowSlidePrev && !n.allowSlideNext && (r.currentTranslate = r.startTranslate), i.threshold > 0)
        if (Math.abs(S) > i.threshold || r.allowThresholdMove) {
            if (!r.allowThresholdMove) {
                r.allowThresholdMove = !0, l.startX = l.currentX, l.startY = l.currentY, r.currentTranslate = r.startTranslate, l.diff = n.isHorizontal() ? l.currentX - l.startX : l.currentY - l.startY;
                return
            }
        } else {
            r.currentTranslate = r.startTranslate;
            return
        }!i.followFinger || i.cssMode || ((i.freeMode && i.freeMode.enabled && n.freeMode || i.watchSlidesProgress) && (n.updateActiveIndex(), n.updateSlidesClasses()), n.params.freeMode && i.freeMode.enabled && n.freeMode && n.freeMode.onTouchMove(), n.updateProgress(r.currentTranslate), n.setTranslate(r.currentTranslate))
}

function Oh(e) {
    const t = this,
        n = t.touchEventsData,
        {
            params: r,
            touches: i,
            rtlTranslate: l,
            slidesGrid: s,
            enabled: a
        } = t;
    if (!a) return;
    let o = e;
    if (o.originalEvent && (o = o.originalEvent), n.allowTouchCallbacks && t.emit("touchEnd", o), n.allowTouchCallbacks = !1, !n.isTouched) {
        n.isMoved && r.grabCursor && t.setGrabCursor(!1), n.isMoved = !1, n.startMoving = !1;
        return
    }
    r.grabCursor && n.isMoved && n.isTouched && (t.allowSlideNext === !0 || t.allowSlidePrev === !0) && t.setGrabCursor(!1);
    const f = fr(),
        d = f - n.touchStartTime;
    if (t.allowClick) {
        const p = o.path || o.composedPath && o.composedPath();
        t.updateClickedSlide(p && p[0] || o.target), t.emit("tap click", o), d < 300 && f - n.lastClickTime < 300 && t.emit("doubleTap doubleClick", o)
    }
    if (n.lastClickTime = fr(), Ei(() => {
            t.destroyed || (t.allowClick = !0)
        }), !n.isTouched || !n.isMoved || !t.swipeDirection || i.diff === 0 || n.currentTranslate === n.startTranslate) {
        n.isTouched = !1, n.isMoved = !1, n.startMoving = !1;
        return
    }
    n.isTouched = !1, n.isMoved = !1, n.startMoving = !1;
    let m;
    if (r.followFinger ? m = l ? t.translate : -t.translate : m = -n.currentTranslate, r.cssMode) return;
    if (t.params.freeMode && r.freeMode.enabled) {
        t.freeMode.onTouchEnd({
            currentPos: m
        });
        return
    }
    let h = 0,
        y = t.slidesSizesGrid[0];
    for (let p = 0; p < s.length; p += p < r.slidesPerGroupSkip ? 1 : r.slidesPerGroup) {
        const g = p < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
        typeof s[p + g] != "undefined" ? m >= s[p] && m < s[p + g] && (h = p, y = s[p + g] - s[p]) : m >= s[p] && (h = p, y = s[s.length - 1] - s[s.length - 2])
    }
    let S = null,
        E = null;
    r.rewind && (t.isBeginning ? E = t.params.virtual && t.params.virtual.enabled && t.virtual ? t.virtual.slides.length - 1 : t.slides.length - 1 : t.isEnd && (S = 0));
    const c = (m - s[h]) / y,
        u = h < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
    if (d > r.longSwipesMs) {
        if (!r.longSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.swipeDirection === "next" && (c >= r.longSwipesRatio ? t.slideTo(r.rewind && t.isEnd ? S : h + u) : t.slideTo(h)), t.swipeDirection === "prev" && (c > 1 - r.longSwipesRatio ? t.slideTo(h + u) : E !== null && c < 0 && Math.abs(c) > r.longSwipesRatio ? t.slideTo(E) : t.slideTo(h))
    } else {
        if (!r.shortSwipes) {
            t.slideTo(t.activeIndex);
            return
        }
        t.navigation && (o.target === t.navigation.nextEl || o.target === t.navigation.prevEl) ? o.target === t.navigation.nextEl ? t.slideTo(h + u) : t.slideTo(h) : (t.swipeDirection === "next" && t.slideTo(S !== null ? S : h + u), t.swipeDirection === "prev" && t.slideTo(E !== null ? E : h))
    }
}

function mf() {
    const e = this,
        {
            params: t,
            el: n
        } = e;
    if (n && n.offsetWidth === 0) return;
    t.breakpoints && e.setBreakpoint();
    const {
        allowSlideNext: r,
        allowSlidePrev: i,
        snapGrid: l
    } = e;
    e.allowSlideNext = !0, e.allowSlidePrev = !0, e.updateSize(), e.updateSlides(), e.updateSlidesClasses(), (t.slidesPerView === "auto" || t.slidesPerView > 1) && e.isEnd && !e.isBeginning && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0), e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.run(), e.allowSlidePrev = i, e.allowSlideNext = r, e.params.watchOverflow && l !== e.snapGrid && e.checkOverflow()
}

function Mh(e) {
    const t = this;
    !t.enabled || t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation()))
}

function Nh() {
    const e = this,
        {
            wrapperEl: t,
            rtlTranslate: n,
            enabled: r
        } = e;
    if (!r) return;
    e.previousTranslate = e.translate, e.isHorizontal() ? e.translate = -t.scrollLeft : e.translate = -t.scrollTop, e.translate === 0 && (e.translate = 0), e.updateActiveIndex(), e.updateSlidesClasses();
    let i;
    const l = e.maxTranslate() - e.minTranslate();
    l === 0 ? i = 0 : i = (e.translate - e.minTranslate()) / l, i !== e.progress && e.updateProgress(n ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1)
}
let gf = !1;

function zh() {}
const vf = (e, t) => {
    const n = re(),
        {
            params: r,
            touchEvents: i,
            el: l,
            wrapperEl: s,
            device: a,
            support: o
        } = e,
        f = !!r.nested,
        d = t === "on" ? "addEventListener" : "removeEventListener",
        m = t;
    if (!o.touch) l[d](i.start, e.onTouchStart, !1), n[d](i.move, e.onTouchMove, f), n[d](i.end, e.onTouchEnd, !1);
    else {
        const h = i.start === "touchstart" && o.passiveListener && r.passiveListeners ? {
            passive: !0,
            capture: !1
        } : !1;
        l[d](i.start, e.onTouchStart, h), l[d](i.move, e.onTouchMove, o.passiveListener ? {
            passive: !1,
            capture: f
        } : f), l[d](i.end, e.onTouchEnd, h), i.cancel && l[d](i.cancel, e.onTouchEnd, h)
    }(r.preventClicks || r.preventClicksPropagation) && l[d]("click", e.onClick, !0), r.cssMode && s[d]("scroll", e.onScroll), r.updateOnWindowResize ? e[m](a.ios || a.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", mf, !0) : e[m]("observerUpdate", mf, !0)
};

function Ih() {
    const e = this,
        t = re(),
        {
            params: n,
            support: r
        } = e;
    e.onTouchStart = _h.bind(e), e.onTouchMove = Lh.bind(e), e.onTouchEnd = Oh.bind(e), n.cssMode && (e.onScroll = Nh.bind(e)), e.onClick = Mh.bind(e), r.touch && !gf && (t.addEventListener("touchstart", zh), gf = !0), vf(e, "on")
}

function $h() {
    vf(this, "off")
}
var Dh = {
    attachEvents: Ih,
    detachEvents: $h
};
const yf = (e, t) => e.grid && t.grid && t.grid.rows > 1;

function Rh() {
    const e = this,
        {
            activeIndex: t,
            initialized: n,
            loopedSlides: r = 0,
            params: i,
            $el: l
        } = e,
        s = i.breakpoints;
    if (!s || s && Object.keys(s).length === 0) return;
    const a = e.getBreakpoint(s, e.params.breakpointsBase, e.el);
    if (!a || e.currentBreakpoint === a) return;
    const f = (a in s ? s[a] : void 0) || e.originalParams,
        d = yf(e, i),
        m = yf(e, f),
        h = i.enabled;
    d && !m ? (l.removeClass(`${i.containerModifierClass}grid ${i.containerModifierClass}grid-column`), e.emitContainerClasses()) : !d && m && (l.addClass(`${i.containerModifierClass}grid`), (f.grid.fill && f.grid.fill === "column" || !f.grid.fill && i.grid.fill === "column") && l.addClass(`${i.containerModifierClass}grid-column`), e.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach(c => {
        const u = i[c] && i[c].enabled,
            p = f[c] && f[c].enabled;
        u && !p && e[c].disable(), !u && p && e[c].enable()
    });
    const y = f.direction && f.direction !== i.direction,
        S = i.loop && (f.slidesPerView !== i.slidesPerView || y);
    y && n && e.changeDirection(), ye(e.params, f);
    const E = e.params.enabled;
    Object.assign(e, {
        allowTouchMove: e.params.allowTouchMove,
        allowSlideNext: e.params.allowSlideNext,
        allowSlidePrev: e.params.allowSlidePrev
    }), h && !E ? e.disable() : !h && E && e.enable(), e.currentBreakpoint = a, e.emit("_beforeBreakpoint", f), S && n && (e.loopDestroy(), e.loopCreate(), e.updateSlides(), e.slideTo(t - r + e.loopedSlides, 0, !1)), e.emit("breakpoint", f)
}

function Ah(e, t, n) {
    if (t === void 0 && (t = "window"), !e || t === "container" && !n) return;
    let r = !1;
    const i = Z(),
        l = t === "window" ? i.innerHeight : n.clientHeight,
        s = Object.keys(e).map(a => {
            if (typeof a == "string" && a.indexOf("@") === 0) {
                const o = parseFloat(a.substr(1));
                return {
                    value: l * o,
                    point: a
                }
            }
            return {
                value: a,
                point: a
            }
        });
    s.sort((a, o) => parseInt(a.value, 10) - parseInt(o.value, 10));
    for (let a = 0; a < s.length; a += 1) {
        const {
            point: o,
            value: f
        } = s[a];
        t === "window" ? i.matchMedia(`(min-width: ${f}px)`).matches && (r = o) : f <= n.clientWidth && (r = o)
    }
    return r || "max"
}
var Fh = {
    setBreakpoint: Rh,
    getBreakpoint: Ah
};

function jh(e, t) {
    const n = [];
    return e.forEach(r => {
        typeof r == "object" ? Object.keys(r).forEach(i => {
            r[i] && n.push(t + i)
        }) : typeof r == "string" && n.push(t + r)
    }), n
}

function Bh() {
    const e = this,
        {
            classNames: t,
            params: n,
            rtl: r,
            $el: i,
            device: l,
            support: s
        } = e,
        a = jh(["initialized", n.direction, {
            "pointer-events": !s.touch
        }, {
            "free-mode": e.params.freeMode && n.freeMode.enabled
        }, {
            autoheight: n.autoHeight
        }, {
            rtl: r
        }, {
            grid: n.grid && n.grid.rows > 1
        }, {
            "grid-column": n.grid && n.grid.rows > 1 && n.grid.fill === "column"
        }, {
            android: l.android
        }, {
            ios: l.ios
        }, {
            "css-mode": n.cssMode
        }, {
            centered: n.cssMode && n.centeredSlides
        }, {
            "watch-progress": n.watchSlidesProgress
        }], n.containerModifierClass);
    t.push(...a), i.addClass([...t].join(" ")), e.emitContainerClasses()
}

function Vh() {
    const e = this,
        {
            $el: t,
            classNames: n
        } = e;
    t.removeClass(n.join(" ")), e.emitContainerClasses()
}
var Hh = {
    addClasses: Bh,
    removeClasses: Vh
};

function Uh(e, t, n, r, i, l) {
    const s = Z();
    let a;

    function o() {
        l && l()
    }!L(e).parent("picture")[0] && (!e.complete || !i) && t ? (a = new s.Image, a.onload = o, a.onerror = o, r && (a.sizes = r), n && (a.srcset = n), t && (a.src = t)) : o()
}

function Wh() {
    const e = this;
    e.imagesToLoad = e.$el.find("img");

    function t() {
        typeof e == "undefined" || e === null || !e || e.destroyed || (e.imagesLoaded !== void 0 && (e.imagesLoaded += 1), e.imagesLoaded === e.imagesToLoad.length && (e.params.updateOnImagesReady && e.update(), e.emit("imagesReady")))
    }
    for (let n = 0; n < e.imagesToLoad.length; n += 1) {
        const r = e.imagesToLoad[n];
        e.loadImage(r, r.currentSrc || r.getAttribute("src"), r.srcset || r.getAttribute("srcset"), r.sizes || r.getAttribute("sizes"), !0, t)
    }
}
var Gh = {
    loadImage: Uh,
    preloadImages: Wh
};

function Yh() {
    const e = this,
        {
            isLocked: t,
            params: n
        } = e,
        {
            slidesOffsetBefore: r
        } = n;
    if (r) {
        const i = e.slides.length - 1,
            l = e.slidesGrid[i] + e.slidesSizesGrid[i] + r * 2;
        e.isLocked = e.size > l
    } else e.isLocked = e.snapGrid.length === 1;
    n.allowSlideNext === !0 && (e.allowSlideNext = !e.isLocked), n.allowSlidePrev === !0 && (e.allowSlidePrev = !e.isLocked), t && t !== e.isLocked && (e.isEnd = !1), t !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock")
}
var bh = {
        checkOverflow: Yh
    },
    wf = {
        init: !0,
        direction: "horizontal",
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 0,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        preloadImages: !0,
        updateOnImagesReady: !0,
        loop: !1,
        loopAdditionalSlides: 0,
        loopedSlides: null,
        loopedSlidesLimit: !0,
        loopFillGroupWithBlank: !1,
        loopPreventsSlide: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideBlankClass: "swiper-slide-invisible-blank",
        slideActiveClass: "swiper-slide-active",
        slideDuplicateActiveClass: "swiper-slide-duplicate-active",
        slideVisibleClass: "swiper-slide-visible",
        slideDuplicateClass: "swiper-slide-duplicate",
        slideNextClass: "swiper-slide-next",
        slideDuplicateNextClass: "swiper-slide-duplicate-next",
        slidePrevClass: "swiper-slide-prev",
        slideDuplicatePrevClass: "swiper-slide-duplicate-prev",
        wrapperClass: "swiper-wrapper",
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

function Xh(e, t) {
    return function(r) {
        r === void 0 && (r = {});
        const i = Object.keys(r)[0],
            l = r[i];
        if (typeof l != "object" || l === null) {
            ye(t, r);
            return
        }
        if (["navigation", "pagination", "scrollbar"].indexOf(i) >= 0 && e[i] === !0 && (e[i] = {
                auto: !0
            }), !(i in e && "enabled" in l)) {
            ye(t, r);
            return
        }
        e[i] === !0 && (e[i] = {
            enabled: !0
        }), typeof e[i] == "object" && !("enabled" in e[i]) && (e[i].enabled = !0), e[i] || (e[i] = {
            enabled: !1
        }), ye(t, r)
    }
}
const js = {
        eventsEmitter: Wp,
        update: eh,
        translate: sh,
        transition: fh,
        slide: yh,
        loop: Ch,
        grabCursor: kh,
        events: Dh,
        breakpoints: Fh,
        checkOverflow: bh,
        classes: Hh,
        images: Gh
    },
    Bs = {};
class fe {
    constructor() {
        let t, n;
        for (var r = arguments.length, i = new Array(r), l = 0; l < r; l++) i[l] = arguments[l];
        if (i.length === 1 && i[0].constructor && Object.prototype.toString.call(i[0]).slice(8, -1) === "Object" ? n = i[0] : [t, n] = i, n || (n = {}), n = ye({}, n), t && !n.el && (n.el = t), n.el && L(n.el).length > 1) {
            const f = [];
            return L(n.el).each(d => {
                const m = ye({}, n, {
                    el: d
                });
                f.push(new fe(m))
            }), f
        }
        const s = this;
        s.__swiper__ = !0, s.support = pf(), s.device = jp({
            userAgent: n.userAgent
        }), s.browser = Vp(), s.eventsListeners = {}, s.eventsAnyListeners = [], s.modules = [...s.__modules__], n.modules && Array.isArray(n.modules) && s.modules.push(...n.modules);
        const a = {};
        s.modules.forEach(f => {
            f({
                swiper: s,
                extendParams: Xh(n, a),
                on: s.on.bind(s),
                once: s.once.bind(s),
                off: s.off.bind(s),
                emit: s.emit.bind(s)
            })
        });
        const o = ye({}, wf, a);
        return s.params = ye({}, o, Bs, n), s.originalParams = ye({}, s.params), s.passedParams = ye({}, n), s.params && s.params.on && Object.keys(s.params.on).forEach(f => {
            s.on(f, s.params.on[f])
        }), s.params && s.params.onAny && s.onAny(s.params.onAny), s.$ = L, Object.assign(s, {
            enabled: s.params.enabled,
            el: t,
            classNames: [],
            slides: L(),
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal() {
                return s.params.direction === "horizontal"
            },
            isVertical() {
                return s.params.direction === "vertical"
            },
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            allowSlideNext: s.params.allowSlideNext,
            allowSlidePrev: s.params.allowSlidePrev,
            touchEvents: function() {
                const d = ["touchstart", "touchmove", "touchend", "touchcancel"],
                    m = ["pointerdown", "pointermove", "pointerup"];
                return s.touchEventsTouch = {
                    start: d[0],
                    move: d[1],
                    end: d[2],
                    cancel: d[3]
                }, s.touchEventsDesktop = {
                    start: m[0],
                    move: m[1],
                    end: m[2]
                }, s.support.touch || !s.params.simulateTouch ? s.touchEventsTouch : s.touchEventsDesktop
            }(),
            touchEventsData: {
                isTouched: void 0,
                isMoved: void 0,
                allowTouchCallbacks: void 0,
                touchStartTime: void 0,
                isScrolling: void 0,
                currentTranslate: void 0,
                startTranslate: void 0,
                allowThresholdMove: void 0,
                focusableElements: s.params.focusableElements,
                lastClickTime: fr(),
                clickTimeout: void 0,
                velocities: [],
                allowMomentumBounce: void 0,
                isTouchEvent: void 0,
                startMoving: void 0
            },
            allowClick: !0,
            allowTouchMove: s.params.allowTouchMove,
            touches: {
                startX: 0,
                startY: 0,
                currentX: 0,
                currentY: 0,
                diff: 0
            },
            imagesToLoad: [],
            imagesLoaded: 0
        }), s.emit("_swiper"), s.params.init && s.init(), s
    }
    enable() {
        const t = this;
        t.enabled || (t.enabled = !0, t.params.grabCursor && t.setGrabCursor(), t.emit("enable"))
    }
    disable() {
        const t = this;
        !t.enabled || (t.enabled = !1, t.params.grabCursor && t.unsetGrabCursor(), t.emit("disable"))
    }
    setProgress(t, n) {
        const r = this;
        t = Math.min(Math.max(t, 0), 1);
        const i = r.minTranslate(),
            s = (r.maxTranslate() - i) * t + i;
        r.translateTo(s, typeof n == "undefined" ? 0 : n), r.updateActiveIndex(), r.updateSlidesClasses()
    }
    emitContainerClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const n = t.el.className.split(" ").filter(r => r.indexOf("swiper") === 0 || r.indexOf(t.params.containerModifierClass) === 0);
        t.emit("_containerClasses", n.join(" "))
    }
    getSlideClasses(t) {
        const n = this;
        return n.destroyed ? "" : t.className.split(" ").filter(r => r.indexOf("swiper-slide") === 0 || r.indexOf(n.params.slideClass) === 0).join(" ")
    }
    emitSlidesClasses() {
        const t = this;
        if (!t.params._emitClasses || !t.el) return;
        const n = [];
        t.slides.each(r => {
            const i = t.getSlideClasses(r);
            n.push({
                slideEl: r,
                classNames: i
            }), t.emit("_slideClass", r, i)
        }), t.emit("_slideClasses", n)
    }
    slidesPerViewDynamic(t, n) {
        t === void 0 && (t = "current"), n === void 0 && (n = !1);
        const r = this,
            {
                params: i,
                slides: l,
                slidesGrid: s,
                slidesSizesGrid: a,
                size: o,
                activeIndex: f
            } = r;
        let d = 1;
        if (i.centeredSlides) {
            let m = l[f].swiperSlideSize,
                h;
            for (let y = f + 1; y < l.length; y += 1) l[y] && !h && (m += l[y].swiperSlideSize, d += 1, m > o && (h = !0));
            for (let y = f - 1; y >= 0; y -= 1) l[y] && !h && (m += l[y].swiperSlideSize, d += 1, m > o && (h = !0))
        } else if (t === "current")
            for (let m = f + 1; m < l.length; m += 1)(n ? s[m] + a[m] - s[f] < o : s[m] - s[f] < o) && (d += 1);
        else
            for (let m = f - 1; m >= 0; m -= 1) s[f] - s[m] < o && (d += 1);
        return d
    }
    update() {
        const t = this;
        if (!t || t.destroyed) return;
        const {
            snapGrid: n,
            params: r
        } = t;
        r.breakpoints && t.setBreakpoint(), t.updateSize(), t.updateSlides(), t.updateProgress(), t.updateSlidesClasses();

        function i() {
            const s = t.rtlTranslate ? t.translate * -1 : t.translate,
                a = Math.min(Math.max(s, t.maxTranslate()), t.minTranslate());
            t.setTranslate(a), t.updateActiveIndex(), t.updateSlidesClasses()
        }
        let l;
        t.params.freeMode && t.params.freeMode.enabled ? (i(), t.params.autoHeight && t.updateAutoHeight()) : ((t.params.slidesPerView === "auto" || t.params.slidesPerView > 1) && t.isEnd && !t.params.centeredSlides ? l = t.slideTo(t.slides.length - 1, 0, !1, !0) : l = t.slideTo(t.activeIndex, 0, !1, !0), l || i()), r.watchOverflow && n !== t.snapGrid && t.checkOverflow(), t.emit("update")
    }
    changeDirection(t, n) {
        n === void 0 && (n = !0);
        const r = this,
            i = r.params.direction;
        return t || (t = i === "horizontal" ? "vertical" : "horizontal"), t === i || t !== "horizontal" && t !== "vertical" || (r.$el.removeClass(`${r.params.containerModifierClass}${i}`).addClass(`${r.params.containerModifierClass}${t}`), r.emitContainerClasses(), r.params.direction = t, r.slides.each(l => {
            t === "vertical" ? l.style.width = "" : l.style.height = ""
        }), r.emit("changeDirection"), n && r.update()), r
    }
    changeLanguageDirection(t) {
        const n = this;
        n.rtl && t === "rtl" || !n.rtl && t === "ltr" || (n.rtl = t === "rtl", n.rtlTranslate = n.params.direction === "horizontal" && n.rtl, n.rtl ? (n.$el.addClass(`${n.params.containerModifierClass}rtl`), n.el.dir = "rtl") : (n.$el.removeClass(`${n.params.containerModifierClass}rtl`), n.el.dir = "ltr"), n.update())
    }
    mount(t) {
        const n = this;
        if (n.mounted) return !0;
        const r = L(t || n.params.el);
        if (t = r[0], !t) return !1;
        t.swiper = n;
        const i = () => `.${(n.params.wrapperClass||"").trim().split(" ").join(".")}`;
        let s = (() => {
            if (t && t.shadowRoot && t.shadowRoot.querySelector) {
                const a = L(t.shadowRoot.querySelector(i()));
                return a.children = o => r.children(o), a
            }
            return r.children ? r.children(i()) : L(r).children(i())
        })();
        if (s.length === 0 && n.params.createElements) {
            const o = re().createElement("div");
            s = L(o), o.className = n.params.wrapperClass, r.append(o), r.children(`.${n.params.slideClass}`).each(f => {
                s.append(f)
            })
        }
        return Object.assign(n, {
            $el: r,
            el: t,
            $wrapperEl: s,
            wrapperEl: s[0],
            mounted: !0,
            rtl: t.dir.toLowerCase() === "rtl" || r.css("direction") === "rtl",
            rtlTranslate: n.params.direction === "horizontal" && (t.dir.toLowerCase() === "rtl" || r.css("direction") === "rtl"),
            wrongRTL: s.css("display") === "-webkit-box"
        }), !0
    }
    init(t) {
        const n = this;
        return n.initialized || n.mount(t) === !1 || (n.emit("beforeInit"), n.params.breakpoints && n.setBreakpoint(), n.addClasses(), n.params.loop && n.loopCreate(), n.updateSize(), n.updateSlides(), n.params.watchOverflow && n.checkOverflow(), n.params.grabCursor && n.enabled && n.setGrabCursor(), n.params.preloadImages && n.preloadImages(), n.params.loop ? n.slideTo(n.params.initialSlide + n.loopedSlides, 0, n.params.runCallbacksOnInit, !1, !0) : n.slideTo(n.params.initialSlide, 0, n.params.runCallbacksOnInit, !1, !0), n.attachEvents(), n.initialized = !0, n.emit("init"), n.emit("afterInit")), n
    }
    destroy(t, n) {
        t === void 0 && (t = !0), n === void 0 && (n = !0);
        const r = this,
            {
                params: i,
                $el: l,
                $wrapperEl: s,
                slides: a
            } = r;
        return typeof r.params == "undefined" || r.destroyed || (r.emit("beforeDestroy"), r.initialized = !1, r.detachEvents(), i.loop && r.loopDestroy(), n && (r.removeClasses(), l.removeAttr("style"), s.removeAttr("style"), a && a.length && a.removeClass([i.slideVisibleClass, i.slideActiveClass, i.slideNextClass, i.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-slide-index")), r.emit("destroy"), Object.keys(r.eventsListeners).forEach(o => {
            r.off(o)
        }), t !== !1 && (r.$el[0].swiper = null, Ip(r)), r.destroyed = !0), null
    }
    static extendDefaults(t) {
        ye(Bs, t)
    }
    static get extendedDefaults() {
        return Bs
    }
    static get defaults() {
        return wf
    }
    static installModule(t) {
        fe.prototype.__modules__ || (fe.prototype.__modules__ = []);
        const n = fe.prototype.__modules__;
        typeof t == "function" && n.indexOf(t) < 0 && n.push(t)
    }
    static use(t) {
        return Array.isArray(t) ? (t.forEach(n => fe.installModule(n)), fe) : (fe.installModule(t), fe)
    }
}
Object.keys(js).forEach(e => {
    Object.keys(js[e]).forEach(t => {
        fe.prototype[t] = js[e][t]
    })
});
fe.use([Hp, Up]);

function Qh(e, t, n, r) {
    const i = re();
    return e.params.createElements && Object.keys(r).forEach(l => {
        if (!n[l] && n.auto === !0) {
            let s = e.$el.children(`.${r[l]}`)[0];
            s || (s = i.createElement("div"), s.className = r[l], e.$el.append(s)), n[l] = s, t[l] = s
        }
    }), n
}

function cn(e) {
    return e === void 0 && (e = ""), `.${e.trim().replace(/([\.:!\/])/g,"\\$1").replace(/ /g,".")}`
}

function cm(e) {
    let {
        swiper: t,
        extendParams: n,
        on: r,
        emit: i
    } = e;
    const l = "swiper-pagination";
    n({
        pagination: {
            el: null,
            bulletElement: "span",
            clickable: !1,
            hideOnClick: !1,
            renderBullet: null,
            renderProgressbar: null,
            renderFraction: null,
            renderCustom: null,
            progressbarOpposite: !1,
            type: "bullets",
            dynamicBullets: !1,
            dynamicMainBullets: 1,
            formatFractionCurrent: c => c,
            formatFractionTotal: c => c,
            bulletClass: `${l}-bullet`,
            bulletActiveClass: `${l}-bullet-active`,
            modifierClass: `${l}-`,
            currentClass: `${l}-current`,
            totalClass: `${l}-total`,
            hiddenClass: `${l}-hidden`,
            progressbarFillClass: `${l}-progressbar-fill`,
            progressbarOppositeClass: `${l}-progressbar-opposite`,
            clickableClass: `${l}-clickable`,
            lockClass: `${l}-lock`,
            horizontalClass: `${l}-horizontal`,
            verticalClass: `${l}-vertical`,
            paginationDisabledClass: `${l}-disabled`
        }
    }), t.pagination = {
        el: null,
        $el: null,
        bullets: []
    };
    let s, a = 0;

    function o() {
        return !t.params.pagination.el || !t.pagination.el || !t.pagination.$el || t.pagination.$el.length === 0
    }

    function f(c, u) {
        const {
            bulletActiveClass: p
        } = t.params.pagination;
        c[u]().addClass(`${p}-${u}`)[u]().addClass(`${p}-${u}-${u}`)
    }

    function d() {
        const c = t.rtl,
            u = t.params.pagination;
        if (o()) return;
        const p = t.virtual && t.params.virtual.enabled ? t.virtual.slides.length : t.slides.length,
            g = t.pagination.$el;
        let v;
        const T = t.params.loop ? Math.ceil((p - t.loopedSlides * 2) / t.params.slidesPerGroup) : t.snapGrid.length;
        if (t.params.loop ? (v = Math.ceil((t.activeIndex - t.loopedSlides) / t.params.slidesPerGroup), v > p - 1 - t.loopedSlides * 2 && (v -= p - t.loopedSlides * 2), v > T - 1 && (v -= T), v < 0 && t.params.paginationType !== "bullets" && (v = T + v)) : typeof t.snapIndex != "undefined" ? v = t.snapIndex : v = t.activeIndex || 0, u.type === "bullets" && t.pagination.bullets && t.pagination.bullets.length > 0) {
            const w = t.pagination.bullets;
            let P, x, O;
            if (u.dynamicBullets && (s = w.eq(0)[t.isHorizontal() ? "outerWidth" : "outerHeight"](!0), g.css(t.isHorizontal() ? "width" : "height", `${s*(u.dynamicMainBullets+4)}px`), u.dynamicMainBullets > 1 && t.previousIndex !== void 0 && (a += v - (t.previousIndex - t.loopedSlides || 0), a > u.dynamicMainBullets - 1 ? a = u.dynamicMainBullets - 1 : a < 0 && (a = 0)), P = Math.max(v - a, 0), x = P + (Math.min(w.length, u.dynamicMainBullets) - 1), O = (x + P) / 2), w.removeClass(["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map(_ => `${u.bulletActiveClass}${_}`).join(" ")), g.length > 1) w.each(_ => {
                const z = L(_),
                    N = z.index();
                N === v && z.addClass(u.bulletActiveClass), u.dynamicBullets && (N >= P && N <= x && z.addClass(`${u.bulletActiveClass}-main`), N === P && f(z, "prev"), N === x && f(z, "next"))
            });
            else {
                const _ = w.eq(v),
                    z = _.index();
                if (_.addClass(u.bulletActiveClass), u.dynamicBullets) {
                    const N = w.eq(P),
                        F = w.eq(x);
                    for (let b = P; b <= x; b += 1) w.eq(b).addClass(`${u.bulletActiveClass}-main`);
                    if (t.params.loop)
                        if (z >= w.length) {
                            for (let b = u.dynamicMainBullets; b >= 0; b -= 1) w.eq(w.length - b).addClass(`${u.bulletActiveClass}-main`);
                            w.eq(w.length - u.dynamicMainBullets - 1).addClass(`${u.bulletActiveClass}-prev`)
                        } else f(N, "prev"), f(F, "next");
                    else f(N, "prev"), f(F, "next")
                }
            }
            if (u.dynamicBullets) {
                const _ = Math.min(w.length, u.dynamicMainBullets + 4),
                    z = (s * _ - s) / 2 - O * s,
                    N = c ? "right" : "left";
                w.css(t.isHorizontal() ? N : "top", `${z}px`)
            }
        }
        if (u.type === "fraction" && (g.find(cn(u.currentClass)).text(u.formatFractionCurrent(v + 1)), g.find(cn(u.totalClass)).text(u.formatFractionTotal(T))), u.type === "progressbar") {
            let w;
            u.progressbarOpposite ? w = t.isHorizontal() ? "vertical" : "horizontal" : w = t.isHorizontal() ? "horizontal" : "vertical";
            const P = (v + 1) / T;
            let x = 1,
                O = 1;
            w === "horizontal" ? x = P : O = P, g.find(cn(u.progressbarFillClass)).transform(`translate3d(0,0,0) scaleX(${x}) scaleY(${O})`).transition(t.params.speed)
        }
        u.type === "custom" && u.renderCustom ? (g.html(u.renderCustom(t, v + 1, T)), i("paginationRender", g[0])) : i("paginationUpdate", g[0]), t.params.watchOverflow && t.enabled && g[t.isLocked ? "addClass" : "removeClass"](u.lockClass)
    }

    function m() {
        const c = t.params.pagination;
        if (o()) return;
        const u = t.virtual && t.params.virtual.enabled ? t.virtual.slides.length : t.slides.length,
            p = t.pagination.$el;
        let g = "";
        if (c.type === "bullets") {
            let v = t.params.loop ? Math.ceil((u - t.loopedSlides * 2) / t.params.slidesPerGroup) : t.snapGrid.length;
            t.params.freeMode && t.params.freeMode.enabled && !t.params.loop && v > u && (v = u);
            for (let T = 0; T < v; T += 1) c.renderBullet ? g += c.renderBullet.call(t, T, c.bulletClass) : g += `<${c.bulletElement} class="${c.bulletClass}"></${c.bulletElement}>`;
            p.html(g), t.pagination.bullets = p.find(cn(c.bulletClass))
        }
        c.type === "fraction" && (c.renderFraction ? g = c.renderFraction.call(t, c.currentClass, c.totalClass) : g = `<span class="${c.currentClass}"></span> / <span class="${c.totalClass}"></span>`, p.html(g)), c.type === "progressbar" && (c.renderProgressbar ? g = c.renderProgressbar.call(t, c.progressbarFillClass) : g = `<span class="${c.progressbarFillClass}"></span>`, p.html(g)), c.type !== "custom" && i("paginationRender", t.pagination.$el[0])
    }

    function h() {
        t.params.pagination = Qh(t, t.originalParams.pagination, t.params.pagination, {
            el: "swiper-pagination"
        });
        const c = t.params.pagination;
        if (!c.el) return;
        let u = L(c.el);
        u.length !== 0 && (t.params.uniqueNavElements && typeof c.el == "string" && u.length > 1 && (u = t.$el.find(c.el), u.length > 1 && (u = u.filter(p => L(p).parents(".swiper")[0] === t.el))), c.type === "bullets" && c.clickable && u.addClass(c.clickableClass), u.addClass(c.modifierClass + c.type), u.addClass(t.isHorizontal() ? c.horizontalClass : c.verticalClass), c.type === "bullets" && c.dynamicBullets && (u.addClass(`${c.modifierClass}${c.type}-dynamic`), a = 0, c.dynamicMainBullets < 1 && (c.dynamicMainBullets = 1)), c.type === "progressbar" && c.progressbarOpposite && u.addClass(c.progressbarOppositeClass), c.clickable && u.on("click", cn(c.bulletClass), function(g) {
            g.preventDefault();
            let v = L(this).index() * t.params.slidesPerGroup;
            t.params.loop && (v += t.loopedSlides), t.slideTo(v)
        }), Object.assign(t.pagination, {
            $el: u,
            el: u[0]
        }), t.enabled || u.addClass(c.lockClass))
    }

    function y() {
        const c = t.params.pagination;
        if (o()) return;
        const u = t.pagination.$el;
        u.removeClass(c.hiddenClass), u.removeClass(c.modifierClass + c.type), u.removeClass(t.isHorizontal() ? c.horizontalClass : c.verticalClass), t.pagination.bullets && t.pagination.bullets.removeClass && t.pagination.bullets.removeClass(c.bulletActiveClass), c.clickable && u.off("click", cn(c.bulletClass))
    }
    r("init", () => {
        t.params.pagination.enabled === !1 ? E() : (h(), m(), d())
    }), r("activeIndexChange", () => {
        (t.params.loop || typeof t.snapIndex == "undefined") && d()
    }), r("snapIndexChange", () => {
        t.params.loop || d()
    }), r("slidesLengthChange", () => {
        t.params.loop && (m(), d())
    }), r("snapGridLengthChange", () => {
        t.params.loop || (m(), d())
    }), r("destroy", () => {
        y()
    }), r("enable disable", () => {
        const {
            $el: c
        } = t.pagination;
        c && c[t.enabled ? "removeClass" : "addClass"](t.params.pagination.lockClass)
    }), r("lock unlock", () => {
        d()
    }), r("click", (c, u) => {
        const p = u.target,
            {
                $el: g
            } = t.pagination;
        if (t.params.pagination.el && t.params.pagination.hideOnClick && g && g.length > 0 && !L(p).hasClass(t.params.pagination.bulletClass)) {
            if (t.navigation && (t.navigation.nextEl && p === t.navigation.nextEl || t.navigation.prevEl && p === t.navigation.prevEl)) return;
            const v = g.hasClass(t.params.pagination.hiddenClass);
            i(v === !0 ? "paginationShow" : "paginationHide"), g.toggleClass(t.params.pagination.hiddenClass)
        }
    });
    const S = () => {
            t.$el.removeClass(t.params.pagination.paginationDisabledClass), t.pagination.$el && t.pagination.$el.removeClass(t.params.pagination.paginationDisabledClass), h(), m(), d()
        },
        E = () => {
            t.$el.addClass(t.params.pagination.paginationDisabledClass), t.pagination.$el && t.pagination.$el.addClass(t.params.pagination.paginationDisabledClass), y()
        };
    Object.assign(t.pagination, {
        enable: S,
        disable: E,
        render: m,
        update: d,
        init: h,
        destroy: y
    })
}

function dm(e) {
    let {
        swiper: t,
        extendParams: n,
        on: r,
        emit: i
    } = e, l;
    t.autoplay = {
        running: !1,
        paused: !1
    }, n({
        autoplay: {
            enabled: !1,
            delay: 3e3,
            waitForTransition: !0,
            disableOnInteraction: !0,
            stopOnLastSlide: !1,
            reverseDirection: !1,
            pauseOnMouseEnter: !1
        }
    });

    function s() {
        if (!t.size) {
            t.autoplay.running = !1, t.autoplay.paused = !1;
            return
        }
        const c = t.slides.eq(t.activeIndex);
        let u = t.params.autoplay.delay;
        c.attr("data-swiper-autoplay") && (u = c.attr("data-swiper-autoplay") || t.params.autoplay.delay), clearTimeout(l), l = Ei(() => {
            let p;
            t.params.autoplay.reverseDirection ? t.params.loop ? (t.loopFix(), p = t.slidePrev(t.params.speed, !0, !0), i("autoplay")) : t.isBeginning ? t.params.autoplay.stopOnLastSlide ? o() : (p = t.slideTo(t.slides.length - 1, t.params.speed, !0, !0), i("autoplay")) : (p = t.slidePrev(t.params.speed, !0, !0), i("autoplay")) : t.params.loop ? (t.loopFix(), p = t.slideNext(t.params.speed, !0, !0), i("autoplay")) : t.isEnd ? t.params.autoplay.stopOnLastSlide ? o() : (p = t.slideTo(0, t.params.speed, !0, !0), i("autoplay")) : (p = t.slideNext(t.params.speed, !0, !0), i("autoplay")), (t.params.cssMode && t.autoplay.running || p === !1) && s()
        }, u)
    }

    function a() {
        return typeof l != "undefined" || t.autoplay.running ? !1 : (t.autoplay.running = !0, i("autoplayStart"), s(), !0)
    }

    function o() {
        return !t.autoplay.running || typeof l == "undefined" ? !1 : (l && (clearTimeout(l), l = void 0), t.autoplay.running = !1, i("autoplayStop"), !0)
    }

    function f(c) {
        !t.autoplay.running || t.autoplay.paused || (l && clearTimeout(l), t.autoplay.paused = !0, c === 0 || !t.params.autoplay.waitForTransition ? (t.autoplay.paused = !1, s()) : ["transitionend", "webkitTransitionEnd"].forEach(u => {
            t.$wrapperEl[0].addEventListener(u, m)
        }))
    }

    function d() {
        const c = re();
        c.visibilityState === "hidden" && t.autoplay.running && f(), c.visibilityState === "visible" && t.autoplay.paused && (s(), t.autoplay.paused = !1)
    }

    function m(c) {
        !t || t.destroyed || !t.$wrapperEl || c.target === t.$wrapperEl[0] && (["transitionend", "webkitTransitionEnd"].forEach(u => {
            t.$wrapperEl[0].removeEventListener(u, m)
        }), t.autoplay.paused = !1, t.autoplay.running ? s() : o())
    }

    function h() {
        t.params.autoplay.disableOnInteraction ? o() : (i("autoplayPause"), f()), ["transitionend", "webkitTransitionEnd"].forEach(c => {
            t.$wrapperEl[0].removeEventListener(c, m)
        })
    }

    function y() {
        t.params.autoplay.disableOnInteraction || (t.autoplay.paused = !1, i("autoplayResume"), s())
    }

    function S() {
        t.params.autoplay.pauseOnMouseEnter && (t.$el.on("mouseenter", h), t.$el.on("mouseleave", y))
    }

    function E() {
        t.$el.off("mouseenter", h), t.$el.off("mouseleave", y)
    }
    r("init", () => {
        t.params.autoplay.enabled && (a(), re().addEventListener("visibilitychange", d), S())
    }), r("beforeTransitionStart", (c, u, p) => {
        t.autoplay.running && (p || !t.params.autoplay.disableOnInteraction ? t.autoplay.pause(u) : o())
    }), r("sliderFirstMove", () => {
        t.autoplay.running && (t.params.autoplay.disableOnInteraction ? o() : f())
    }), r("touchEnd", () => {
        t.params.cssMode && t.autoplay.paused && !t.params.autoplay.disableOnInteraction && s()
    }), r("destroy", () => {
        E(), t.autoplay.running && o(), re().removeEventListener("visibilitychange", d)
    }), Object.assign(t.autoplay, {
        pause: f,
        run: s,
        start: a,
        stop: o
    })
}

function zt(e) {
    return typeof e == "object" && e !== null && e.constructor && Object.prototype.toString.call(e).slice(8, -1) === "Object"
}

function dt(e, t) {
    const n = ["__proto__", "constructor", "prototype"];
    Object.keys(t).filter(r => n.indexOf(r) < 0).forEach(r => {
        typeof e[r] == "undefined" ? e[r] = t[r] : zt(t[r]) && zt(e[r]) && Object.keys(t[r]).length > 0 ? t[r].__swiper__ ? e[r] = t[r] : dt(e[r], t[r]) : e[r] = t[r]
    })
}

function Sf(e) {
    return e === void 0 && (e = {}), e.navigation && typeof e.navigation.nextEl == "undefined" && typeof e.navigation.prevEl == "undefined"
}

function Ef(e) {
    return e === void 0 && (e = {}), e.pagination && typeof e.pagination.el == "undefined"
}

function Cf(e) {
    return e === void 0 && (e = {}), e.scrollbar && typeof e.scrollbar.el == "undefined"
}

function xf(e) {
    e === void 0 && (e = "");
    const t = e.split(" ").map(r => r.trim()).filter(r => !!r),
        n = [];
    return t.forEach(r => {
        n.indexOf(r) < 0 && n.push(r)
    }), n.join(" ")
}
const Tf = ["modules", "init", "_direction", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_preloadImages", "updateOnImagesReady", "_loop", "_loopAdditionalSlides", "_loopedSlides", "_loopedSlidesLimit", "_loopFillGroupWithBlank", "loopPreventsSlide", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideBlankClass", "slideActiveClass", "slideDuplicateActiveClass", "slideVisibleClass", "slideDuplicateClass", "slideNextClass", "slideDuplicateNextClass", "slidePrevClass", "slideDuplicatePrevClass", "wrapperClass", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "lazy", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom"];

function qh(e, t) {
    e === void 0 && (e = {}), t === void 0 && (t = !0);
    const n = {
            on: {}
        },
        r = {},
        i = {};
    dt(n, fe.defaults), dt(n, fe.extendedDefaults), n._emitClasses = !0, n.init = !1;
    const l = {},
        s = Tf.map(o => o.replace(/_/, "")),
        a = Object.assign({}, e);
    return Object.keys(a).forEach(o => {
        typeof e[o] != "undefined" && (s.indexOf(o) >= 0 ? zt(e[o]) ? (n[o] = {}, i[o] = {}, dt(n[o], e[o]), dt(i[o], e[o])) : (n[o] = e[o], i[o] = e[o]) : o.search(/on[A-Z]/) === 0 && typeof e[o] == "function" ? t ? r[`${o[2].toLowerCase()}${o.substr(3)}`] = e[o] : n.on[`${o[2].toLowerCase()}${o.substr(3)}`] = e[o] : l[o] = e[o])
    }), ["navigation", "pagination", "scrollbar"].forEach(o => {
        n[o] === !0 && (n[o] = {}), n[o] === !1 && delete n[o]
    }), {
        params: n,
        passedParams: i,
        rest: l,
        events: r
    }
}

function Kh(e, t) {
    let {
        el: n,
        nextEl: r,
        prevEl: i,
        paginationEl: l,
        scrollbarEl: s,
        swiper: a
    } = e;
    Sf(t) && r && i && (a.params.navigation.nextEl = r, a.originalParams.navigation.nextEl = r, a.params.navigation.prevEl = i, a.originalParams.navigation.prevEl = i), Ef(t) && l && (a.params.pagination.el = l, a.originalParams.pagination.el = l), Cf(t) && s && (a.params.scrollbar.el = s, a.originalParams.scrollbar.el = s), a.init(n)
}

function kf(e, t) {
    let n = t.slidesPerView;
    if (t.breakpoints) {
        const i = fe.prototype.getBreakpoint(t.breakpoints),
            l = i in t.breakpoints ? t.breakpoints[i] : void 0;
        l && l.slidesPerView && (n = l.slidesPerView)
    }
    let r = Math.ceil(parseFloat(t.loopedSlides || n, 10));
    return r += t.loopAdditionalSlides, r > e.length && t.loopedSlidesLimit && (r = e.length), r
}

function Zh(e, t, n) {
    const r = t.map((o, f) => gt.cloneElement(o, {
        swiper: e,
        "data-swiper-slide-index": f
    }));

    function i(o, f, d) {
        return gt.cloneElement(o, {
            key: `${o.key}-duplicate-${f}-${d}`,
            className: `${o.props.className||""} ${n.slideDuplicateClass}`
        })
    }
    if (n.loopFillGroupWithBlank) {
        const o = n.slidesPerGroup - r.length % n.slidesPerGroup;
        if (o !== n.slidesPerGroup)
            for (let f = 0; f < o; f += 1) {
                const d = gt.createElement("div", {
                    className: `${n.slideClass} ${n.slideBlankClass}`
                });
                r.push(d)
            }
    }
    n.slidesPerView === "auto" && !n.loopedSlides && (n.loopedSlides = r.length);
    const l = kf(r, n),
        s = [],
        a = [];
    for (let o = 0; o < l; o += 1) {
        const f = o - Math.floor(o / r.length) * r.length;
        a.push(i(r[f], o, "append")), s.unshift(i(r[r.length - f - 1], o, "prepend"))
    }
    return e && (e.loopedSlides = l), [...s, ...r, ...a]
}

function Jh(e, t, n, r, i) {
    const l = [];
    if (!t) return l;
    const s = o => {
        l.indexOf(o) < 0 && l.push(o)
    };
    if (n && r) {
        const o = r.map(i),
            f = n.map(i);
        o.join("") !== f.join("") && s("children"), r.length !== n.length && s("children")
    }
    return Tf.filter(o => o[0] === "_").map(o => o.replace(/_/, "")).forEach(o => {
        if (o in e && o in t)
            if (zt(e[o]) && zt(t[o])) {
                const f = Object.keys(e[o]),
                    d = Object.keys(t[o]);
                f.length !== d.length ? s(o) : (f.forEach(m => {
                    e[o][m] !== t[o][m] && s(o)
                }), d.forEach(m => {
                    e[o][m] !== t[o][m] && s(o)
                }))
            } else e[o] !== t[o] && s(o)
    }), l
}

function Pf(e) {
    const t = [];
    return gt.Children.toArray(e).forEach(n => {
        n.type && n.type.displayName === "SwiperSlide" ? t.push(n) : n.props && n.props.children && Pf(n.props.children).forEach(r => t.push(r))
    }), t
}

function em(e) {
    const t = [],
        n = {
            "container-start": [],
            "container-end": [],
            "wrapper-start": [],
            "wrapper-end": []
        };
    return gt.Children.toArray(e).forEach(r => {
        if (r.type && r.type.displayName === "SwiperSlide") t.push(r);
        else if (r.props && r.props.slot && n[r.props.slot]) n[r.props.slot].push(r);
        else if (r.props && r.props.children) {
            const i = Pf(r.props.children);
            i.length > 0 ? i.forEach(l => t.push(l)) : n["container-end"].push(r)
        } else n["container-end"].push(r)
    }), {
        slides: t,
        slots: n
    }
}

function tm(e) {
    let {
        swiper: t,
        slides: n,
        passedParams: r,
        changedParams: i,
        nextEl: l,
        prevEl: s,
        scrollbarEl: a,
        paginationEl: o
    } = e;
    const f = i.filter(w => w !== "children" && w !== "direction"),
        {
            params: d,
            pagination: m,
            navigation: h,
            scrollbar: y,
            virtual: S,
            thumbs: E
        } = t;
    let c, u, p, g, v;
    i.includes("thumbs") && r.thumbs && r.thumbs.swiper && d.thumbs && !d.thumbs.swiper && (c = !0), i.includes("controller") && r.controller && r.controller.control && d.controller && !d.controller.control && (u = !0), i.includes("pagination") && r.pagination && (r.pagination.el || o) && (d.pagination || d.pagination === !1) && m && !m.el && (p = !0), i.includes("scrollbar") && r.scrollbar && (r.scrollbar.el || a) && (d.scrollbar || d.scrollbar === !1) && y && !y.el && (g = !0), i.includes("navigation") && r.navigation && (r.navigation.prevEl || s) && (r.navigation.nextEl || l) && (d.navigation || d.navigation === !1) && h && !h.prevEl && !h.nextEl && (v = !0);
    const T = w => {
        !t[w] || (t[w].destroy(), w === "navigation" ? (d[w].prevEl = void 0, d[w].nextEl = void 0, t[w].prevEl = void 0, t[w].nextEl = void 0) : (d[w].el = void 0, t[w].el = void 0))
    };
    f.forEach(w => {
        if (zt(d[w]) && zt(r[w])) dt(d[w], r[w]);
        else {
            const P = r[w];
            (P === !0 || P === !1) && (w === "navigation" || w === "pagination" || w === "scrollbar") ? P === !1 && T(w): d[w] = r[w]
        }
    }), f.includes("controller") && !u && t.controller && t.controller.control && d.controller && d.controller.control && (t.controller.control = d.controller.control), i.includes("children") && n && S && d.virtual.enabled ? (S.slides = n, S.update(!0)) : i.includes("children") && t.lazy && t.params.lazy.enabled && t.lazy.load(), c && E.init() && E.update(!0), u && (t.controller.control = d.controller.control), p && (o && (d.pagination.el = o), m.init(), m.render(), m.update()), g && (a && (d.scrollbar.el = a), y.init(), y.updateSize(), y.setTranslate()), v && (l && (d.navigation.nextEl = l), s && (d.navigation.prevEl = s), h.init(), h.update()), i.includes("allowSlideNext") && (t.allowSlideNext = r.allowSlideNext), i.includes("allowSlidePrev") && (t.allowSlidePrev = r.allowSlidePrev), i.includes("direction") && t.changeDirection(r.direction, !1), t.update()
}

function nm(e, t, n) {
    if (!n) return null;
    const r = e.isHorizontal() ? {
        [e.rtlTranslate ? "right" : "left"]: `${n.offset}px`
    } : {
        top: `${n.offset}px`
    };
    return t.filter((i, l) => l >= n.from && l <= n.to).map(i => gt.cloneElement(i, {
        swiper: e,
        style: r
    }))
}
const rm = e => {
    !e || e.destroyed || !e.params.virtual || e.params.virtual && !e.params.virtual.enabled || (e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.lazy && e.params.lazy.enabled && e.lazy.load(), e.parallax && e.params.parallax && e.params.parallax.enabled && e.parallax.setTranslate())
};

function cr(e, t) {
    return typeof window == "undefined" ? R.exports.useEffect(e, t) : R.exports.useLayoutEffect(e, t)
}
const im = R.exports.createContext(null),
    lm = R.exports.createContext(null),
    sm = R.exports.forwardRef(function(e, t) {
        let De = e === void 0 ? {} : e,
            {
                className: n,
                tag: r = "div",
                wrapperTag: i = "div",
                children: l,
                onSwiper: s
            } = De,
            a = Pi(De, ["className", "tag", "wrapperTag", "children", "onSwiper"]),
            o = !1;
        const [f, d] = R.exports.useState("swiper"), [m, h] = R.exports.useState(null), [y, S] = R.exports.useState(!1), E = R.exports.useRef(!1), c = R.exports.useRef(null), u = R.exports.useRef(null), p = R.exports.useRef(null), g = R.exports.useRef(null), v = R.exports.useRef(null), T = R.exports.useRef(null), w = R.exports.useRef(null), P = R.exports.useRef(null), {
            params: x,
            passedParams: O,
            rest: _,
            events: z
        } = qh(a), {
            slides: N,
            slots: F
        } = em(l), b = () => {
            S(!y)
        };
        Object.assign(x.on, {
            _containerClasses(X, k) {
                d(k)
            }
        });
        const me = () => {
            if (Object.assign(x.on, z), o = !0, u.current = new fe(x), u.current.loopCreate = () => {}, u.current.loopDestroy = () => {}, x.loop && (u.current.loopedSlides = kf(N, x)), u.current.virtual && u.current.params.virtual.enabled) {
                u.current.virtual.slides = N;
                const X = {
                    cache: !1,
                    slides: N,
                    renderExternal: h,
                    renderExternalUpdate: !1
                };
                dt(u.current.params.virtual, X), dt(u.current.originalParams.virtual, X)
            }
        };
        c.current || me(), u.current && u.current.on("_beforeBreakpoint", b);
        const $e = () => {
                o || !z || !u.current || Object.keys(z).forEach(X => {
                    u.current.on(X, z[X])
                })
            },
            pt = () => {
                !z || !u.current || Object.keys(z).forEach(X => {
                    u.current.off(X, z[X])
                })
            };
        R.exports.useEffect(() => () => {
            u.current && u.current.off("_beforeBreakpoint", b)
        }), R.exports.useEffect(() => {
            !E.current && u.current && (u.current.emitSlidesClasses(), E.current = !0)
        }), cr(() => {
            if (t && (t.current = c.current), !!c.current) return u.current.destroyed && me(), Kh({
                el: c.current,
                nextEl: v.current,
                prevEl: T.current,
                paginationEl: w.current,
                scrollbarEl: P.current,
                swiper: u.current
            }, x), s && s(u.current), () => {
                u.current && !u.current.destroyed && u.current.destroy(!0, !1)
            }
        }, []), cr(() => {
            $e();
            const X = Jh(O, p.current, N, g.current, k => k.key);
            return p.current = O, g.current = N, X.length && u.current && !u.current.destroyed && tm({
                swiper: u.current,
                slides: N,
                passedParams: O,
                changedParams: X,
                nextEl: v.current,
                prevEl: T.current,
                scrollbarEl: P.current,
                paginationEl: w.current
            }), () => {
                pt()
            }
        }), cr(() => {
            rm(u.current)
        }, [m]);

        function Ue() {
            return x.virtual ? nm(u.current, N, m) : !x.loop || u.current && u.current.destroyed ? N.map(X => gt.cloneElement(X, {
                swiper: u.current
            })) : Zh(u.current, N, x)
        }
        return ft(r, ki(Ti({
            ref: c,
            className: xf(`${f}${n?` ${n}`:""}`)
        }, _), {
            children: $s(lm.Provider, {
                value: u.current,
                children: [F["container-start"], $s(i, {
                    className: "swiper-wrapper",
                    children: [F["wrapper-start"], Ue(), F["wrapper-end"]]
                }), Sf(x) && $s(Yd, {
                    children: [ft("div", {
                        ref: T,
                        className: "swiper-button-prev"
                    }), ft("div", {
                        ref: v,
                        className: "swiper-button-next"
                    })]
                }), Cf(x) && ft("div", {
                    ref: P,
                    className: "swiper-scrollbar"
                }), Ef(x) && ft("div", {
                    ref: w,
                    className: "swiper-pagination"
                }), F["container-end"]]
            })
        }))
    });
sm.displayName = "Swiper";
const om = R.exports.forwardRef(function(e, t) {
    let E = e === void 0 ? {} : e,
        {
            tag: n = "div",
            children: r,
            className: i = "",
            swiper: l,
            zoom: s,
            virtualIndex: a
        } = E,
        o = Pi(E, ["tag", "children", "className", "swiper", "zoom", "virtualIndex"]);
    const f = R.exports.useRef(null),
        [d, m] = R.exports.useState("swiper-slide");

    function h(c, u, p) {
        u === f.current && m(p)
    }
    cr(() => {
        if (t && (t.current = f.current), !(!f.current || !l)) {
            if (l.destroyed) {
                d !== "swiper-slide" && m("swiper-slide");
                return
            }
            return l.on("_slideClass", h), () => {
                !l || l.off("_slideClass", h)
            }
        }
    }), cr(() => {
        l && f.current && !l.destroyed && m(l.getSlideClasses(f.current))
    }, [l]);
    const y = {
            isActive: d.indexOf("swiper-slide-active") >= 0 || d.indexOf("swiper-slide-duplicate-active") >= 0,
            isVisible: d.indexOf("swiper-slide-visible") >= 0,
            isDuplicate: d.indexOf("swiper-slide-duplicate") >= 0,
            isPrev: d.indexOf("swiper-slide-prev") >= 0 || d.indexOf("swiper-slide-duplicate-prev") >= 0,
            isNext: d.indexOf("swiper-slide-next") >= 0 || d.indexOf("swiper-slide-duplicate-next") >= 0
        },
        S = () => typeof r == "function" ? r(y) : r;
    return ft(n, ki(Ti({
        ref: f,
        className: xf(`${d}${i?` ${i}`:""}`),
        "data-swiper-slide-index": a
    }, o), {
        children: ft(im.Provider, {
            value: y,
            children: s ? ft("div", {
                className: "swiper-zoom-container",
                "data-swiper-zoom": typeof s == "number" ? s : void 0,
                children: S()
            }) : S()
        })
    }))
});
om.displayName = "SwiperSlide";
export {
    dm as A, fm as B, cm as P, um as R, sm as S, ft as a, om as b, $s as j, R as r
};